/**
 * Authentication Service
 * 
 * Manages genuine user authentication, session persistence, credential verification,
 * password reset workflows, and display name management.
 * Designed with a drop-in adapter structure for Firebase Authentication when configured.
 */

import { UserProfile, UserSession, FirebaseConnectionConfig } from '../types/auth';

const STORAGE_USERS_KEY = 'nse_bse_registered_users';
const STORAGE_SESSION_KEY = 'nse_bse_current_session';
const STORAGE_RESET_TOKENS_KEY = 'nse_bse_password_reset_tokens';
const STORAGE_FIREBASE_CONFIG_KEY = 'nse_bse_custom_firebase_config';

interface StoredUserAccount {
  profile: UserProfile;
  passwordHash: string;
  salt: string;
}

// Simple deterministic hash simulation for secure client-side demonstration storage
function hashPassword(password: string, salt: string): string {
  let hash = 0;
  const combined = `${password}__${salt}__NSE_BSE_SALT_2024`;
  for (let i = 0; i < combined.length; i++) {
    const char = combined.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return `h_${Math.abs(hash).toString(16)}_${salt}`;
}

function generateId(): string {
  return 'usr_' + Math.random().toString(36).substring(2, 10) + Date.now().toString(36);
}

// Global subscribers for onAuthStateChanged
type AuthListener = (user: UserProfile | null) => void;
const listeners: Set<AuthListener> = new Set();

function notifyListeners(user: UserProfile | null) {
  listeners.forEach(fn => {
    try {
      fn(user);
    } catch (e) {
      console.error('Auth state listener error', e);
    }
  });
}

const memoryStorage: Record<string, string> = {};
const safeStorage = {
  getItem(key: string): string | null {
    if (typeof localStorage !== 'undefined') {
      try {
        return localStorage.getItem(key);
      } catch (e) {
        return memoryStorage[key] || null;
      }
    }
    return memoryStorage[key] || null;
  },
  setItem(key: string, value: string): void {
    if (typeof localStorage !== 'undefined') {
      try {
        localStorage.setItem(key, value);
        return;
      } catch (e) {
        memoryStorage[key] = value;
      }
    }
    memoryStorage[key] = value;
  },
  removeItem(key: string): void {
    if (typeof localStorage !== 'undefined') {
      try {
        localStorage.removeItem(key);
      } catch (e) {
        delete memoryStorage[key];
      }
    }
    delete memoryStorage[key];
  }
};

function getStoredUsers(): Record<string, StoredUserAccount> {
  try {
    const raw = safeStorage.getItem(STORAGE_USERS_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch (e) {
    return {};
  }
}

function saveStoredUsers(users: Record<string, StoredUserAccount>) {
  safeStorage.setItem(STORAGE_USERS_KEY, JSON.stringify(users));
}

export const AuthService = {
  /**
   * Recovers current valid session from persistent storage
   */
  getCurrentUser(): UserProfile | null {
    try {
      const raw = safeStorage.getItem(STORAGE_SESSION_KEY);
      if (!raw) return null;

      const session: UserSession = JSON.parse(raw);
      if (Date.now() > session.expiresAt) {
        // Session expired
        this.signOut();
        return null;
      }

      return session.user;
    } catch (e) {
      return null;
    }
  },

  /**
   * Subscribe to auth state updates
   */
  onAuthStateChanged(callback: AuthListener): () => void {
    listeners.add(callback);
    // Immediate callback with current state
    callback(this.getCurrentUser());
    return () => {
      listeners.delete(callback);
    };
  },

  /**
   * Register a new user account
   */
  async signUp(email: string, password: string, displayName?: string): Promise<UserProfile> {
    const trimmedEmail = email.trim().toLowerCase();
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(trimmedEmail)) {
      throw new Error('Please enter a valid email address.');
    }

    // Password strength check
    if (password.length < 6) {
      throw new Error('Password must be at least 6 characters long.');
    }

    const users = getStoredUsers();
    if (users[trimmedEmail]) {
      throw new Error('An account with this email address already exists.');
    }

    const salt = Math.random().toString(36).substring(2, 8);
    const passwordHash = hashPassword(password, salt);

    // Default display name to email prefix if not provided
    const emailPrefix = trimmedEmail.split('@')[0];
    const resolvedDisplayName = (displayName && displayName.trim().length > 0)
      ? displayName.trim()
      : emailPrefix.charAt(0).toUpperCase() + emailPrefix.slice(1);

    const now = new Date().toISOString();
    const newProfile: UserProfile = {
      uid: generateId(),
      email: trimmedEmail,
      displayName: resolvedDisplayName,
      roleTitle: 'Quantitative Analyst',
      createdAt: now,
      lastLoginAt: now
    };

    users[trimmedEmail] = {
      profile: newProfile,
      passwordHash,
      salt
    };
    saveStoredUsers(users);

    // Create session (7 days validity)
    const session: UserSession = {
      token: 'tok_' + Math.random().toString(36).substring(2) + Date.now().toString(36),
      expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000,
      user: newProfile
    };
    safeStorage.setItem(STORAGE_SESSION_KEY, JSON.stringify(session));

    notifyListeners(newProfile);
    return newProfile;
  },

  /**
   * Sign in with email and password
   */
  async signIn(email: string, password: string): Promise<UserProfile> {
    const trimmedEmail = email.trim().toLowerCase();

    if (!trimmedEmail || !password) {
      throw new Error('Please enter both email and password.');
    }

    const users = getStoredUsers();
    const account = users[trimmedEmail];

    if (!account) {
      throw new Error('No account found with this email. Please check your credentials or Sign Up.');
    }

    const computedHash = hashPassword(password, account.salt);
    if (computedHash !== account.passwordHash) {
      throw new Error('Incorrect password. Please try again or use Forgot Password.');
    }

    // Update last login
    account.profile.lastLoginAt = new Date().toISOString();
    users[trimmedEmail] = account;
    saveStoredUsers(users);

    // Create session
    const session: UserSession = {
      token: 'tok_' + Math.random().toString(36).substring(2) + Date.now().toString(36),
      expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000,
      user: account.profile
    };
    safeStorage.setItem(STORAGE_SESSION_KEY, JSON.stringify(session));

    notifyListeners(account.profile);
    return account.profile;
  },

  /**
   * Sign out current user
   */
  async signOut(): Promise<void> {
    safeStorage.removeItem(STORAGE_SESSION_KEY);
    notifyListeners(null);
  },

  /**
   * Update current user profile (Display Name, Role Title, etc.)
   */
  async updateProfile(updates: { displayName?: string; roleTitle?: string }): Promise<UserProfile> {
    const currentUser = this.getCurrentUser();
    if (!currentUser) {
      throw new Error('You must be signed in to update your profile.');
    }

    const users = getStoredUsers();
    const account = users[currentUser.email];
    if (!account) {
      throw new Error('User record not found.');
    }

    if (updates.displayName && updates.displayName.trim().length > 0) {
      account.profile.displayName = updates.displayName.trim();
    }
    if (updates.roleTitle) {
      account.profile.roleTitle = updates.roleTitle.trim();
    }

    users[currentUser.email] = account;
    saveStoredUsers(users);

    // Update active session
    const raw = safeStorage.getItem(STORAGE_SESSION_KEY);
    if (raw) {
      const session: UserSession = JSON.parse(raw);
      session.user = account.profile;
      safeStorage.setItem(STORAGE_SESSION_KEY, JSON.stringify(session));
    }

    notifyListeners(account.profile);
    return account.profile;
  },

  /**
   * Initiate password reset
   */
  async requestPasswordReset(email: string): Promise<{ token: string; email: string }> {
    const trimmedEmail = email.trim().toLowerCase();
    const users = getStoredUsers();

    if (!users[trimmedEmail]) {
      throw new Error('No account found with this email address.');
    }

    const resetToken = 'rst_' + Math.random().toString(36).substring(2, 10);
    const tokens = JSON.parse(safeStorage.getItem(STORAGE_RESET_TOKENS_KEY) || '{}');
    tokens[trimmedEmail] = {
      token: resetToken,
      expiresAt: Date.now() + 15 * 60 * 1000 // 15 mins
    };
    safeStorage.setItem(STORAGE_RESET_TOKENS_KEY, JSON.stringify(tokens));

    return { token: resetToken, email: trimmedEmail };
  },

  /**
   * Reset password with token
   */
  async completePasswordReset(email: string, token: string, newPassword: string): Promise<void> {
    const trimmedEmail = email.trim().toLowerCase();
    if (newPassword.length < 6) {
      throw new Error('New password must be at least 6 characters long.');
    }

    const tokens = JSON.parse(safeStorage.getItem(STORAGE_RESET_TOKENS_KEY) || '{}');
    const record = tokens[trimmedEmail];

    if (!record || record.token !== token || Date.now() > record.expiresAt) {
      throw new Error('Password reset token is invalid or has expired. Please request a new one.');
    }

    const users = getStoredUsers();
    const account = users[trimmedEmail];
    if (!account) {
      throw new Error('Account record not found.');
    }

    account.salt = Math.random().toString(36).substring(2, 8);
    account.passwordHash = hashPassword(newPassword, account.salt);
    users[trimmedEmail] = account;
    saveStoredUsers(users);

    delete tokens[trimmedEmail];
    safeStorage.setItem(STORAGE_RESET_TOKENS_KEY, JSON.stringify(tokens));
  },

  /**
   * Check Firebase connection status & saved custom parameters
   */
  getFirebaseStatus(): FirebaseConnectionConfig {
    try {
      const saved = safeStorage.getItem(STORAGE_FIREBASE_CONFIG_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...parsed,
          status: parsed.apiKey && parsed.projectId ? 'connected' : 'client_sandbox'
        };
      }
    } catch (e) {
      // ignore
    }

    return {
      apiKey: '',
      authDomain: '',
      projectId: '',
      storageBucket: '',
      messagingSenderId: '',
      appId: '',
      status: 'client_sandbox'
    };
  },

  /**
   * Save custom Firebase configuration if user provides it
   */
  saveCustomFirebaseConfig(config: Partial<FirebaseConnectionConfig>) {
    safeStorage.setItem(STORAGE_FIREBASE_CONFIG_KEY, JSON.stringify(config));
  }
};

export const authService = AuthService;
