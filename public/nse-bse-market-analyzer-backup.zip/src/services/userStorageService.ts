/**
 * User Storage Service
 * 
 * Partitions and persists application data (watchlists, preferences, notes)
 * on a per-user basis. Ensures that different authenticated users have completely
 * isolated watchlists and preferences across sessions.
 */

import { UserPreferences } from '../types/auth';

const WATCHLIST_PREFIX = 'nse_bse_watchlist_user_';
const PREFERENCES_PREFIX = 'nse_bse_preferences_user_';

export const DEFAULT_PREFERENCES: UserPreferences = {
  defaultExchange: 'NSE',
  defaultTimeframe: '1M',
  currencyFormat: 'lakhs_crores',
  highPrecisionMode: true,
  activeHorizon: 'T+1'
};

const DEFAULT_INITIAL_WATCHLIST = ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY'];

const memoryStorage: Record<string, string> = {};
const safeStorage = {
  getItem(key: string): string | null {
    if (typeof localStorage !== 'undefined') {
      try {
        return localStorage.getItem(key);
      } catch (e) {
        return memoryStorage[key] || null;
      }
    }
    return memoryStorage[key] || null;
  },
  setItem(key: string, value: string): void {
    if (typeof localStorage !== 'undefined') {
      try {
        localStorage.setItem(key, value);
        return;
      } catch (e) {
        memoryStorage[key] = value;
      }
    }
    memoryStorage[key] = value;
  },
  removeItem(key: string): void {
    if (typeof localStorage !== 'undefined') {
      try {
        localStorage.removeItem(key);
      } catch (e) {
        delete memoryStorage[key];
      }
    }
    delete memoryStorage[key];
  }
};

export const UserStorageService = {
  /**
   * Retrieves the watchlist specific to a given user ID
   */
  getUserWatchlist(userId?: string | null): string[] {
    const key = `${WATCHLIST_PREFIX}${userId || 'guest'}`;
    try {
      const raw = safeStorage.getItem(key);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Failed to load user watchlist from storage', e);
    }
    // Return default set for new accounts or guests
    return [...DEFAULT_INITIAL_WATCHLIST];
  },

  getWatchlist(userId?: string | null): string[] {
    return this.getUserWatchlist(userId);
  },

  /**
   * Persists the user's specific watchlist
   */
  saveUserWatchlist(userId: string | null | undefined, symbols: string[]): void {
    const key = `${WATCHLIST_PREFIX}${userId || 'guest'}`;
    try {
      safeStorage.setItem(key, JSON.stringify(symbols));
    } catch (e) {
      console.error('Failed to save user watchlist', e);
      throw new Error('Storage write failed. Please check local browser storage availability.');
    }
  },

  saveWatchlist(symbols: string[], userId?: string | null): void {
    this.saveUserWatchlist(userId, symbols);
  },

  addToWatchlist(userId: string | null | undefined, symbol: string): string[] {
    const current = this.getUserWatchlist(userId);
    const sym = symbol.toUpperCase().trim();
    if (!current.includes(sym)) {
      const updated = [...current, sym];
      this.saveUserWatchlist(userId, updated);
      return updated;
    }
    return current;
  },

  removeFromWatchlist(userId: string | null | undefined, symbol: string): string[] {
    const current = this.getUserWatchlist(userId);
    const sym = symbol.toUpperCase().trim();
    const updated = current.filter(s => s !== sym);
    this.saveUserWatchlist(userId, updated);
    return updated;
  },

  resetWatchlistToDefaults(userId?: string | null): string[] {
    this.saveUserWatchlist(userId, DEFAULT_INITIAL_WATCHLIST);
    return [...DEFAULT_INITIAL_WATCHLIST];
  },

  /**
   * Retrieves user preferences
   */
  getUserPreferences(userId?: string | null): UserPreferences {
    const key = `${PREFERENCES_PREFIX}${userId || 'guest'}`;
    try {
      const raw = safeStorage.getItem(key);
      if (raw) {
        return { ...DEFAULT_PREFERENCES, ...JSON.parse(raw) };
      }
    } catch (e) {
      console.warn('Failed to load user preferences', e);
    }
    return { ...DEFAULT_PREFERENCES };
  },

  /**
   * Persists user preferences
   */
  saveUserPreferences(userId: string | null | undefined, preferences: Partial<UserPreferences>): UserPreferences {
    const key = `${PREFERENCES_PREFIX}${userId || 'guest'}`;
    const current = this.getUserPreferences(userId);
    const updated = { ...current, ...preferences };
    try {
      safeStorage.setItem(key, JSON.stringify(updated));
    } catch (e) {
      console.error('Failed to save user preferences', e);
    }
    return updated;
  }
};

export const userStorageService = UserStorageService;
