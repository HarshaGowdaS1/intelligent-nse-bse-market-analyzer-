import React, { useState } from 'react';
import { 
  Settings, 
  User, 
  ShieldCheck, 
  Database, 
  Sliders, 
  CheckCircle2, 
  AlertCircle, 
  Save, 
  RefreshCw, 
  Download, 
  Trash2, 
  ExternalLink,
  Lock,
  Cpu,
  Layers
} from 'lucide-react';
import { UserProfile, UserPreferences } from '../../types/auth';
import { AuthService } from '../../services/authService';
import { UserStorageService } from '../../services/userStorageService';
import { Exchange, Timeframe } from '../../types/market';

interface SettingsPageProps {
  currentUser: UserProfile | null;
  onOpenAuth: (mode?: 'signin' | 'signup' | 'profile') => void;
  onUserUpdated: (user: UserProfile) => void;
  currentExchange: Exchange;
  onExchangeChange: (exchange: Exchange) => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({
  currentUser,
  onOpenAuth,
  onUserUpdated,
  currentExchange,
  onExchangeChange
}) => {
  const [displayName, setDisplayName] = useState(currentUser?.displayName || '');
  const [roleTitle, setRoleTitle] = useState(currentUser?.roleTitle || 'Quantitative Analyst');
  const [defaultExchange, setDefaultExchange] = useState<Exchange>(currentExchange);
  const [defaultTimeframe, setDefaultTimeframe] = useState<Timeframe>('1M');
  const [numberFormat, setNumberFormat] = useState<'indian' | 'international'>('indian');
  const [riskFreeRate, setRiskFreeRate] = useState<number>(6.85);
  
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [resetSuccess, setResetSuccess] = useState(false);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onOpenAuth('signin');
      return;
    }

    setIsSaving(true);
    try {
      const updated = await AuthService.updateProfile({
        displayName: displayName.trim(),
        roleTitle: roleTitle.trim()
      });
      onUserUpdated(updated);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err) {
      console.error('Failed to update profile', err);
    } finally {
      setIsSaving(false);
    }
  };

  const handleResetWatchlist = () => {
    UserStorageService.resetWatchlistToDefaults(currentUser?.uid);
    setResetSuccess(true);
    setTimeout(() => {
      setResetSuccess(false);
      window.location.reload();
    }, 800);
  };

  const handleExportConfiguration = () => {
    const config = {
      user: currentUser ? { email: currentUser.email, displayName: currentUser.displayName, roleTitle: currentUser.roleTitle } : 'guest',
      preferences: {
        defaultExchange,
        defaultTimeframe,
        numberFormat,
        riskFreeRate
      },
      exportedAt: new Date().toISOString()
    };

    const blob = new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `NSE_BSE_Terminal_Config_${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex flex-col gap-6 max-w-5xl pb-16">
      {/* Page Header */}
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="font-mono text-[10px] text-[#87929a] uppercase tracking-wider">
            Terminal Core
          </span>
          <span className="text-[#3e484f] text-[10px]">/</span>
          <span className="font-mono text-[10px] text-[#38bdf8] font-semibold uppercase tracking-wider">
            Configuration & Preferences
          </span>
        </div>
        <h1 className="text-xl sm:text-2xl font-bold text-[#d4e4fa] tracking-tight">
          System Settings & User Workspace
        </h1>
        <p className="text-xs text-[#bdc8d1] max-w-2xl mt-0.5">
          Manage your quantitative account credentials, exchange defaults, mathematical risk benchmarks, and data integration adapters.
        </p>
      </div>

      {/* Grid: 2 Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column: Account Profile (7 cols) */}
        <div className="lg:col-span-7 flex flex-col gap-5">
          {/* User Account Card */}
          <div className="p-4 sm:p-5 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] shadow-md flex flex-col gap-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#1c2b3c]">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-[#38bdf8]" />
                <h2 className="text-sm font-bold text-[#d4e4fa] uppercase tracking-wider">
                  Analyst Identity & Credentials
                </h2>
              </div>
              {currentUser ? (
                <span className="inline-flex items-center gap-1 font-mono text-[10px] px-2 py-0.5 rounded-full bg-[#56e5a9]/15 text-[#56e5a9]">
                  <CheckCircle2 className="w-3 h-3" />
                  Authenticated
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 font-mono text-[10px] px-2 py-0.5 rounded-full bg-[#87929a]/20 text-[#87929a]">
                  Guest Session
                </span>
              )}
            </div>

            {currentUser ? (
              <form onSubmit={handleSaveProfile} className="space-y-4 text-xs font-mono">
                <div>
                  <label className="text-[#87929a] text-[11px] block mb-1">REGISTERED EMAIL</label>
                  <input
                    type="email"
                    disabled
                    value={currentUser.email}
                    className="w-full h-9 px-3 rounded-lg bg-[#051424] border border-[#1c2b3c] text-[#87929a] cursor-not-allowed text-xs"
                  />
                  <span className="text-[10px] text-[#87929a] mt-1 block">Account UID: {currentUser.uid}</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[#d4e4fa] text-[11px] block mb-1">DISPLAY NAME</label>
                    <input
                      type="text"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder="e.g. Rahul Verma"
                      required
                      className="w-full h-9 px-3 rounded-lg bg-[#122131] border border-[#1c2b3c] text-[#d4e4fa] focus:border-[#38bdf8] focus:outline-none transition-colors text-xs"
                    />
                  </div>

                  <div>
                    <label className="text-[#d4e4fa] text-[11px] block mb-1">ORGANIZATION / ROLE</label>
                    <input
                      type="text"
                      value={roleTitle}
                      onChange={(e) => setRoleTitle(e.target.value)}
                      placeholder="e.g. Lead Quantitative Researcher"
                      className="w-full h-9 px-3 rounded-lg bg-[#122131] border border-[#1c2b3c] text-[#d4e4fa] focus:border-[#38bdf8] focus:outline-none transition-colors text-xs"
                    />
                  </div>
                </div>

                {saveSuccess && (
                  <div className="p-2.5 rounded-lg bg-[#56e5a9]/15 border border-[#56e5a9]/40 text-[#56e5a9] text-xs flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    <span>Profile identity updated successfully.</span>
                  </div>
                )}

                <div className="flex justify-end pt-1">
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="px-4 py-2 rounded-lg bg-[#38bdf8] text-[#00354a] font-semibold text-xs flex items-center gap-1.5 hover:brightness-110 shadow-sm transition-all"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>{isSaving ? 'Updating...' : 'Save Profile Changes'}</span>
                  </button>
                </div>
              </form>
            ) : (
              <div className="p-4 rounded-lg bg-[#010f1f] border border-[#1c2b3c] flex flex-col gap-3 text-xs">
                <p className="text-[#bdc8d1]">
                  You are currently operating in <strong>Guest Mode</strong>. In guest mode, your watchlist and chart preferences are saved locally on this machine.
                </p>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onOpenAuth('signup')}
                    className="px-3.5 py-2 rounded-lg bg-[#38bdf8] text-[#00354a] font-semibold text-xs hover:brightness-110 transition-all"
                  >
                    Create Free Analyst Account
                  </button>
                  <button
                    onClick={() => onOpenAuth('signin')}
                    className="px-3.5 py-2 rounded-lg bg-[#122131] border border-[#1c2b3c] text-[#8ed5ff] text-xs hover:bg-[#1c2b3c] transition-colors"
                  >
                    Sign In Existing Account
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Quantitative Risk & Analytics Parameters */}
          <div className="p-4 sm:p-5 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] shadow-md flex flex-col gap-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#1c2b3c]">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-[#38bdf8]" />
                <h2 className="text-sm font-bold text-[#d4e4fa] uppercase tracking-wider">
                  Quantitative Risk Parameters
                </h2>
              </div>
              <span className="font-mono text-[10px] text-[#87929a]">ACTUAL COMPUTATIONS</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
              <div>
                <label className="text-[#87929a] text-[11px] block mb-1">
                  RISK-FREE RATE (Rf) BENCHMARK
                </label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.05"
                    value={riskFreeRate}
                    onChange={(e) => setRiskFreeRate(parseFloat(e.target.value) || 0)}
                    className="w-full h-9 pl-3 pr-8 rounded-lg bg-[#122131] border border-[#1c2b3c] text-[#d4e4fa] focus:border-[#38bdf8] focus:outline-none"
                  />
                  <span className="absolute right-3 top-2.5 text-[#87929a] text-xs">% p.a.</span>
                </div>
                <p className="text-[10px] text-[#87929a] mt-1">
                  Benchmarked to Reserve Bank of India (RBI) 10-Year Sovereign G-Sec yield (currently 6.85%).
                </p>
              </div>

              <div>
                <label className="text-[#87929a] text-[11px] block mb-1">
                  NUMBER FORMATTING
                </label>
                <select
                  value={numberFormat}
                  onChange={(e) => setNumberFormat(e.target.value as any)}
                  className="w-full h-9 px-3 rounded-lg bg-[#122131] border border-[#1c2b3c] text-[#d4e4fa] focus:border-[#38bdf8] focus:outline-none text-xs"
                >
                  <option value="indian">Indian Notation (Lakhs & Crores ₹)</option>
                  <option value="international">Standard International (M & B $)</option>
                </select>
                <p className="text-[10px] text-[#87929a] mt-1">
                  Formatted across market capitalization, daily turnover, and institutional blocks.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Platform Adapters & Reset Actions (5 cols) */}
        <div className="lg:col-span-5 flex flex-col gap-5">
          {/* Cloud Database Integration Status Card */}
          <div className="p-4 sm:p-5 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] shadow-md flex flex-col gap-3">
            <div className="flex items-center justify-between pb-2 border-b border-[#1c2b3c]">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-[#38bdf8]" />
                <h2 className="text-xs font-bold text-[#d4e4fa] uppercase tracking-wider">
                  Data Persistence Architecture
                </h2>
              </div>
              <span className="font-mono text-[9px] px-2 py-0.5 rounded bg-[#122131] text-[#38bdf8]">
                CLIENT SANDBOX
              </span>
            </div>

            <p className="text-xs text-[#bdc8d1] leading-relaxed">
              The application is configured to run on an authenticated client storage model with isolated user namespaces (<code>nse_bse_watchlist_user_&#123;uid&#125;</code>).
            </p>

            <div className="p-3 rounded-lg bg-[#010f1f] border border-[#1c2b3c] space-y-2 font-mono text-[11px]">
              <div className="flex items-center justify-between">
                <span className="text-[#87929a]">Client Auth Engine:</span>
                <span className="text-[#56e5a9] font-bold">Active & Partitioned</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#87929a]">Remote Firebase Sync:</span>
                <span className="text-[#ffb4ab]">User Declined in UI</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#87929a]">Session Expiry:</span>
                <span className="text-[#d4e4fa]">7 Days (Rolling)</span>
              </div>
            </div>

            <div className="text-[11px] text-[#87929a] space-y-1">
              <p>
                <strong>Future Cloud Upgrade:</strong> To connect Google Cloud Firestore or Firebase Auth, specify <code>VITE_FIREBASE_API_KEY</code> and <code>VITE_FIREBASE_PROJECT_ID</code> in <code>.env</code>.
              </p>
            </div>
          </div>

          {/* Reset & Backup Actions */}
          <div className="p-4 sm:p-5 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] shadow-md flex flex-col gap-3">
            <div className="flex items-center justify-between pb-2 border-b border-[#1c2b3c]">
              <div className="flex items-center gap-2">
                <Cpu className="w-4 h-4 text-[#87929a]" />
                <h2 className="text-xs font-bold text-[#d4e4fa] uppercase tracking-wider">
                  Storage Maintenance & Backup
                </h2>
              </div>
            </div>

            <div className="space-y-2 text-xs">
              <button
                onClick={handleExportConfiguration}
                className="w-full py-2 px-3 rounded-lg bg-[#122131] hover:bg-[#1c2b3c] border border-[#1c2b3c] text-[#8ed5ff] font-mono flex items-center justify-between transition-colors"
              >
                <span>Export Configuration (JSON)</span>
                <Download className="w-3.5 h-3.5 text-[#38bdf8]" />
              </button>

              <button
                onClick={handleResetWatchlist}
                className="w-full py-2 px-3 rounded-lg bg-[#122131] hover:bg-[#93000a]/20 border border-[#1c2b3c] hover:border-[#ffb4ab]/40 text-[#ffb4ab] font-mono flex items-center justify-between transition-colors"
              >
                <span>Reset Watchlist to Predefined (10 Equities)</span>
                <Trash2 className="w-3.5 h-3.5" />
              </button>

              {resetSuccess && (
                <div className="p-2 rounded bg-[#56e5a9]/15 text-[#56e5a9] font-mono text-[10px] text-center">
                  Watchlist reset to initial default basket.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
