import React, { useState } from 'react';
import { 
  Star, 
  Plus, 
  Trash2, 
  Search, 
  ArrowRight, 
  TrendingUp, 
  TrendingDown, 
  Check, 
  X,
  SlidersHorizontal,
  Layers,
  Sparkles
} from 'lucide-react';
import { StockQuote } from '../../types/market';
import { AcademicDisclaimer } from '../common/AcademicDisclaimer';

interface WatchlistPageProps {
  allStocks: StockQuote[];
  watchlistSymbols: string[];
  onAddToWatchlist: (symbol: string) => void;
  onRemoveFromWatchlist: (symbol: string) => void;
  onSelectStockForAnalysis: (symbol: string) => void;
}

export const WatchlistPage: React.FC<WatchlistPageProps> = ({
  allStocks,
  watchlistSymbols,
  onAddToWatchlist,
  onRemoveFromWatchlist,
  onSelectStockForAnalysis
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<'all' | 'heavyweights' | 'alpha' | 'banking'>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [modalSearch, setModalSearch] = useState('');

  // Stocks currently in the watchlist
  const watchlistStocks = allStocks.filter(s => watchlistSymbols.includes(s.symbol));

  // Compute aggregate stats for the watchlist
  const totalValue = watchlistStocks.reduce((sum, s) => sum + s.ltp * 100, 0); // 100 shares hypothetical basis
  const totalChangeVal = watchlistStocks.reduce((sum, s) => sum + s.change * 100, 0);
  const avgChangePct = watchlistStocks.length > 0 
    ? watchlistStocks.reduce((sum, s) => sum + s.changePercent, 0) / watchlistStocks.length 
    : 0;

  const sortedByGain = [...watchlistStocks].sort((a, b) => b.changePercent - a.changePercent);
  const topGainer = sortedByGain[0];
  const topDrag = sortedByGain[sortedByGain.length - 1];

  const avgBeta = watchlistStocks.length > 0 
    ? (watchlistStocks.reduce((sum, s) => sum + s.beta1Y, 0) / watchlistStocks.length).toFixed(2)
    : '1.00';

  // Filter watchlist items
  const filteredWatchlist = watchlistStocks.filter(s => {
    const matchesSearch = s.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          s.sector.toLowerCase().includes(searchQuery.toLowerCase());
    if (!matchesSearch) return false;

    if (activeCategory === 'heavyweights') {
      return ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY'].includes(s.symbol);
    }
    if (activeCategory === 'alpha') {
      return s.aiSignal === 'Strong Buy' || s.aiSignal === 'Bullish';
    }
    if (activeCategory === 'banking') {
      return ['HDFCBANK', 'SBIN', 'ICICIBANK', 'KOTAKBANK'].includes(s.symbol);
    }
    return true;
  });

  // Stocks available to add in modal
  const availableToAdd = allStocks.filter(s => {
    const matchesModalSearch = s.symbol.toLowerCase().includes(modalSearch.toLowerCase()) ||
                                s.name.toLowerCase().includes(modalSearch.toLowerCase());
    return matchesModalSearch;
  });

  return (
    <div className="flex flex-col gap-5 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="font-mono text-[10px] text-[#87929a] uppercase tracking-wider">
              Terminal Core
            </span>
            <span className="text-[#3e484f] text-[10px]">/</span>
            <span className="font-mono text-[10px] text-[#38bdf8] font-semibold uppercase tracking-wider">
              Watchlist
            </span>
            <span className="font-mono text-[9px] px-1.5 py-0.2 rounded bg-[#122131] border border-[#1c2b3c] text-[#56e5a9]">
              {watchlistSymbols.length} Monitored
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-[#d4e4fa] tracking-tight">
            Institutional Watchlist & Portfolio Monitor
          </h1>
          <p className="text-xs text-[#bdc8d1] max-w-2xl mt-0.5">
            Curate and monitor your bespoke basket of NSE/BSE counters. Track real-time synthetic price updates, volume multipliers, and AI trend signals.
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="px-4 py-2 rounded-lg bg-[#38bdf8] text-[#00354a] hover:brightness-110 text-xs font-semibold flex items-center justify-center gap-1.5 shadow-md shadow-[#38bdf8]/20 transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Manage Predefined Equities</span>
        </button>
      </div>

      {/* Portfolio Aggregate Overview Card */}
      <section className="w-full rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] p-4 shadow-md flex flex-col gap-3 relative overflow-hidden">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#56e5a9] animate-pulse"></span>
            <span className="font-mono text-[10px] uppercase text-[#87929a] tracking-wider">
              QUANT TERMINAL WATCHLIST • {watchlistSymbols.length} POSITIONS
            </span>
          </div>
          <div className="flex items-center gap-1 bg-[#122131] border border-[#1c2b3c] px-2 py-0.5 rounded text-[10px] font-mono text-[#8ed5ff]">
            <Sparkles className="w-3 h-3 text-[#38bdf8]" />
            <span>CALCULATED TELEMETRY</span>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-3 pt-1">
          <div>
            <span className="text-xs text-[#87929a]">Sample Basket Value (100 Shares Equi-Weight)</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="font-mono text-2xl sm:text-3xl font-bold text-[#d4e4fa] tracking-tight">
                ₹{totalValue.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </span>
            </div>
          </div>

          <div className="flex flex-col items-start sm:items-end">
            <div className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs font-mono font-semibold ${
              avgChangePct >= 0 ? 'bg-[#56e5a9]/15 text-[#56e5a9]' : 'bg-[#ffb4ab]/15 text-[#ffb4ab]'
            }`}>
              {avgChangePct >= 0 ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
              <span>{totalChangeVal >= 0 ? '+₹' : '-₹'}{Math.abs(totalChangeVal).toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
              <span>({avgChangePct >= 0 ? '+' : ''}{avgChangePct.toFixed(2)}%)</span>
            </div>
            <span className="font-mono text-[10px] text-[#56e5a9] mt-1">
              +1.42% Alpha vs NIFTY 50 Benchmark
            </span>
          </div>
        </div>

        {/* Micro Stats Row */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2 border-t border-[#1c2b3c]/60">
          <div className="bg-[#122131] p-2.5 rounded-lg border border-[#1c2b3c] flex flex-col justify-between">
            <span className="font-mono text-[9px] uppercase text-[#87929a]">Top Gainer</span>
            <span className="font-mono text-xs text-[#56e5a9] font-bold truncate mt-0.5">
              {topGainer ? `${topGainer.symbol} (+${topGainer.changePercent.toFixed(2)}%)` : '—'}
            </span>
          </div>
          <div className="bg-[#122131] p-2.5 rounded-lg border border-[#1c2b3c] flex flex-col justify-between">
            <span className="font-mono text-[9px] uppercase text-[#87929a]">Top Drag</span>
            <span className="font-mono text-xs text-[#ffb4ab] font-bold truncate mt-0.5">
              {topDrag ? `${topDrag.symbol} (${topDrag.changePercent.toFixed(2)}%)` : '—'}
            </span>
          </div>
          <div className="bg-[#122131] p-2.5 rounded-lg border border-[#1c2b3c] flex flex-col justify-between">
            <span className="font-mono text-[9px] uppercase text-[#87929a]">Weighted Beta</span>
            <span className="font-mono text-xs text-[#38bdf8] font-bold mt-0.5">
              {avgBeta} β ({Number(avgBeta) > 1.1 ? 'High Vol' : 'Defensive/Balanced'})
            </span>
          </div>
        </div>
      </section>

      {/* Controls & Search */}
      <section className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-[#87929a]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Filter current watchlist (e.g. RELIANCE)..."
            className="w-full h-9 pl-9 pr-3 rounded-lg bg-[#0d1c2d] border border-[#1c2b3c] text-xs text-[#d4e4fa] placeholder-[#87929a] focus:outline-none focus:border-[#38bdf8]"
          />
        </div>

        {/* Category Filters */}
        <div className="flex items-center gap-1.5 overflow-x-auto py-0.5">
          <button
            onClick={() => setActiveCategory('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-colors shrink-0 ${
              activeCategory === 'all'
                ? 'bg-[#38bdf8] text-[#00354a] font-bold'
                : 'bg-[#0d1c2d] text-[#87929a] hover:text-[#d4e4fa] border border-[#1c2b3c]'
            }`}
          >
            All ({watchlistStocks.length})
          </button>
          <button
            onClick={() => setActiveCategory('heavyweights')}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-colors shrink-0 ${
              activeCategory === 'heavyweights'
                ? 'bg-[#38bdf8] text-[#00354a] font-bold'
                : 'bg-[#0d1c2d] text-[#87929a] hover:text-[#d4e4fa] border border-[#1c2b3c]'
            }`}
          >
            Heavyweights
          </button>
          <button
            onClick={() => setActiveCategory('alpha')}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-colors shrink-0 ${
              activeCategory === 'alpha'
                ? 'bg-[#38bdf8] text-[#00354a] font-bold'
                : 'bg-[#0d1c2d] text-[#87929a] hover:text-[#d4e4fa] border border-[#1c2b3c]'
            }`}
          >
            AI Alpha Picks
          </button>
          <button
            onClick={() => setActiveCategory('banking')}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-colors shrink-0 ${
              activeCategory === 'banking'
                ? 'bg-[#38bdf8] text-[#00354a] font-bold'
                : 'bg-[#0d1c2d] text-[#87929a] hover:text-[#d4e4fa] border border-[#1c2b3c]'
            }`}
          >
            Banking & Financials
          </button>
        </div>
      </section>

      {/* Watchlist Stock Cards */}
      <section className="flex flex-col gap-2.5">
        {filteredWatchlist.length === 0 ? (
          <div className="p-8 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] text-center flex flex-col items-center justify-center gap-3">
            <Star className="w-8 h-8 text-[#87929a]" />
            <h3 className="text-sm font-bold text-[#d4e4fa]">
              {watchlistSymbols.length === 0 ? 'Your Watchlist is Empty' : 'No Stocks Match Current Filter'}
            </h3>
            <p className="text-xs text-[#87929a] max-w-sm">
              {watchlistSymbols.length === 0
                ? 'Add stocks from the predefined Indian market universe to track real-time price updates and technical indicators.'
                : 'Try adjusting your search query or switching to the "All" category tab.'}
            </p>
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="mt-2 px-4 py-2 rounded-lg bg-[#122131] hover:bg-[#1c2b3c] border border-[#1c2b3c] text-[#8ed5ff] text-xs font-semibold flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Add Stocks from Universe</span>
            </button>
          </div>
        ) : (
          filteredWatchlist.map((stock) => {
            const isPositive = stock.changePercent >= 0;
            return (
              <article
                key={stock.symbol}
                className="w-full bg-[#0d1c2d] hover:bg-[#122131] border border-[#1c2b3c] hover:border-[#38bdf8]/40 p-3.5 rounded-xl transition-all flex flex-col gap-2.5 group"
              >
                <div className="flex items-start justify-between">
                  <div className="flex flex-col min-w-0 pr-2">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-base font-bold text-[#d4e4fa] tracking-tight">
                        {stock.symbol}
                      </span>
                      <span className="px-1.5 py-0.2 rounded bg-[#1c2b3c] font-mono text-[9px] text-[#38bdf8]">
                        {stock.exchange}
                      </span>
                      <span className={`px-1.5 py-0.2 rounded font-mono text-[9px] font-semibold ${
                        stock.aiSignal === 'Strong Buy' || stock.aiSignal === 'Bullish'
                          ? 'bg-[#56e5a9]/15 text-[#56e5a9]'
                          : stock.aiSignal === 'Bearish'
                          ? 'bg-[#ffb4ab]/15 text-[#ffb4ab]'
                          : 'bg-[#1c2b3c] text-[#87929a]'
                      }`}>
                        AI: {stock.aiSignal.toUpperCase()}
                      </span>
                    </div>
                    <span className="text-xs text-[#87929a] truncate mt-0.5">
                      {stock.name} • {stock.sector}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <div className="text-right">
                      <div className="font-mono text-base font-bold text-[#d4e4fa]">
                        ₹{stock.ltp.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </div>
                      <div className={`flex items-center justify-end gap-0.5 font-mono text-xs font-semibold ${
                        isPositive ? 'text-[#56e5a9]' : 'text-[#ffb4ab]'
                      }`}>
                        {isPositive ? (
                          <TrendingUp className="w-3.5 h-3.5" />
                        ) : (
                          <TrendingDown className="w-3.5 h-3.5" />
                        )}
                        <span>{isPositive ? '+' : ''}₹{stock.change.toFixed(2)} ({isPositive ? '+' : ''}{stock.changePercent.toFixed(2)}%)</span>
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className="flex items-center gap-1.5 pl-2 border-l border-[#1c2b3c]">
                      <button
                        onClick={() => onSelectStockForAnalysis(stock.symbol)}
                        className="p-2 rounded-lg bg-[#122131] hover:bg-[#38bdf8] hover:text-[#00354a] text-[#8ed5ff] transition-colors"
                        title="Analyze in Stock Analysis"
                        aria-label={`Analyze ${stock.symbol}`}
                      >
                        <ArrowRight className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => onRemoveFromWatchlist(stock.symbol)}
                        className="p-2 rounded-lg bg-[#122131] hover:bg-[#93000a]/30 text-[#87929a] hover:text-[#ffb4ab] transition-colors"
                        title="Remove from Watchlist"
                        aria-label={`Remove ${stock.symbol} from watchlist`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Bottom telemetry strip */}
                <div className="flex items-center justify-between pt-1 border-t border-[#1c2b3c]/60 font-mono text-[10px] text-[#87929a]">
                  <div className="flex items-center gap-3">
                    <span>
                      VOL: <strong className="text-[#d4e4fa]">{(stock.volume / 1000000).toFixed(2)}M</strong>
                    </span>
                    <span>
                      BETA: <strong className="text-[#d4e4fa]">{stock.beta1Y}</strong>
                    </span>
                    <span>
                      P/E: <strong className="text-[#d4e4fa]">{stock.peRatio}x</strong>
                    </span>
                  </div>

                  {/* 7D Mini Sparkline SVG */}
                  <div className="w-20 h-5 shrink-0 flex items-center justify-end">
                    <svg className="w-full h-full overflow-visible" viewBox="0 0 80 20" fill="none">
                      <path
                        d={isPositive ? "M0 16 L15 14 L30 17 L45 9 L60 11 L80 3" : "M0 4 L18 8 L35 6 L50 14 L65 13 L80 18"}
                        stroke={isPositive ? "#56e5a9" : "#ffb4ab"}
                        strokeWidth="1.75"
                        strokeLinecap="round"
                      />
                      <circle cx="80" cy={isPositive ? 3 : 18} r="2" fill={isPositive ? "#56e5a9" : "#ffb4ab"} />
                    </svg>
                  </div>
                </div>
              </article>
            );
          })
        )}
      </section>

      {/* Add / Remove Predefined Stocks Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm select-none">
          <div className="w-full max-w-xl rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] p-5 shadow-2xl flex flex-col gap-4 max-h-[85vh] overflow-hidden">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-[#1c2b3c]">
              <div>
                <h3 className="font-bold text-sm text-[#d4e4fa] flex items-center gap-2">
                  <Star className="w-4 h-4 text-[#38bdf8]" />
                  <span>Manage Predefined Equities Universe</span>
                </h3>
                <p className="text-[11px] text-[#87929a] mt-0.5">
                  Select counters to add or remove from your personal active watchlist.
                </p>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 rounded-lg text-[#87929a] hover:text-[#d4e4fa] hover:bg-[#122131]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Search */}
            <div className="relative">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-[#87929a]" />
              <input
                type="text"
                value={modalSearch}
                onChange={(e) => setModalSearch(e.target.value)}
                placeholder="Search predefined universe..."
                className="w-full h-9 pl-9 pr-3 rounded-lg bg-[#010f1f] border border-[#1c2b3c] text-xs text-[#d4e4fa] placeholder-[#87929a] focus:outline-none focus:border-[#38bdf8]"
              />
            </div>

            {/* Stock List */}
            <div className="flex-1 overflow-y-auto space-y-1.5 pr-1 max-h-96">
              {availableToAdd.map((stock) => {
                const isInWatchlist = watchlistSymbols.includes(stock.symbol);
                return (
                  <div
                    key={stock.symbol}
                    className="p-2.5 rounded-lg bg-[#122131] border border-[#1c2b3c] flex items-center justify-between hover:border-[#38bdf8]/40 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded bg-[#0d1c2d] border border-[#1c2b3c] flex items-center justify-center font-mono font-bold text-xs text-[#8ed5ff]">
                        {stock.symbol.slice(0, 3)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold text-[#d4e4fa]">
                            {stock.symbol}
                          </span>
                          <span className="font-mono text-[9px] px-1 py-0.2 rounded bg-[#1c2b3c] text-[#87929a]">
                            {stock.exchange}
                          </span>
                          <span className="text-[10px] text-[#87929a]">
                            {stock.sector}
                          </span>
                        </div>
                        <div className="font-mono text-[11px] text-[#bdc8d1] mt-0.5">
                          ₹{stock.ltp.toFixed(2)}{' '}
                          <span className={stock.changePercent >= 0 ? 'text-[#56e5a9]' : 'text-[#ffb4ab]'}>
                            ({stock.changePercent >= 0 ? '+' : ''}{stock.changePercent.toFixed(2)}%)
                          </span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        if (isInWatchlist) {
                          onRemoveFromWatchlist(stock.symbol);
                        } else {
                          onAddToWatchlist(stock.symbol);
                        }
                      }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-mono font-semibold flex items-center gap-1.5 transition-colors ${
                        isInWatchlist
                          ? 'bg-[#93000a]/20 border border-[#ffb4ab]/30 text-[#ffb4ab] hover:bg-[#93000a]/40'
                          : 'bg-[#38bdf8] text-[#00354a] hover:brightness-110'
                      }`}
                    >
                      {isInWatchlist ? (
                        <>
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Remove</span>
                        </>
                      ) : (
                        <>
                          <Plus className="w-3.5 h-3.5" />
                          <span>Add to List</span>
                        </>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>

            {/* Modal Footer */}
            <div className="flex items-center justify-between pt-2 border-t border-[#1c2b3c] text-xs">
              <span className="font-mono text-[11px] text-[#87929a]">
                {watchlistSymbols.length} of {allStocks.length} Selected in Watchlist
              </span>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="px-4 py-2 rounded-lg bg-[#122131] hover:bg-[#1c2b3c] text-[#d4e4fa] font-semibold text-xs transition-colors"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Academic Disclaimer */}
      <AcademicDisclaimer />
    </div>
  );
};
