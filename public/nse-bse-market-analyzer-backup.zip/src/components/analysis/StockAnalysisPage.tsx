import React, { useState, useEffect, useMemo } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  Search, 
  SlidersHorizontal, 
  Activity, 
  BarChart2, 
  Layers, 
  Info,
  Calendar,
  Zap,
  ArrowRight,
  Download,
  ShieldAlert,
  Percent,
  CheckCircle2
} from 'lucide-react';
import { StockQuote, CandleData, Timeframe } from '../../types/market';
import { SampleDataService } from '../../services/dataService';
import { 
  calculateSMA, 
  calculateEMA, 
  calculateRSI, 
  calculateBollingerBands, 
  calculatePivotPoints,
  calculateMACD,
  calculateRiskMetrics,
  calculateBeta
} from '../../services/indicators';
import { exportStockDataToCSV } from '../../utils/csvExport';
import { AcademicDisclaimer } from '../common/AcademicDisclaimer';

interface StockAnalysisPageProps {
  selectedSymbol: string;
  onSelectSymbol: (symbol: string) => void;
  allStocks: StockQuote[];
  onNavigateToPredictions: (symbol: string) => void;
}

export const StockAnalysisPage: React.FC<StockAnalysisPageProps> = ({
  selectedSymbol,
  onSelectSymbol,
  allStocks,
  onNavigateToPredictions
}) => {
  const [timeframe, setTimeframe] = useState<Timeframe>('1M');
  const [chartType, setChartType] = useState<'candles' | 'line'>('candles');
  const [showEMA20, setShowEMA20] = useState(true);
  const [showSMA50, setShowSMA50] = useState(true);
  const [showBollinger, setShowBollinger] = useState(false);
  const [hoveredCandle, setHoveredCandle] = useState<CandleData | null>(null);
  const [candles, setCandles] = useState<CandleData[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Pre-selected primary stocks for quick-switch tabs
  const primaryStocks = ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'SBIN', 'TATAMOTORS'];

  // Current selected stock metadata
  const currentStock = allStocks.find(s => s.symbol === selectedSymbol) || allStocks[0];

  // Fetch historical data whenever symbol or timeframe changes
  useEffect(() => {
    let isMounted = true;
    setIsLoading(true);

    SampleDataService.getHistoricalCandles(selectedSymbol, timeframe)
      .then((data) => {
        if (isMounted) {
          setCandles(data);
          setHoveredCandle(null);
          setIsLoading(false);
        }
      })
      .catch((err) => {
        console.error('Failed to load historical candles', err);
        if (isMounted) setIsLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [selectedSymbol, timeframe]);

  // Pure mathematical calculations on underlying OHLCV vector data
  const closePrices = useMemo(() => candles.map(c => c.close), [candles]);

  const ema20 = useMemo(() => calculateEMA(closePrices, 20), [closePrices]);
  const sma50 = useMemo(() => calculateSMA(closePrices, 50), [closePrices]);
  const rsi14 = useMemo(() => calculateRSI(closePrices, 14), [closePrices]);
  const bollinger = useMemo(() => calculateBollingerBands(closePrices, 20, 2), [closePrices]);
  const macd = useMemo(() => calculateMACD(closePrices, 12, 26, 9), [closePrices]);
  const riskMetrics = useMemo(() => calculateRiskMetrics(closePrices, 6.85), [closePrices]);

  const pivotPoints = useMemo(() => {
    if (!currentStock) return { pp: 0, r1: 0, s1: 0, r2: 0, s2: 0 };
    return calculatePivotPoints(currentStock.high, currentStock.low, currentStock.ltp);
  }, [currentStock]);

  // Last calculated values
  const currentRSI = rsi14.length > 0 ? rsi14[rsi14.length - 1] : 50;
  const currentEMA = ema20.length > 0 ? ema20[ema20.length - 1] : currentStock.ltp;
  const currentSMA = sma50.length > 0 ? sma50[sma50.length - 1] : currentStock.ltp;
  const currentMACD = macd.macdLine.length > 0 ? (macd.macdLine[macd.macdLine.length - 1] ?? 0) : 0;
  const currentSignal = macd.signalLine.length > 0 ? (macd.signalLine[macd.signalLine.length - 1] ?? 0) : 0;
  const currentHistogram = macd.histogram.length > 0 ? (macd.histogram[macd.histogram.length - 1] ?? 0) : 0;

  const handleExportCSV = () => {
    if (candles.length === 0) return;
    const indicatorCols = [
      { name: 'EMA20', values: ema20 },
      { name: 'SMA50', values: sma50 },
      { name: 'RSI14', values: rsi14 },
      { name: 'MACD', values: macd.macdLine },
      { name: 'MACD_Signal', values: macd.signalLine },
      { name: 'MACD_Hist', values: macd.histogram }
    ];
    exportStockDataToCSV(selectedSymbol, candles, indicatorCols);
  };

  // Chart coordinate math
  const minPrice = useMemo(() => {
    if (candles.length === 0) return 0;
    const lows = candles.map(c => c.low);
    return Math.min(...lows) * 0.995;
  }, [candles]);

  const maxPrice = useMemo(() => {
    if (candles.length === 0) return 100;
    const highs = candles.map(c => c.high);
    return Math.max(...highs) * 1.005;
  }, [candles]);

  const maxVolume = useMemo(() => {
    if (candles.length === 0) return 1;
    return Math.max(...candles.map(c => c.volume));
  }, [candles]);

  const svgWidth = 900;
  const svgHeight = 280;
  const volHeight = 70;

  const getYCoord = (price: number) => {
    if (maxPrice === minPrice) return svgHeight / 2;
    return svgHeight - ((price - minPrice) / (maxPrice - minPrice)) * (svgHeight - 20) - 10;
  };

  const getVolYCoord = (vol: number) => {
    return (vol / maxVolume) * volHeight;
  };

  const isPositiveDay = currentStock.changePercent >= 0;

  return (
    <div className="flex flex-col gap-5 pb-12 select-none">
      {/* Top Header & Stock Switcher */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="font-mono text-[10px] text-[#87929a] uppercase tracking-wider">
              Terminal Core
            </span>
            <span className="text-[#3e484f] text-[10px]">/</span>
            <span className="font-mono text-[10px] text-[#38bdf8] font-semibold uppercase tracking-wider">
              Stock Analysis
            </span>
            <span className="font-mono text-[9px] px-1.5 py-0.2 rounded bg-[#122131] border border-[#1c2b3c] text-[#8ed5ff]">
              {currentStock.exchange} EQUITIES
            </span>
          </div>

          <div className="flex flex-wrap items-baseline gap-3">
            <h1 className="text-xl sm:text-2xl font-bold text-[#d4e4fa] tracking-tight">
              {currentStock.symbol}
            </h1>
            <span className="text-xs text-[#87929a] font-medium truncate">
              {currentStock.name} • {currentStock.sector}
            </span>
          </div>
        </div>

        {/* Quick Stock Selector Buttons */}
        <div className="flex flex-wrap items-center gap-1.5">
          {primaryStocks.map((sym) => (
            <button
              key={sym}
              onClick={() => onSelectSymbol(sym)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-all ${
                selectedSymbol === sym
                  ? 'bg-[#38bdf8] text-[#00354a] font-bold shadow-md shadow-[#38bdf8]/20'
                  : 'bg-[#0d1c2d] hover:bg-[#122131] border border-[#1c2b3c] text-[#87929a] hover:text-[#d4e4fa]'
              }`}
            >
              {sym}
            </button>
          ))}
          <button
            onClick={() => onNavigateToPredictions(selectedSymbol)}
            className="px-3.5 py-1.5 rounded-lg bg-[#3131c0]/40 hover:bg-[#3131c0]/60 border border-[#c0c1ff]/30 text-[#c0c1ff] text-xs font-mono font-semibold flex items-center gap-1 transition-all"
          >
            <Zap className="w-3.5 h-3.5 text-[#38bdf8]" />
            <span>Run AI Prediction</span>
          </button>
        </div>
      </div>

      {/* SECTION 1: Key Quote Metrics Cards Strip */}
      <section className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* CMP */}
        <div className="p-3 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] flex flex-col justify-between">
          <span className="font-mono text-[10px] uppercase text-[#87929a]">Current Price (CMP)</span>
          <div className="my-1">
            <div className="font-mono text-xl sm:text-2xl font-bold text-[#d4e4fa] tracking-tight">
              ₹{currentStock.ltp.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </div>
            <div className={`flex items-center gap-0.5 font-mono text-xs font-semibold ${
              isPositiveDay ? 'text-[#56e5a9]' : 'text-[#ffb4ab]'
            }`}>
              {isPositiveDay ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
              <span>{isPositiveDay ? '+' : ''}{currentStock.change.toFixed(2)} ({isPositiveDay ? '+' : ''}{currentStock.changePercent.toFixed(2)}%)</span>
            </div>
          </div>
          <span className="font-mono text-[9px] text-[#87929a]">15:30 IST Snapshot</span>
        </div>

        {/* Day Range */}
        <div className="p-3 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] flex flex-col justify-between">
          <span className="font-mono text-[10px] uppercase text-[#87929a]">Day's High / Low</span>
          <div className="my-1">
            <div className="font-mono text-xs font-bold text-[#d4e4fa]">
              ₹{currentStock.high.toFixed(2)} / ₹{currentStock.low.toFixed(2)}
            </div>
            <div className="w-full h-1.5 rounded-full bg-[#1c2b3c] relative overflow-hidden mt-1.5">
              <div 
                className="absolute left-0 top-0 bottom-0 bg-[#38bdf8] rounded-full" 
                style={{ width: `${((currentStock.ltp - currentStock.low) / (currentStock.high - currentStock.low || 1)) * 100}%` }}
              />
            </div>
          </div>
          <div className="flex justify-between font-mono text-[9px] text-[#87929a]">
            <span>L: ₹{currentStock.low.toFixed(0)}</span>
            <span>H: ₹{currentStock.high.toFixed(0)}</span>
          </div>
        </div>

        {/* Open & Prev Close */}
        <div className="p-3 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] flex flex-col justify-between">
          <span className="font-mono text-[10px] uppercase text-[#87929a]">Open Price</span>
          <div className="my-1">
            <div className="font-mono text-base font-bold text-[#d4e4fa]">
              ₹{currentStock.open.toFixed(2)}
            </div>
            <span className="font-mono text-[10px] text-[#87929a]">
              Prev: ₹{currentStock.prevClose.toFixed(2)}
            </span>
          </div>
          <span className="font-mono text-[9px] text-[#38bdf8]">
            Gap: {currentStock.open > currentStock.prevClose ? '+' : ''}{(currentStock.open - currentStock.prevClose).toFixed(2)}
          </span>
        </div>

        {/* Day Volume */}
        <div className="p-3 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] flex flex-col justify-between">
          <span className="font-mono text-[10px] uppercase text-[#87929a]">Day Volume</span>
          <div className="my-1">
            <div className="font-mono text-base font-bold text-[#d4e4fa]">
              {(currentStock.volume / 1000000).toFixed(2)}M
            </div>
            <span className="font-mono text-[10px] text-[#56e5a9]">
              {(currentStock.volume / currentStock.avgVolume20D).toFixed(2)}x 20D Avg
            </span>
          </div>
          <span className="font-mono text-[9px] text-[#87929a]">
            20D Avg: {(currentStock.avgVolume20D / 1000000).toFixed(2)}M
          </span>
        </div>

        {/* VWAP */}
        <div className="p-3 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] flex flex-col justify-between">
          <span className="font-mono text-[10px] uppercase text-[#87929a]">VWAP (Est.)</span>
          <div className="my-1">
            <div className="font-mono text-base font-bold text-[#d4e4fa]">
              ₹{currentStock.vwap.toFixed(2)}
            </div>
            <span className={`font-mono text-[10px] ${currentStock.ltp >= currentStock.vwap ? 'text-[#56e5a9]' : 'text-[#ffb4ab]'}`}>
              {currentStock.ltp >= currentStock.vwap ? '+₹' : '-₹'}{Math.abs(currentStock.ltp - currentStock.vwap).toFixed(2)} Spread
            </span>
          </div>
          <span className="font-mono text-[9px] text-[#87929a]">Institutional Benchmark</span>
        </div>

        {/* AI Signal Score */}
        <div className="p-3 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] flex flex-col justify-between">
          <span className="font-mono text-[10px] uppercase text-[#87929a]">AI Signal Pulse</span>
          <div className="my-1">
            <div className={`font-mono text-base font-bold ${
              currentStock.aiSignal === 'Strong Buy' || currentStock.aiSignal === 'Bullish'
                ? 'text-[#56e5a9]'
                : currentStock.aiSignal === 'Bearish'
                ? 'text-[#ffb4ab]'
                : 'text-[#8ed5ff]'
            }`}>
              {currentStock.aiSignal.toUpperCase()}
            </div>
            <span className="font-mono text-[10px] text-[#38bdf8]">
              {currentStock.aiConfidence}% Backtest Acc.
            </span>
          </div>
          <span className="font-mono text-[9px] text-[#87929a]">
            Horizon: T+5 Target
          </span>
        </div>
      </section>

      {/* SECTION 2: Main Interactive Price Chart & Volume Histogram */}
      <section className="rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] shadow-md overflow-hidden flex flex-col">
        {/* Chart Toolbar Controls */}
        <div className="p-3.5 bg-[#0d1c2d] border-b border-[#1c2b3c] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Timeframe Controls */}
          <div className="flex items-center gap-2">
            <div className="flex items-center p-0.5 rounded-lg bg-[#122131] border border-[#1c2b3c]">
              {(['1D', '5D', '1M', '3M', '6M', '1Y'] as Timeframe[]).map((tf) => (
                <button
                  key={tf}
                  onClick={() => setTimeframe(tf)}
                  className={`px-2.5 py-1 rounded text-xs font-mono font-medium transition-colors ${
                    timeframe === tf
                      ? 'bg-[#38bdf8] text-[#00354a] font-bold shadow-sm'
                      : 'text-[#87929a] hover:text-[#d4e4fa]'
                  }`}
                >
                  {tf}
                </button>
              ))}
            </div>

            {/* Candles vs Line Switcher */}
            <div className="flex items-center p-0.5 rounded-lg bg-[#122131] border border-[#1c2b3c]">
              <button
                onClick={() => setChartType('candles')}
                className={`px-2.5 py-1 rounded text-xs font-mono font-medium transition-colors ${
                  chartType === 'candles'
                    ? 'bg-[#1c2b3c] text-[#8ed5ff] font-bold'
                    : 'text-[#87929a] hover:text-[#d4e4fa]'
                }`}
              >
                Candles
              </button>
              <button
                onClick={() => setChartType('line')}
                className={`px-2.5 py-1 rounded text-xs font-mono font-medium transition-colors ${
                  chartType === 'line'
                    ? 'bg-[#1c2b3c] text-[#8ed5ff] font-bold'
                    : 'text-[#87929a] hover:text-[#d4e4fa]'
                }`}
              >
                Line
              </button>
            </div>
          </div>

          {/* Overlays / Indicator Checkboxes */}
          <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
            <label className="flex items-center gap-1.5 cursor-pointer px-2.5 py-1 rounded bg-[#122131] hover:bg-[#1c2b3c] text-[#bdc8d1]">
              <input
                type="checkbox"
                checked={showEMA20}
                onChange={(e) => setShowEMA20(e.target.checked)}
                className="w-3.5 h-3.5 rounded bg-[#051424] text-[#38bdf8] accent-[#38bdf8]"
              />
              <span className="text-[#38bdf8]">20 EMA</span>
              {currentEMA && <span className="text-[10px] text-[#87929a]">(₹{currentEMA.toFixed(1)})</span>}
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer px-2.5 py-1 rounded bg-[#122131] hover:bg-[#1c2b3c] text-[#bdc8d1]">
              <input
                type="checkbox"
                checked={showSMA50}
                onChange={(e) => setShowSMA50(e.target.checked)}
                className="w-3.5 h-3.5 rounded bg-[#051424] text-[#f59e0b] accent-[#f59e0b]"
              />
              <span className="text-[#f59e0b]">50 SMA</span>
              {currentSMA && <span className="text-[10px] text-[#87929a]">(₹{currentSMA.toFixed(1)})</span>}
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer px-2.5 py-1 rounded bg-[#122131] hover:bg-[#1c2b3c] text-[#bdc8d1]">
              <input
                type="checkbox"
                checked={showBollinger}
                onChange={(e) => setShowBollinger(e.target.checked)}
                className="w-3.5 h-3.5 rounded bg-[#051424] text-[#c0c1ff] accent-[#c0c1ff]"
              />
              <span className="text-[#c0c1ff]">Bollinger</span>
            </label>

            <button
              onClick={handleExportCSV}
              className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-[#122131] hover:bg-[#1c2b3c] border border-[#1c2b3c] text-[#8ed5ff] text-xs font-mono transition-colors"
              title="Download historical OHLCV and technical indicators as CSV"
            >
              <Download className="w-3.5 h-3.5 text-[#38bdf8]" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* Hover Crosshair Telemetry Bar */}
        <div className="px-4 py-2 bg-[#010f1f] border-b border-[#1c2b3c] flex flex-wrap items-center gap-4 text-xs font-mono text-[#87929a]">
          {hoveredCandle ? (
            <>
              <div>
                DATE: <span className="text-[#d4e4fa] font-bold">{hoveredCandle.date}</span>
              </div>
              <div>
                O: <span className="text-[#d4e4fa]">₹{hoveredCandle.open.toFixed(2)}</span>
              </div>
              <div>
                H: <span className="text-[#56e5a9]">₹{hoveredCandle.high.toFixed(2)}</span>
              </div>
              <div>
                L: <span className="text-[#ffb4ab]">₹{hoveredCandle.low.toFixed(2)}</span>
              </div>
              <div>
                C: <span className="text-[#d4e4fa] font-bold">₹{hoveredCandle.close.toFixed(2)}</span>
              </div>
              <div>
                VOL: <span className="text-[#38bdf8]">{(hoveredCandle.volume / 1000000).toFixed(2)}M</span>
              </div>
            </>
          ) : (
            <div className="text-[11px] text-[#87929a] italic">
              Hover over candlestick or price chart to inspect discrete session OHLCV vector data
            </div>
          )}
        </div>

        {/* SVG Drawing Canvas */}
        <div className="relative w-full bg-[#010f1f] p-4 overflow-hidden">
          {isLoading ? (
            <div className="h-72 flex items-center justify-center text-xs font-mono text-[#87929a]">
              Computing rolling indicators and rendering candles...
            </div>
          ) : candles.length === 0 ? (
            <div className="h-72 flex items-center justify-center text-xs font-mono text-[#ffb4ab]">
              No historical data available for selected timeframe
            </div>
          ) : (
            <div className="flex flex-col gap-2">
              {/* Main Price Canvas */}
              <div className="w-full h-64 sm:h-72 relative">
                <svg
                  className="w-full h-full overflow-visible"
                  viewBox={`0 0 ${svgWidth} ${svgHeight}`}
                  preserveAspectRatio="none"
                >
                  <defs>
                    <linearGradient id="lineGrad" x1="0" x2="0" y1="0" y2="1">
                      <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.25" />
                      <stop offset="100%" stopColor="#38bdf8" stopOpacity="0.0" />
                    </linearGradient>
                  </defs>

                  {/* Horizontal grid lines */}
                  {[0.25, 0.5, 0.75].map((pct, i) => {
                    const priceLevel = minPrice + (maxPrice - minPrice) * (1 - pct);
                    const y = svgHeight * pct;
                    return (
                      <g key={i}>
                        <line x1="0" y1={y} x2={svgWidth} y2={y} stroke="#1c2b3c" strokeDasharray="3 3" strokeWidth="0.75" />
                        <text x={svgWidth - 5} y={y - 4} fill="#87929a" fontSize="9" fontFamily="JetBrains Mono" textAnchor="end">
                          ₹{priceLevel.toFixed(1)}
                        </text>
                      </g>
                    );
                  })}

                  {/* Bollinger Upper & Lower bands */}
                  {showBollinger && bollinger.upper.length > 0 && (
                    <>
                      <path
                        d={bollinger.upper
                          .map((val, idx) => {
                            if (val === null) return '';
                            const x = (idx / (candles.length - 1 || 1)) * svgWidth;
                            const y = getYCoord(val);
                            return `${idx === 20 ? 'M' : 'L'} ${x} ${y}`;
                          })
                          .filter(Boolean)
                          .join(' ')}
                        fill="none"
                        stroke="#c0c1ff"
                        strokeWidth="1"
                        strokeDasharray="2 2"
                        opacity="0.65"
                      />
                      <path
                        d={bollinger.lower
                          .map((val, idx) => {
                            if (val === null) return '';
                            const x = (idx / (candles.length - 1 || 1)) * svgWidth;
                            const y = getYCoord(val);
                            return `${idx === 20 ? 'M' : 'L'} ${x} ${y}`;
                          })
                          .filter(Boolean)
                          .join(' ')}
                        fill="none"
                        stroke="#c0c1ff"
                        strokeWidth="1"
                        strokeDasharray="2 2"
                        opacity="0.65"
                      />
                    </>
                  )}

                  {/* 50 SMA Curve */}
                  {showSMA50 && sma50.length > 0 && (
                    <path
                      d={sma50
                        .map((val, idx) => {
                          if (val === null) return '';
                          const x = (idx / (candles.length - 1 || 1)) * svgWidth;
                          const y = getYCoord(val);
                          return `${idx === 50 ? 'M' : 'L'} ${x} ${y}`;
                        })
                        .filter(Boolean)
                        .join(' ')}
                      fill="none"
                      stroke="#f59e0b"
                      strokeWidth="1.5"
                      strokeDasharray="3 2"
                      opacity="0.85"
                    />
                  )}

                  {/* 20 EMA Curve */}
                  {showEMA20 && ema20.length > 0 && (
                    <path
                      d={ema20
                        .map((val, idx) => {
                          if (val === null) return '';
                          const x = (idx / (candles.length - 1 || 1)) * svgWidth;
                          const y = getYCoord(val);
                          return `${idx === 20 ? 'M' : 'L'} ${x} ${y}`;
                        })
                        .filter(Boolean)
                        .join(' ')}
                      fill="none"
                      stroke="#38bdf8"
                      strokeWidth="1.75"
                      strokeLinecap="round"
                    />
                  )}

                  {/* Candlesticks or Line */}
                  {chartType === 'line' ? (
                    <>
                      <path
                        d={candles
                          .map((c, idx) => {
                            const x = (idx / (candles.length - 1 || 1)) * svgWidth;
                            const y = getYCoord(c.close);
                            return `${idx === 0 ? 'M' : 'L'} ${x} ${y}`;
                          })
                          .join(' ') + ` L ${svgWidth} ${svgHeight} L 0 ${svgHeight} Z`}
                        fill="url(#lineGrad)"
                      />
                      <path
                        d={candles
                          .map((c, idx) => {
                            const x = (idx / (candles.length - 1 || 1)) * svgWidth;
                            const y = getYCoord(c.close);
                            return `${idx === 0 ? 'M' : 'L'} ${x} ${y}`;
                          })
                          .join(' ')}
                        fill="none"
                        stroke="#56e5a9"
                        strokeWidth="2"
                        strokeLinecap="round"
                      />
                    </>
                  ) : (
                    candles.map((c, idx) => {
                      const x = (idx / (candles.length - 1 || 1)) * svgWidth;
                      const candleWidth = Math.max(2, Math.min(10, (svgWidth / candles.length) * 0.7));
                      const isUp = c.close >= c.open;
                      const color = isUp ? '#56e5a9' : '#ffb4ab';

                      const yOpen = getYCoord(c.open);
                      const yClose = getYCoord(c.close);
                      const yHigh = getYCoord(c.high);
                      const yLow = getYCoord(c.low);

                      const bodyTop = Math.min(yOpen, yClose);
                      const bodyHeight = Math.max(1.5, Math.abs(yClose - yOpen));

                      return (
                        <g
                          key={c.date}
                          onMouseEnter={() => setHoveredCandle(c)}
                          className="cursor-pointer group"
                        >
                          {/* Wick */}
                          <line
                            x1={x}
                            y1={yHigh}
                            x2={x}
                            y2={yLow}
                            stroke={color}
                            strokeWidth="1"
                          />
                          {/* Body */}
                          <rect
                            x={x - candleWidth / 2}
                            y={bodyTop}
                            width={candleWidth}
                            height={bodyHeight}
                            fill={color}
                            rx="0.5"
                          />
                        </g>
                      );
                    })
                  )}
                </svg>
              </div>

              {/* Volume Histogram */}
              <div className="w-full h-16 pt-1 border-t border-[#1c2b3c]/60">
                <div className="flex items-center justify-between text-[9px] font-mono text-[#87929a] pb-1">
                  <span>SESSION VOLUME HISTOGRAM</span>
                  <span>MAX: {(maxVolume / 1000000).toFixed(2)}M</span>
                </div>
                <div className="w-full h-10 flex items-end justify-between gap-[2px]">
                  {candles.map((c, idx) => {
                    const isUp = c.close >= c.open;
                    const heightPct = Math.max(5, (c.volume / maxVolume) * 100);
                    return (
                      <div
                        key={c.date}
                        className={`flex-1 rounded-t-[1px] transition-all hover:brightness-125 ${
                          isUp ? 'bg-[#56e5a9]/50' : 'bg-[#ffb4ab]/50'
                        }`}
                        style={{ height: `${heightPct}%` }}
                        onMouseEnter={() => setHoveredCandle(c)}
                        title={`${c.date}: ${(c.volume / 1000000).toFixed(2)}M shares`}
                      />
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>
      </section>

      {/* SECTION 3: Calculated Oscillators & Technical Factors */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Relative Strength Index (RSI 14) Panel (6 cols) */}
        <div className="lg:col-span-6 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] p-4 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between pb-2 border-b border-[#1c2b3c]">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xs font-bold text-[#d4e4fa] uppercase tracking-wider">
                  Relative Strength Index (RSI 14)
                </h3>
                <span className="font-mono text-[9px] px-1.5 py-0.2 rounded bg-[#122131] text-[#38bdf8]">
                  WILDER'S FORMULA
                </span>
              </div>
              <p className="text-[11px] text-[#87929a] mt-0.5">
                Evaluates magnitude of recent price changes to evaluate overbought or oversold conditions.
              </p>
            </div>

            <div className="text-right">
              <span className="font-mono text-xl font-bold text-[#38bdf8]">
                {currentRSI ? currentRSI.toFixed(1) : '50.0'}
              </span>
              <span className={`block font-mono text-[9px] font-semibold ${
                currentRSI && currentRSI > 70
                  ? 'text-[#ffb4ab]'
                  : currentRSI && currentRSI < 30
                  ? 'text-[#56e5a9]'
                  : 'text-[#8ed5ff]'
              }`}>
                {currentRSI && currentRSI > 70
                  ? 'Overbought (>70)'
                  : currentRSI && currentRSI < 30
                  ? 'Oversold (<30)'
                  : 'Bullish Zone (50-70)'}
              </span>
            </div>
          </div>

          {/* RSI SVG Oscillator Curve */}
          <div className="h-28 w-full my-3 bg-[#010f1f] rounded-lg p-2 relative">
            <svg className="w-full h-full overflow-visible" viewBox="0 0 400 90" preserveAspectRatio="none">
              <line x1="0" y1="25" x2="400" y2="25" stroke="#ffb4ab" strokeDasharray="3 3" strokeWidth="0.75" />
              <text x="395" y="21" fill="#ffb4ab" fontSize="8" fontFamily="JetBrains Mono" textAnchor="end">
                70 Overbought
              </text>

              <line x1="0" y1="45" x2="400" y2="45" stroke="#1c2b3c" strokeDasharray="2 2" strokeWidth="0.75" />
              <text x="395" y="42" fill="#87929a" fontSize="8" fontFamily="JetBrains Mono" textAnchor="end">
                50 Neutral
              </text>

              <line x1="0" y1="65" x2="400" y2="65" stroke="#56e5a9" strokeDasharray="3 3" strokeWidth="0.75" />
              <text x="395" y="62" fill="#56e5a9" fontSize="8" fontFamily="JetBrains Mono" textAnchor="end">
                30 Oversold
              </text>

              {rsi14.length > 0 && (
                <path
                  d={rsi14
                    .map((val, idx) => {
                      if (val === null) return '';
                      const x = (idx / (rsi14.length - 1 || 1)) * 400;
                      const y = 85 - (val / 100) * 80;
                      return `${idx === 14 ? 'M' : 'L'} ${x} ${y}`;
                    })
                    .filter(Boolean)
                    .join(' ')}
                  fill="none"
                  stroke="#38bdf8"
                  strokeWidth="2"
                  strokeLinecap="round"
                />
              )}
            </svg>
          </div>

          <div className="flex items-center justify-between text-[10px] font-mono text-[#87929a]">
            <span>14-Session Exponential Smoothing</span>
            <span className="text-[#56e5a9]">Wilder RS Smoothing</span>
          </div>
        </div>

        {/* Moving Average Convergence Divergence (MACD 12, 26, 9) (6 cols) */}
        <div className="lg:col-span-6 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] p-4 flex flex-col justify-between shadow-sm">
          <div className="flex items-center justify-between pb-2 border-b border-[#1c2b3c]">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xs font-bold text-[#d4e4fa] uppercase tracking-wider">
                  MACD Oscillator (12, 26, 9)
                </h3>
                <span className="font-mono text-[9px] px-1.5 py-0.2 rounded bg-[#122131] text-[#38bdf8]">
                  MOMENTUM
                </span>
              </div>
              <p className="text-[11px] text-[#87929a] mt-0.5">
                Exponential trend-following momentum oscillator derived from 12 and 26-period EMAs.
              </p>
            </div>

            <div className="text-right">
              <span className={`font-mono text-xl font-bold ${currentHistogram >= 0 ? 'text-[#56e5a9]' : 'text-[#ffb4ab]'}`}>
                {currentHistogram >= 0 ? '+' : ''}{currentHistogram.toFixed(2)}
              </span>
              <span className="block font-mono text-[9px] text-[#87929a]">
                MACD: {currentMACD.toFixed(2)} • Sig: {currentSignal.toFixed(2)}
              </span>
            </div>
          </div>

          {/* MACD SVG Graphic */}
          <div className="h-28 w-full my-3 bg-[#010f1f] rounded-lg p-2 relative">
            <svg className="w-full h-full overflow-visible" viewBox="0 0 400 90" preserveAspectRatio="none">
              {/* Zero baseline */}
              <line x1="0" y1="45" x2="400" y2="45" stroke="#1c2b3c" strokeWidth="1" strokeDasharray="2 2" />
              <text x="395" y="43" fill="#87929a" fontSize="8" fontFamily="JetBrains Mono" textAnchor="end">
                0 Baseline
              </text>

              {/* Histogram bars */}
              {macd.histogram.map((val, idx) => {
                if (val === null) return null;
                const barWidth = Math.max(2, 380 / (macd.histogram.length || 1) - 1);
                const x = 10 + (idx / (macd.histogram.length - 1 || 1)) * 380;
                const scaledHeight = Math.min(38, Math.abs(val) * 6);
                const y = val >= 0 ? 45 - scaledHeight : 45;
                return (
                  <rect
                    key={idx}
                    x={x}
                    y={y}
                    width={barWidth}
                    height={Math.max(1, scaledHeight)}
                    fill={val >= 0 ? '#56e5a9' : '#ffb4ab'}
                    opacity="0.75"
                  />
                );
              })}

              {/* MACD Line (Cyan) */}
              {macd.macdLine.length > 0 && (
                <path
                  d={macd.macdLine
                    .map((val, idx) => {
                      if (val === null) return '';
                      const x = 10 + (idx / (macd.macdLine.length - 1 || 1)) * 380;
                      const y = 45 - Math.max(-40, Math.min(40, val * 3));
                      return `${idx === 25 ? 'M' : 'L'} ${x} ${y}`;
                    })
                    .filter(Boolean)
                    .join(' ')}
                  fill="none"
                  stroke="#38bdf8"
                  strokeWidth="1.75"
                  strokeLinecap="round"
                />
              )}

              {/* Signal Line (Orange) */}
              {macd.signalLine.length > 0 && (
                <path
                  d={macd.signalLine
                    .map((val, idx) => {
                      if (val === null) return '';
                      const x = 10 + (idx / (macd.signalLine.length - 1 || 1)) * 380;
                      const y = 45 - Math.max(-40, Math.min(40, val * 3));
                      return `${idx === 33 ? 'M' : 'L'} ${x} ${y}`;
                    })
                    .filter(Boolean)
                    .join(' ')}
                  fill="none"
                  stroke="#f59e0b"
                  strokeWidth="1.5"
                  strokeDasharray="3 2"
                  strokeLinecap="round"
                />
              )}
            </svg>
          </div>

          <div className="flex items-center justify-between text-[10px] font-mono text-[#87929a]">
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1">
                <span className="w-2 h-0.5 bg-[#38bdf8] inline-block"></span> MACD (12, 26)
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-0.5 bg-[#f59e0b] inline-block"></span> Signal (9)
              </span>
            </div>
            <span className={currentHistogram >= 0 ? 'text-[#56e5a9]' : 'text-[#ffb4ab]'}>
              {currentHistogram >= 0 ? 'Bullish Histogram' : 'Bearish Histogram'}
            </span>
          </div>
        </div>

        {/* Support, Resistance & Pivot Points (12 cols) */}
        <div className="lg:col-span-12 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] p-4 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between pb-2 border-b border-[#1c2b3c]">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xs font-bold text-[#d4e4fa] uppercase tracking-wider">
                  Algorithmic Key Support & Resistance (Pivot Floor Matrix)
                </h3>
                <span className="font-mono text-[9px] px-1.5 py-0.2 rounded bg-[#122131] text-[#56e5a9]">
                  SYNCHRONIZED
                </span>
              </div>
              <p className="text-[11px] text-[#87929a] mt-0.5">
                Classical floor trader pivot matrix derived from previous session high, low, and closing values.
              </p>
            </div>

            <div className="text-right">
              <span className="font-mono text-base font-bold text-[#d4e4fa]">
                ₹{pivotPoints.pp.toFixed(2)}
              </span>
              <span className="block font-mono text-[9px] text-[#87929a]">Central Pivot (PP)</span>
            </div>
          </div>

          {/* Pivot Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 my-3">
            <div className="p-2.5 rounded-lg bg-[#122131] border border-[#1c2b3c] text-center">
              <span className="font-mono text-[9px] text-[#ffb4ab] block">R2 (Major Resistance)</span>
              <span className="font-mono text-xs font-bold text-[#d4e4fa] mt-1 block">
                ₹{pivotPoints.r2.toFixed(2)}
              </span>
            </div>
            <div className="p-2.5 rounded-lg bg-[#122131] border border-[#1c2b3c] text-center">
              <span className="font-mono text-[9px] text-[#f59e0b] block">R1 (Minor Resistance)</span>
              <span className="font-mono text-xs font-bold text-[#d4e4fa] mt-1 block">
                ₹{pivotPoints.r1.toFixed(2)}
              </span>
            </div>
            <div className="p-2.5 rounded-lg bg-[#122131] border border-[#1c2b3c] text-center">
              <span className="font-mono text-[9px] text-[#38bdf8] block">S1 (Minor Support)</span>
              <span className="font-mono text-xs font-bold text-[#d4e4fa] mt-1 block">
                ₹{pivotPoints.s1.toFixed(2)}
              </span>
            </div>
            <div className="p-2.5 rounded-lg bg-[#122131] border border-[#1c2b3c] text-center">
              <span className="font-mono text-[9px] text-[#56e5a9] block">S2 (Demand Floor)</span>
              <span className="font-mono text-xs font-bold text-[#d4e4fa] mt-1 block">
                ₹{pivotPoints.s2.toFixed(2)}
              </span>
            </div>
          </div>

          <div className="flex items-center justify-between text-[10px] font-mono text-[#87929a]">
            <span>Regime: {currentStock.ltp >= pivotPoints.pp ? 'Above Pivot (Bullish Bias)' : 'Below Pivot (Bearish Bias)'}</span>
            <span className="text-[#38bdf8]">CMP is {currentStock.ltp >= pivotPoints.pp ? '+' : ''}₹{(currentStock.ltp - pivotPoints.pp).toFixed(2)} relative to PP</span>
          </div>
        </div>
      </div>

      {/* SECTION 3.5: Quantitative Risk Profile & Value-at-Risk (VaR) */}
      <section className="rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] p-4 shadow-sm flex flex-col gap-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-[#1c2b3c]">
          <div>
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-[#38bdf8]" />
              <h3 className="text-xs font-bold text-[#d4e4fa] uppercase tracking-wider">
                Quantitative Risk Profile & Capital at Risk (VaR)
              </h3>
              <span className="font-mono text-[9px] px-1.5 py-0.2 rounded bg-[#122131] text-[#38bdf8]">
                CALCULATED FROM OHLCV
              </span>
            </div>
            <p className="text-[11px] text-[#87929a] mt-0.5">
              Empirical risk metrics computed from log daily returns series. Benchmark risk-free rate Rf = 6.85% (RBI 10Y G-Sec Yield).
            </p>
          </div>
          <span className="font-mono text-[10px] text-[#87929a]">
            252 Annualized Sessions • N={candles.length} Candles
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 font-mono">
          {/* Annualized Volatility */}
          <div className="p-3 rounded-lg bg-[#122131] border border-[#1c2b3c]">
            <span className="text-[9px] text-[#87929a] block">ANNUALIZED VOL (σ)</span>
            <span className="text-sm font-bold text-[#d4e4fa] mt-1 block">
              {riskMetrics.annualizedVolatility.toFixed(2)}%
            </span>
            <span className="text-[9px] text-[#87929a] block mt-0.5">Daily: {riskMetrics.dailyStdDev.toFixed(2)}%</span>
          </div>

          {/* Historical VaR 95% */}
          <div className="p-3 rounded-lg bg-[#122131] border border-[#1c2b3c]">
            <span className="text-[9px] text-[#ffb4ab] block">1-DAY VaR (95%)</span>
            <span className="text-sm font-bold text-[#ffb4ab] mt-1 block">
              {riskMetrics.var95.toFixed(2)}%
            </span>
            <span className="text-[9px] text-[#87929a] block mt-0.5">₹{(currentStock.ltp * Math.abs(riskMetrics.var95) / 100).toFixed(2)} capital</span>
          </div>

          {/* Conditional VaR 95% (CVaR) */}
          <div className="p-3 rounded-lg bg-[#122131] border border-[#1c2b3c]">
            <span className="text-[9px] text-[#ffb4ab] block">1-DAY CVaR (95%)</span>
            <span className="text-sm font-bold text-[#ffb4ab] mt-1 block">
              {riskMetrics.cvar95.toFixed(2)}%
            </span>
            <span className="text-[9px] text-[#87929a] block mt-0.5">Expected Shortfall</span>
          </div>

          {/* Max Drawdown */}
          <div className="p-3 rounded-lg bg-[#122131] border border-[#1c2b3c]">
            <span className="text-[9px] text-[#87929a] block">MAX DRAWDOWN (MDD)</span>
            <span className="text-sm font-bold text-[#ffb4ab] mt-1 block">
              {riskMetrics.maxDrawdown.toFixed(2)}%
            </span>
            <span className="text-[9px] text-[#87929a] block mt-0.5">Peak-to-Trough</span>
          </div>

          {/* Sharpe Ratio */}
          <div className="p-3 rounded-lg bg-[#122131] border border-[#1c2b3c]">
            <span className="text-[9px] text-[#38bdf8] block">SHARPE RATIO</span>
            <span className="text-sm font-bold text-[#38bdf8] mt-1 block">
              {riskMetrics.sharpeRatio.toFixed(2)}
            </span>
            <span className="text-[9px] text-[#87929a] block mt-0.5">Rf = 6.85% (RBI)</span>
          </div>

          {/* Sortino Ratio */}
          <div className="p-3 rounded-lg bg-[#122131] border border-[#1c2b3c]">
            <span className="text-[9px] text-[#56e5a9] block">SORTINO RATIO</span>
            <span className="text-sm font-bold text-[#56e5a9] mt-1 block">
              {riskMetrics.sortinoRatio.toFixed(2)}
            </span>
            <span className="text-[9px] text-[#87929a] block mt-0.5">Downside Vol Adjusted</span>
          </div>
        </div>
      </section>

      {/* SECTION 4: Fundamental & Quantitative Factor Matrix */}
      <section className="rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] p-4 shadow-sm flex flex-col gap-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-[#1c2b3c]">
          <div>
            <h3 className="text-xs font-bold text-[#d4e4fa] uppercase tracking-wider">
              Fundamental & Quantitative Factor Matrix
            </h3>
            <p className="text-[11px] text-[#87929a]">
              Key valuation ratios, institutional liquidity depth, and annual price boundaries.
            </p>
          </div>
          <span className="font-mono text-[10px] text-[#87929a]">
            Consolidated TTM Data • Q2 FY25
          </span>
        </div>

        {/* 52-Week Range Spectrum Slider */}
        <div className="p-3 rounded-lg bg-[#122131] border border-[#1c2b3c]">
          <div className="flex items-center justify-between font-mono text-xs mb-1.5">
            <span className="text-[#ffb4ab]">52W Low: ₹{currentStock.week52Low.toFixed(2)}</span>
            <span className="text-[#8ed5ff] font-bold">
              CMP: ₹{currentStock.ltp.toFixed(2)} (
              {(((currentStock.ltp - currentStock.week52Low) / (currentStock.week52High - currentStock.week52Low)) * 100).toFixed(0)}% of Range)
            </span>
            <span className="text-[#56e5a9]">52W High: ₹{currentStock.week52High.toFixed(2)}</span>
          </div>
          <div className="w-full h-2 rounded-full bg-[#051424] relative overflow-hidden">
            <div
              className="absolute left-0 top-0 bottom-0 bg-gradient-to-r from-[#ffb4ab] via-[#38bdf8] to-[#56e5a9] rounded-full"
              style={{
                width: `${Math.min(100, Math.max(0, ((currentStock.ltp - currentStock.week52Low) / (currentStock.week52High - currentStock.week52Low)) * 100))}%`
              }}
            />
          </div>
        </div>

        {/* Fundamental Multiples Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 font-mono">
          <div className="p-2.5 rounded-lg bg-[#122131] border border-[#1c2b3c]">
            <span className="text-[9px] text-[#87929a] block">MARKET CAP</span>
            <span className="text-xs font-bold text-[#d4e4fa] mt-0.5 block">
              ₹{(currentStock.marketCap / 1000).toFixed(2)}T
            </span>
          </div>
          <div className="p-2.5 rounded-lg bg-[#122131] border border-[#1c2b3c]">
            <span className="text-[9px] text-[#87929a] block">BETA (1Y)</span>
            <span className="text-xs font-bold text-[#38bdf8] mt-0.5 block">
              {currentStock.beta1Y}
            </span>
          </div>
          <div className="p-2.5 rounded-lg bg-[#122131] border border-[#1c2b3c]">
            <span className="text-[9px] text-[#87929a] block">P/E RATIO</span>
            <span className="text-xs font-bold text-[#d4e4fa] mt-0.5 block">
              {currentStock.peRatio}x
            </span>
          </div>
          <div className="p-2.5 rounded-lg bg-[#122131] border border-[#1c2b3c]">
            <span className="text-[9px] text-[#87929a] block">SECTOR P/E</span>
            <span className="text-xs font-bold text-[#87929a] mt-0.5 block">
              {currentStock.sectorPE}x
            </span>
          </div>
          <div className="p-2.5 rounded-lg bg-[#122131] border border-[#1c2b3c]">
            <span className="text-[9px] text-[#87929a] block">P/B RATIO</span>
            <span className="text-xs font-bold text-[#d4e4fa] mt-0.5 block">
              {currentStock.priceToBook}x
            </span>
          </div>
          <div className="p-2.5 rounded-lg bg-[#122131] border border-[#1c2b3c]">
            <span className="text-[9px] text-[#87929a] block">EPS (TTM)</span>
            <span className="text-xs font-bold text-[#56e5a9] mt-0.5 block">
              ₹{currentStock.epsTTM.toFixed(1)}
            </span>
          </div>
          <div className="p-2.5 rounded-lg bg-[#122131] border border-[#1c2b3c]">
            <span className="text-[9px] text-[#87929a] block">DIVIDEND</span>
            <span className="text-xs font-bold text-[#d4e4fa] mt-0.5 block">
              {currentStock.dividendYield}%
            </span>
          </div>
          <div className="p-2.5 rounded-lg bg-[#122131] border border-[#1c2b3c]">
            <span className="text-[9px] text-[#87929a] block">DELIVERY %</span>
            <span className="text-xs font-bold text-[#38bdf8] mt-0.5 block">
              {currentStock.deliveryPercent}%
            </span>
          </div>
        </div>
      </section>

      {/* Academic Disclaimer */}
      <AcademicDisclaimer />
    </div>
  );
};
