import React from 'react';
import { AlertTriangle, GraduationCap, ShieldCheck } from 'lucide-react';
import { DATA_METADATA } from '../../services/dataService';

interface AcademicDisclaimerProps {
  compact?: boolean;
}

export const AcademicDisclaimer: React.FC<AcademicDisclaimerProps> = ({ compact = false }) => {
  if (compact) {
    return (
      <div className="flex items-center justify-between px-3 py-1.5 rounded-lg bg-[#0d1c2d] border border-[#1c2b3c] text-[11px] text-[#87929a]">
        <div className="flex items-center gap-1.5">
          <GraduationCap className="w-3.5 h-3.5 text-[#38bdf8]" />
          <span className="font-semibold text-[#8ed5ff]">ACADEMIC SANDBOX</span>
          <span className="text-[#3e484f]">•</span>
          <span>B.Tech AI & ML Capstone Research Project</span>
        </div>
        <span className="font-mono text-[10px] text-[#f59e0b] px-1.5 py-0.5 rounded bg-[#f59e0b]/10 border border-[#f59e0b]/20">
          Demo Dataset ({DATA_METADATA.lastUpdated})
        </span>
      </div>
    );
  }

  return (
    <div className="p-3.5 rounded-lg bg-[#010f1f] border border-[#1c2b3c] flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs text-[#87929a]">
      <div className="flex items-start gap-2.5 max-w-4xl">
        <ShieldCheck className="w-4 h-4 text-[#38bdf8] shrink-0 mt-0.5" />
        <p className="leading-relaxed">
          <strong className="text-[#d4e4fa] font-semibold">Academic Notice & Regulatory Exemption:</strong>{' '}
          The <span className="text-[#8ed5ff] font-medium">NSE-BSE Market Analyzer</span> is an educational capstone prototype built for algorithmic backtesting, technical indicator computation, and machine learning research demonstration. All prices and indicators originate from a fixed sample historical benchmark dataset (Oct 2024). This platform does not provide certified SEBI financial advisory, automated order execution, or guaranteed predictive alpha.
        </p>
      </div>
      <div className="flex items-center gap-2 font-mono text-[10px] shrink-0 text-[#87929a] self-end md:self-auto">
        <span className="px-2 py-0.5 rounded bg-[#122131] border border-[#1c2b3c] text-[#56e5a9]">
          Engine: Scikit-learn + Pandas
        </span>
        <span className="px-2 py-0.5 rounded bg-[#122131] border border-[#1c2b3c]">
          Terminal Node: ONLINE
        </span>
      </div>
    </div>
  );
};
