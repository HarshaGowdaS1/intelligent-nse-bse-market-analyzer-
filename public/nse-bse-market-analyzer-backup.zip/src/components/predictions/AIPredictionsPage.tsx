import React, { useState, useEffect } from 'react';
import { 
  BrainCircuit, 
  TrendingUp, 
  TrendingDown, 
  SlidersHorizontal, 
  CheckCircle2, 
  Info, 
  AlertTriangle, 
  ArrowRight,
  ShieldCheck,
  Zap,
  BarChart,
  Activity
} from 'lucide-react';
import { StockQuote, PredictionHorizon, ForecastResult } from '../../types/market';
import { SampleDataService, DATA_METADATA } from '../../services/dataService';
import { AcademicDisclaimer } from '../common/AcademicDisclaimer';

interface AIPredictionsPageProps {
  selectedSymbol: string;
  onSelectSymbol: (symbol: string) => void;
  allStocks: StockQuote[];
  onNavigateToAnalysis: (symbol: string) => void;
}

export const AIPredictionsPage: React.FC<AIPredictionsPageProps> = ({
  selectedSymbol,
  onSelectSymbol,
  allStocks,
  onNavigateToAnalysis
}) => {
  const [horizon, setHorizon] = useState<PredictionHorizon>('T+1');
  const [modelType, setModelType] = useState<'random-forest' | 'linear-ols' | 'ensemble'>('random-forest');
  const [forecast, setForecast] = useState<ForecastResult | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const primaryStocks = ['RELIANCE', 'TCS', 'HDFCBANK', 'INFY', 'SBIN', 'TATAMOTORS'];
  const currentStock = allStocks.find(s => s.symbol === selectedSymbol) || allStocks[0];

  useEffect(() => {
    let isMounted = true;
    setIsLoading(true);

    SampleDataService.getForecast(selectedSymbol, horizon)
      .then((res) => {
        if (isMounted) {
          setForecast(res);
          setIsLoading(false);
        }
      })
      .catch((err) => {
        console.error('Failed to load forecast', err);
        if (isMounted) setIsLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [selectedSymbol, horizon]);

  const isBullish = forecast ? forecast.projectedDelta >= 0 : true;

  // Chart coordinate computations
  const svgWidth = 800;
  const svgHeight = 240;

  const allPlotPrices = forecast
    ? [...forecast.historicalPrices, ...forecast.forecastUpperBands, ...forecast.forecastLowerBands]
    : [100];
  const minPrice = Math.min(...allPlotPrices) * 0.995;
  const maxPrice = Math.max(...allPlotPrices) * 1.005;

  const getY = (val: number) => {
    if (maxPrice === minPrice) return svgHeight / 2;
    return svgHeight - ((val - minPrice) / (maxPrice - minPrice)) * (svgHeight - 40) - 20;
  };

  const totalPoints = forecast
    ? forecast.historicalPrices.length + forecast.forecastPrices.length
    : 60;
  const histCount = forecast ? forecast.historicalPrices.length : 50;

  return (
    <div className="flex flex-col gap-5 pb-12 select-none">
      {/* Top Header & Ticker Switcher */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="font-mono text-[10px] text-[#87929a] uppercase tracking-wider">
              Terminal Core
            </span>
            <span className="text-[#3e484f] text-[10px]">/</span>
            <span className="font-mono text-[10px] text-[#38bdf8] font-semibold uppercase tracking-wider">
              AI Predictions
            </span>
            <span className="font-mono text-[9px] px-1.5 py-0.2 rounded bg-[#3131c0]/40 text-[#c0c1ff] border border-[#c0c1ff]/20">
              ACADEMIC CAPSTONE MODEL
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-[#d4e4fa] tracking-tight">
            Predictive Machine Learning Workbench
          </h1>
          <p className="text-xs text-[#bdc8d1] max-w-3xl mt-0.5">
            Supervised regression modeling, recursive multi-horizon projection, and Mean Decrease in Impurity (MDI) feature attribution pipeline across Indian equities.
          </p>
        </div>

        {/* Stock Selector Chips */}
        <div className="flex flex-wrap items-center gap-1.5">
          {primaryStocks.map((sym) => (
            <button
              key={sym}
              onClick={() => onSelectSymbol(sym)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-all ${
                selectedSymbol === sym
                  ? 'bg-[#38bdf8] text-[#00354a] font-bold shadow-md shadow-[#38bdf8]/20'
                  : 'bg-[#0d1c2d] hover:bg-[#122131] border border-[#1c2b3c] text-[#87929a] hover:text-[#d4e4fa]'
              }`}
            >
              {sym}
            </button>
          ))}
          <button
            onClick={() => onNavigateToAnalysis(selectedSymbol)}
            className="px-3 py-1.5 rounded-lg bg-[#122131] hover:bg-[#1c2b3c] border border-[#1c2b3c] text-[#8ed5ff] text-xs font-mono font-semibold transition-colors"
          >
            Open Chart
          </button>
        </div>
      </div>

      {/* SECTION 1: Control Ribbon & Pipeline Settings */}
      <section className="p-3.5 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Horizon Controls */}
        <div className="flex items-center gap-3">
          <span className="font-mono text-[10px] uppercase text-[#87929a] tracking-wider">
            Forecast Horizon:
          </span>
          <div className="flex items-center p-0.5 rounded-lg bg-[#122131] border border-[#1c2b3c]">
            {(['T+1', 'T+5', 'T+15'] as PredictionHorizon[]).map((h) => (
              <button
                key={h}
                onClick={() => setHorizon(h)}
                className={`px-3 py-1 rounded text-xs font-mono font-semibold transition-all ${
                  horizon === h
                    ? 'bg-[#38bdf8] text-[#00354a] shadow-sm'
                    : 'text-[#87929a] hover:text-[#d4e4fa]'
                }`}
              >
                {h} {h === 'T+1' ? '(1D)' : h === 'T+5' ? '(1W)' : '(Swing)'}
              </button>
            ))}
          </div>
        </div>

        {/* Model Estimator Selector */}
        <div className="flex items-center gap-3">
          <span className="font-mono text-[10px] uppercase text-[#87929a] tracking-wider">
            Estimator Pipeline:
          </span>
          <div className="flex items-center p-0.5 rounded-lg bg-[#122131] border border-[#1c2b3c]">
            <button
              onClick={() => setModelType('random-forest')}
              className={`px-2.5 py-1 rounded text-xs font-mono font-medium transition-colors ${
                modelType === 'random-forest'
                  ? 'bg-[#1c2b3c] text-[#8ed5ff] font-bold'
                  : 'text-[#87929a] hover:text-[#d4e4fa]'
              }`}
            >
              Random Forest Regressor
            </button>
            <button
              onClick={() => setModelType('linear-ols')}
              className={`px-2.5 py-1 rounded text-xs font-mono font-medium transition-colors ${
                modelType === 'linear-ols'
                  ? 'bg-[#1c2b3c] text-[#8ed5ff] font-bold'
                  : 'text-[#87929a] hover:text-[#d4e4fa]'
              }`}
            >
              Linear (OLS)
            </button>
            <button
              onClick={() => setModelType('ensemble')}
              className={`px-2.5 py-1 rounded text-xs font-mono font-medium transition-colors ${
                modelType === 'ensemble'
                  ? 'bg-[#1c2b3c] text-[#8ed5ff] font-bold'
                  : 'text-[#87929a] hover:text-[#d4e4fa]'
              }`}
            >
              Ridge Ensemble
            </button>
          </div>
        </div>
      </section>

      {/* Prominent Academic Demonstration Guardrail Banner */}
      <div className="p-3 rounded-lg bg-[#010f1f] border border-[#f59e0b]/30 flex items-start gap-3 text-xs">
        <AlertTriangle className="w-4 h-4 text-[#f59e0b] shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <span className="font-bold text-[#f59e0b] uppercase font-mono text-[10px] mr-1.5">
            Demonstration Protocol Notice:
          </span>
          <span className="text-[#bdc8d1]">
            These forecasts are generated for an academic B.Tech Capstone machine learning demonstration. Predictions are computed based on lagged returns, rolling moving averages, and volatility proxies. Model diagnostics reflect an empirical cross-validation benchmark on fixed historical data and do not represent guaranteed real-time forward returns or SEBI-certified investment advice.
          </span>
        </div>
      </div>

      {/* SECTION 2: Top Prediction Summary Cards Strip */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Spot EOD Benchmark */}
        <div className="p-3.5 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="font-mono text-[10px] uppercase text-[#87929a]">
              Spot Benchmark (EOD)
            </span>
            <span className="font-mono text-[9px] px-1 py-0.2 rounded bg-[#122131] text-[#87929a]">
              NSE:{currentStock.symbol}
            </span>
          </div>
          <div className="my-1.5">
            <div className="font-mono text-2xl font-bold text-[#d4e4fa]">
              ₹{currentStock.ltp.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
            </div>
            <span className="font-mono text-xs text-[#56e5a9]">
              +{currentStock.change.toFixed(2)} (+{currentStock.changePercent.toFixed(2)}%)
            </span>
          </div>
          <span className="font-mono text-[9px] text-[#87929a]">
            Anchor: 24 Oct 2024, 15:30 IST Close
          </span>
        </div>

        {/* Projected Target */}
        <div className="p-3.5 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] flex flex-col justify-between relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="font-mono text-[10px] uppercase text-[#38bdf8] font-bold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#38bdf8]"></span>
              Projected {horizon} Target
            </span>
            <span className="font-mono text-[9px] px-1.5 py-0.2 rounded bg-[#38bdf8]/15 text-[#8ed5ff]">
              RF-MDI Engine
            </span>
          </div>
          <div className="my-1.5">
            <div className="font-mono text-2xl font-bold text-[#38bdf8]">
              {forecast ? `₹${forecast.projectedTarget.toLocaleString('en-IN', { minimumFractionDigits: 2 })}` : '—'}
            </div>
            <div className={`font-mono text-xs font-semibold ${isBullish ? 'text-[#56e5a9]' : 'text-[#ffb4ab]'}`}>
              {forecast ? `${isBullish ? '+' : ''}₹${forecast.projectedDelta.toFixed(2)} (${isBullish ? '+' : ''}${forecast.projectedDeltaPercent.toFixed(2)}%)` : '—'}
            </div>
          </div>
          <div className="font-mono text-[9px] text-[#87929a]">
            {forecast ? `95% CI: ₹${forecast.confidenceLower.toFixed(0)} - ₹${forecast.confidenceUpper.toFixed(0)}` : '—'}
          </div>
        </div>

        {/* Primary Model Score */}
        <div className="p-3.5 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="font-mono text-[10px] uppercase text-[#87929a]">
              Primary Model (RF-100)
            </span>
            <span className="font-mono text-[9px] px-1.5 py-0.2 rounded bg-[#122131] text-[#56e5a9]">
              Selected
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2 my-1 font-mono">
            <div>
              <span className="text-[9px] text-[#87929a] block">R² Score (Test)</span>
              <span className="text-base font-bold text-[#56e5a9] block">0.912</span>
            </div>
            <div>
              <span className="text-[9px] text-[#87929a] block">Dir. Win Rate</span>
              <span className="text-base font-bold text-[#d4e4fa] block">67.4%</span>
            </div>
          </div>
          <div className="flex justify-between font-mono text-[9px] text-[#87929a]">
            <span>MAE: ₹14.82</span>
            <span>RMSE: ₹21.40</span>
          </div>
        </div>

        {/* Baseline OLS Reference */}
        <div className="p-3.5 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="font-mono text-[10px] uppercase text-[#87929a]">
              Baseline Model (OLS)
            </span>
            <span className="font-mono text-[9px] px-1.5 py-0.2 rounded bg-[#122131] text-[#87929a]">
              Benchmark
            </span>
          </div>
          <div className="grid grid-cols-2 gap-2 my-1 font-mono">
            <div>
              <span className="text-[9px] text-[#87929a] block">R² Score (Test)</span>
              <span className="text-base font-bold text-[#87929a] block">0.824</span>
            </div>
            <div>
              <span className="text-[9px] text-[#87929a] block">Dir. Win Rate</span>
              <span className="text-base font-bold text-[#87929a] block">58.2%</span>
            </div>
          </div>
          <div className="font-mono text-[9px] text-[#38bdf8]">
            Random Forest yields +8.8% R² boost
          </div>
        </div>
      </section>

      {/* SECTION 3: Main Actual Price vs Model Backtest & Projection Chart */}
      <section className="rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] shadow-md overflow-hidden flex flex-col">
        <div className="p-3.5 bg-[#0d1c2d] border-b border-[#1c2b3c] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <span className="font-mono text-[10px] text-[#87929a] uppercase tracking-wider block">
              Backtest & Forecast Projection
            </span>
            <h2 className="text-sm sm:text-base font-bold text-[#d4e4fa]">
              Actual Spot Price vs Recursive Model Forecast Curve ({horizon})
            </h2>
          </div>

          <div className="flex items-center gap-3 text-xs font-mono">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-[#38bdf8] rounded-sm inline-block"></span>
              <span className="text-[#d4e4fa]">Actual Spot</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-0.5 bg-[#56e5a9] inline-block"></span>
              <span className="text-[#56e5a9] font-bold">RF Forecast</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-[#38bdf8]/20 border border-[#38bdf8]/40 rounded-sm inline-block"></span>
              <span className="text-[#87929a]">95% Confidence Band</span>
            </div>
          </div>
        </div>

        {/* SVG Projection Canvas */}
        <div className="relative w-full bg-[#010f1f] p-4 overflow-hidden">
          {isLoading ? (
            <div className="h-64 flex items-center justify-center text-xs font-mono text-[#87929a]">
              Simulating step-ahead recursive regression and confidence interval bands...
            </div>
          ) : forecast ? (
            <div className="flex flex-col gap-2">
              <div className="w-full h-64 sm:h-72 relative">
                <svg
                  className="w-full h-full overflow-visible"
                  viewBox={`0 0 ${svgWidth} ${svgHeight}`}
                  preserveAspectRatio="none"
                >
                  <defs>
                    <linearGradient id="coneGrad" x1="0" x2="1" y1="0" y2="0">
                      <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.15" />
                      <stop offset="100%" stopColor="#38bdf8" stopOpacity="0.35" />
                    </linearGradient>
                  </defs>

                  {/* Horizontal grid lines */}
                  {[0.25, 0.5, 0.75].map((pct, i) => {
                    const priceLevel = minPrice + (maxPrice - minPrice) * (1 - pct);
                    const y = svgHeight * pct;
                    return (
                      <g key={i}>
                        <line x1="0" y1={y} x2={svgWidth} y2={y} stroke="#1c2b3c" strokeDasharray="3 3" strokeWidth="0.75" />
                        <text x={svgWidth - 5} y={y - 4} fill="#87929a" fontSize="9" fontFamily="JetBrains Mono" textAnchor="end">
                          ₹{priceLevel.toFixed(1)}
                        </text>
                      </g>
                    );
                  })}

                  {/* Vertical demarcation line between history and forecast */}
                  {(() => {
                    const xDivider = ((histCount - 1) / (totalPoints - 1)) * svgWidth;
                    return (
                      <g>
                        <line
                          x1={xDivider}
                          y1="0"
                          x2={xDivider}
                          y2={svgHeight}
                          stroke="#38bdf8"
                          strokeDasharray="4 4"
                          strokeWidth="1.5"
                        />
                        <text
                          x={xDivider - 6}
                          y="20"
                          fill="#87929a"
                          fontSize="9"
                          fontFamily="JetBrains Mono"
                          textAnchor="end"
                        >
                          TODAY (24 Oct)
                        </text>
                        <text
                          x={xDivider + 6}
                          y="20"
                          fill="#38bdf8"
                          fontSize="9"
                          fontFamily="JetBrains Mono"
                          textAnchor="start"
                        >
                          PROJECTION CONE →
                        </text>
                      </g>
                    );
                  })()}

                  {/* Historical Spot Line */}
                  <path
                    d={forecast.historicalPrices
                      .map((p, idx) => {
                        const x = (idx / (totalPoints - 1)) * svgWidth;
                        const y = getY(p);
                        return `${idx === 0 ? 'M' : 'L'} ${x} ${y}`;
                      })
                      .join(' ')}
                    fill="none"
                    stroke="#38bdf8"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                  />

                  {/* Confidence Interval Shaded Corridor */}
                  {(() => {
                    const xStart = ((histCount - 1) / (totalPoints - 1)) * svgWidth;
                    const yStart = getY(forecast.lastClose);

                    const upperPoints = forecast.forecastUpperBands.map((ub, idx) => {
                      const x = ((histCount + idx) / (totalPoints - 1)) * svgWidth;
                      const y = getY(ub);
                      return `L ${x} ${y}`;
                    }).join(' ');

                    const lowerPointsRev = forecast.forecastLowerBands
                      .slice()
                      .reverse()
                      .map((lb, idx) => {
                        const originalIdx = forecast.forecastLowerBands.length - 1 - idx;
                        const x = ((histCount + originalIdx) / (totalPoints - 1)) * svgWidth;
                        const y = getY(lb);
                        return `L ${x} ${y}`;
                      }).join(' ');

                    return (
                      <path
                        d={`M ${xStart} ${yStart} ${upperPoints} ${lowerPointsRev} Z`}
                        fill="url(#coneGrad)"
                        stroke="#38bdf8"
                        strokeWidth="0.75"
                        strokeDasharray="2 2"
                      />
                    );
                  })()}

                  {/* Predicted Mean Forecast Line */}
                  {(() => {
                    const xStart = ((histCount - 1) / (totalPoints - 1)) * svgWidth;
                    const yStart = getY(forecast.lastClose);

                    const forecastPath = forecast.forecastPrices.map((fp, idx) => {
                      const x = ((histCount + idx) / (totalPoints - 1)) * svgWidth;
                      const y = getY(fp);
                      return `L ${x} ${y}`;
                    }).join(' ');

                    const lastX = svgWidth - 10;
                    const lastY = getY(forecast.projectedTarget);

                    return (
                      <g>
                        <path
                          d={`M ${xStart} ${yStart} ${forecastPath}`}
                          fill="none"
                          stroke="#56e5a9"
                          strokeWidth="2.5"
                          strokeDasharray="4 2"
                          strokeLinecap="round"
                        />
                        <circle cx={lastX} cy={lastY} r="4.5" fill="#56e5a9" stroke="#010f1f" strokeWidth="2" />
                        <rect x={lastX - 95} y={lastY - 26} width="110" height="20" rx="3" fill="#1c2b3c" />
                        <text x={lastX - 40} y={lastY - 12} fill="#56e5a9" fontSize="9" fontWeight="bold" fontFamily="JetBrains Mono" textAnchor="middle">
                          {horizon}: ₹{forecast.projectedTarget.toFixed(1)}
                        </text>
                      </g>
                    );
                  })()}
                </svg>
              </div>

              {/* Residual Variance Histogram */}
              <div className="w-full h-14 pt-1 border-t border-[#1c2b3c]/60">
                <div className="flex items-center justify-between text-[9px] font-mono text-[#87929a] pb-1">
                  <span>DAILY PREDICTION RESIDUAL VARIANCE (e = Spot - RF_Forecast)</span>
                  <span>MAE: ₹14.82 • STD DEV (σ): ₹8.45</span>
                </div>
                <div className="w-full h-8 flex items-center justify-between gap-[3px]">
                  {forecast.residuals.map((r, idx) => {
                    const isPositive = r.residual >= 0;
                    const barHeight = Math.min(24, Math.abs(r.residual) * 1.2);
                    return (
                      <div key={idx} className="flex-1 flex flex-col items-center justify-center h-full">
                        <div
                          className={`w-full rounded-sm ${
                            isPositive ? 'bg-[#56e5a9]/60' : 'bg-[#ffb4ab]/60'
                          }`}
                          style={{ height: `${Math.max(4, barHeight)}px` }}
                          title={`${r.date}: Residual ₹${r.residual.toFixed(2)}`}
                        />
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : null}
        </div>
      </section>

      {/* SECTION 4: Statistical Diagnostics & Feature Attribution Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Diagnostics Table (7 cols) */}
        <div className="lg:col-span-7 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] p-4 flex flex-col justify-between shadow-sm">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-[#1c2b3c]">
              <div>
                <h3 className="text-xs font-bold text-[#d4e4fa] uppercase tracking-wider">
                  Statistical Diagnostics Benchmark
                </h3>
                <p className="text-[11px] text-[#87929a] mt-0.5">
                  Empirical cross-validation across 252 Indian market trading sessions.
                </p>
              </div>
              <span className="font-mono text-[9px] px-1.5 py-0.5 rounded bg-[#122131] text-[#38bdf8]">
                Cross-Val k=5
              </span>
            </div>

            <div className="w-full overflow-x-auto mt-2">
              <table className="w-full text-left font-mono text-xs">
                <thead>
                  <tr className="border-b border-[#1c2b3c] text-[10px] text-[#87929a] uppercase">
                    <th className="py-2 px-2">Metric Parameter</th>
                    <th className={`py-2 px-2 text-right transition-colors ${modelType === 'linear-ols' ? 'text-[#38bdf8] font-bold bg-[#122131]/60' : 'text-[#87929a]'}`}>
                      Linear (OLS) {modelType === 'linear-ols' ? '• Active' : ''}
                    </th>
                    <th className={`py-2 px-2 text-right transition-colors ${modelType === 'random-forest' ? 'text-[#56e5a9] font-bold bg-[#122131]/60' : 'text-[#87929a]'}`}>
                      Random Forest {modelType === 'random-forest' ? '• Active' : ''}
                    </th>
                    <th className={`py-2 px-2 text-right transition-colors ${modelType === 'ensemble' ? 'text-[#c0c1ff] font-bold bg-[#122131]/60' : 'text-[#87929a]'}`}>
                      Ensemble {modelType === 'ensemble' ? '• Active' : ''}
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1c2b3c]/50 text-[11px]">
                  {forecast?.modelMetrics.map((m, idx) => (
                    <tr key={idx} className="hover:bg-[#122131] transition-colors">
                      <td className="py-2 px-2 text-[#d4e4fa] font-sans font-medium">
                        {m.metricName}
                      </td>
                      <td className={`py-2 px-2 text-right font-mono ${modelType === 'linear-ols' ? 'text-[#38bdf8] font-bold bg-[#122131]/40' : 'text-[#87929a]'}`}>
                        {m.linearOLS}
                      </td>
                      <td className={`py-2 px-2 text-right font-mono ${modelType === 'random-forest' ? 'text-[#56e5a9] font-bold bg-[#122131]/40' : 'text-[#87929a]'}`}>
                        {m.randomForest}
                      </td>
                      <td className={`py-2 px-2 text-right font-mono ${modelType === 'ensemble' ? 'text-[#c0c1ff] font-bold bg-[#122131]/40' : 'text-[#87929a]'}`}>
                        {m.ensemble}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="mt-3 p-2 rounded-lg bg-[#010f1f] border border-[#1c2b3c] text-[10px] font-mono text-[#87929a]">
            Validation Protocol: Purged 5-fold TimeSeriesSplit with 5-day embargo to eliminate lookahead bias.
          </div>
        </div>

        {/* Feature Importance (MDI) Panel (5 cols) */}
        <div className="lg:col-span-5 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] p-4 flex flex-col justify-between shadow-sm">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-[#1c2b3c]">
              <div>
                <h3 className="text-xs font-bold text-[#d4e4fa] uppercase tracking-wider">
                  Feature Importance (MDI)
                </h3>
                <p className="text-[11px] text-[#87929a] mt-0.5">
                  Gini impurity reduction weighting across decision trees.
                </p>
              </div>
              <span className="font-mono text-[9px] px-1.5 py-0.5 rounded bg-[#122131] text-[#56e5a9]">
                Scikit-Learn
              </span>
            </div>

            <div className="space-y-3 mt-3">
              {forecast?.featureImportances.map((item, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-[#d4e4fa] font-medium truncate max-w-[200px]">
                      {idx + 1}. {item.feature}
                    </span>
                    <span className="font-bold text-[#38bdf8]">{item.importance}%</span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-[#1c2b3c] overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-[#38bdf8] to-[#56e5a9] rounded-full"
                      style={{ width: `${item.importance * 3}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-3 p-2.5 rounded-lg bg-[#010f1f] border border-[#1c2b3c] text-[10px] text-[#87929a] leading-relaxed">
            <strong className="text-[#8ed5ff]">Model Attribution Synthesis:</strong> The ensemble places highest explanatory weighting on intermediate trend continuity (20-EMA) and momentum mean-reversion (RSI-14).
          </div>
        </div>
      </div>

      {/* Academic Disclaimer */}
      <AcademicDisclaimer />
    </div>
  );
};
