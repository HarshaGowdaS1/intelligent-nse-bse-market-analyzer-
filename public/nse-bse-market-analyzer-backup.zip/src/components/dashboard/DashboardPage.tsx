import React, { useState, useMemo } from 'react';
import { 
  TrendingUp, 
  TrendingDown, 
  BrainCircuit, 
  ArrowRight, 
  RefreshCw, 
  Download, 
  Activity, 
  Zap, 
  Layers, 
  SlidersHorizontal,
  Flame,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';
import { StockQuote, MarketIndex, Timeframe } from '../../types/market';
import { DATA_METADATA } from '../../services/dataService';
import { AcademicDisclaimer } from '../common/AcademicDisclaimer';
import { exportStocksScreenerToCSV } from '../../utils/csvExport';

interface DashboardPageProps {
  indices: MarketIndex[];
  stocks: StockQuote[];
  watchlistSymbols: string[];
  onSelectStock: (symbol: string) => void;
  onNavigateToPredictions: () => void;
  onNavigateToWatchlist: () => void;
  onRemoveFromWatchlist: (symbol: string) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  indices,
  stocks,
  watchlistSymbols,
  onSelectStock,
  onNavigateToPredictions,
  onNavigateToWatchlist,
  onRemoveFromWatchlist
}) => {
  const [selectedBenchmark, setSelectedBenchmark] = useState<'NIFTY 50' | 'BANK NIFTY' | 'SENSEX' | 'NIFTY IT'>('NIFTY 50');
  const [timeframe, setTimeframe] = useState<Timeframe>('1M');
  const [showSMA, setShowSMA] = useState(true);
  const [showBollinger, setShowBollinger] = useState(false);
  const [filterMode, setFilterMode] = useState<'all' | 'high-beta' | 'ml-favs'>('all');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastRefreshedTime, setLastRefreshedTime] = useState('15:30:00 IST');

  const niftyIndex = indices.find(i => i.symbol === 'NIFTY 50') || indices[0];
  const sensexIndex = indices.find(i => i.symbol === 'SENSEX') || indices[1];
  const vixIndex = indices.find(i => i.symbol === 'INDIA VIX') || indices[2];

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
      const now = new Date();
      setLastRefreshedTime(now.toLocaleTimeString('en-IN', { hour12: false }) + ' IST');
    }, 600);
  };

  // Filter stocks based on table filter tabs
  const displayedStocks = stocks.filter(stock => {
    if (filterMode === 'high-beta') return stock.beta1Y > 1.1;
    if (filterMode === 'ml-favs') return stock.aiSignal === 'Bullish' || stock.aiSignal === 'Strong Buy';
    return true;
  });

  // Calculate dynamic benchmark series and coordinates
  const activeBenchmarkData = useMemo(() => {
    const currentIdx = indices.find(i => i.symbol === selectedBenchmark) || indices[0];
    const baseValue = currentIdx.value;
    const isUp = currentIdx.changePercent >= 0;
    
    // Deterministic seed generation based on index symbol and timeframe
    const pointsCount = timeframe === '1D' ? 24 : timeframe === '5D' ? 30 : timeframe === '1M' ? 30 : timeframe === '3M' ? 50 : 65;
    const points: number[] = [];
    
    const seed = selectedBenchmark.charCodeAt(0) + selectedBenchmark.charCodeAt(selectedBenchmark.length - 1);
    let cur = baseValue * (1 - (isUp ? 0.025 : -0.015));
    
    for (let i = 0; i < pointsCount; i++) {
      const progress = i / (pointsCount - 1);
      const target = baseValue * (1 - (1 - progress) * (isUp ? 0.025 : -0.015));
      const noise = Math.sin(i * 0.7 + seed) * (baseValue * 0.003) + Math.cos(i * 1.3) * (baseValue * 0.002);
      cur = cur * 0.4 + (target + noise) * 0.6;
      points.push(cur);
    }
    // Ensure final point matches current quote value
    points[points.length - 1] = baseValue;

    const min = Math.min(...points) * 0.998;
    const max = Math.max(...points) * 1.002;
    const range = max - min || 1;

    // SMA series
    const smaPoints: (number | null)[] = points.map((_, i) => {
      const period = Math.min(12, Math.floor(pointsCount / 2));
      if (i < period - 1) return null;
      const window = points.slice(i - period + 1, i + 1);
      return window.reduce((a, b) => a + b, 0) / window.length;
    });

    // Bollinger Bands series (mean ± 1.8 * stdDev)
    const bbUpper: (number | null)[] = [];
    const bbLower: (number | null)[] = [];
    points.forEach((_, i) => {
      const period = Math.min(12, Math.floor(pointsCount / 2));
      if (i < period - 1) {
        bbUpper.push(null);
        bbLower.push(null);
      } else {
        const window = points.slice(i - period + 1, i + 1);
        const mean = window.reduce((a, b) => a + b, 0) / window.length;
        const variance = window.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / window.length;
        const stdDev = Math.sqrt(variance);
        bbUpper.push(mean + stdDev * 1.8);
        bbLower.push(mean - stdDev * 1.8);
      }
    });

    const toY = (val: number) => 250 - ((val - min) / range) * 200;
    const toX = (idx: number) => (idx / (pointsCount - 1)) * 1000;

    const pathCoords = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${toX(i).toFixed(1)} ${toY(p).toFixed(1)}`).join(' ');
    const areaCoords = `${pathCoords} L 1000 280 L 0 280 Z`;

    const smaCoords = smaPoints
      .map((p, i) => (p !== null ? `${toX(i).toFixed(1)} ${toY(p).toFixed(1)}` : null))
      .filter(Boolean);
    const smaPath = smaCoords.length > 0 ? `M ${smaCoords.join(' L ')}` : '';

    const upperCoords = bbUpper
      .map((p, i) => (p !== null ? `${toX(i).toFixed(1)} ${toY(p).toFixed(1)}` : null))
      .filter(Boolean);
    const bbUpperPath = upperCoords.length > 0 ? `M ${upperCoords.join(' L ')}` : '';

    const lowerCoords = bbLower
      .map((p, i) => (p !== null ? `${toX(i).toFixed(1)} ${toY(p).toFixed(1)}` : null))
      .filter(Boolean);
    const bbLowerPath = lowerCoords.length > 0 ? `M ${lowerCoords.join(' L ')}` : '';

    let minIdx = 0;
    let maxIdx = 0;
    points.forEach((p, i) => {
      if (p < points[minIdx]) minIdx = i;
      if (p > points[maxIdx]) maxIdx = i;
    });

    const periodChange = baseValue - points[0];
    const periodChangePercent = ((periodChange) / points[0]) * 100;

    return {
      index: currentIdx,
      points,
      min,
      max,
      minPoint: { x: toX(minIdx), y: toY(points[minIdx]), val: points[minIdx] },
      maxPoint: { x: toX(maxIdx), y: toY(points[maxIdx]), val: points[maxIdx] },
      lastPoint: { x: toX(pointsCount - 1), y: toY(baseValue), val: baseValue },
      pathCoords,
      areaCoords,
      smaPath,
      bbUpperPath,
      bbLowerPath,
      periodChange,
      periodChangePercent
    };
  }, [selectedBenchmark, timeframe, indices]);

  return (
    <div className="flex flex-col gap-5 pb-12">
      {/* Top Header Strip */}
      <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="font-mono text-[10px] text-[#87929a] uppercase tracking-wider">
              Dashboard
            </span>
            <span className="text-[#3e484f] text-[10px]">/</span>
            <span className="font-mono text-[10px] text-[#38bdf8] font-semibold uppercase tracking-wider">
              Overview (NSE Focus)
            </span>
            <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-[#122131] border border-[#1c2b3c] text-[#8ed5ff] font-mono text-[9px]">
              SNAPSHOT CACHED
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-[#d4e4fa] tracking-tight">
            NSE-BSE Market Analyzer
          </h1>
          <p className="text-xs text-[#bdc8d1] max-w-3xl mt-0.5">
            Algorithmic equity monitoring, institutional volume profiling, and ML-driven trend classification across National Stock Exchange (NSE) & Bombay Stock Exchange (BSE).
          </p>
        </div>

        {/* Quick Action Buttons */}
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            onClick={() => exportStocksScreenerToCSV(displayedStocks)}
            className="px-3 py-2 rounded-lg bg-[#0d1c2d] hover:bg-[#122131] border border-[#1c2b3c] text-[#8ed5ff] text-xs flex items-center gap-1.5 shadow-sm transition-all"
            title="Export complete equities dataset as CSV"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={handleRefresh}
            className="px-3 py-2 rounded-lg bg-[#0d1c2d] hover:bg-[#122131] border border-[#1c2b3c] text-[#d4e4fa] text-xs flex items-center gap-1.5 shadow-sm transition-all"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-[#87929a] ${isRefreshing ? 'animate-spin text-[#38bdf8]' : ''}`} />
            <span>Refresh Telemetry</span>
          </button>
          <button
            onClick={onNavigateToPredictions}
            className="px-3.5 py-2 rounded-lg bg-[#38bdf8] text-[#00354a] hover:brightness-110 text-xs font-semibold flex items-center gap-1.5 shadow-md shadow-[#38bdf8]/20 transition-all"
          >
            <BrainCircuit className="w-4 h-4" />
            <span>AI Predictions Radar</span>
          </button>
        </div>
      </div>

      {/* Academic Sandbox Banner */}
      <AcademicDisclaimer compact={true} />

      {/* SECTION A: Five Market Overview Cards */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        {/* Card 1: NIFTY 50 */}
        <div className="p-3.5 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] shadow-sm flex flex-col justify-between hover:border-[#38bdf8]/40 transition-colors">
          <div>
            <div className="flex items-center justify-between pb-1">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-[#d4e4fa]">NIFTY 50</span>
                <span className="px-1 py-0.2 rounded bg-[#122131] font-mono text-[9px] text-[#87929a]">
                  NSE
                </span>
              </div>
              <TrendingUp className="w-3.5 h-3.5 text-[#56e5a9]" />
            </div>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="font-mono text-xl font-bold text-[#d4e4fa] tracking-tight">
                {niftyIndex.value.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </span>
              <span className="font-mono text-xs font-semibold text-[#56e5a9]">
                +{niftyIndex.change.toFixed(2)} (+{niftyIndex.changePercent.toFixed(2)}%)
              </span>
            </div>
          </div>
          <div className="my-2 h-7 w-full overflow-hidden">
            <svg className="w-full h-full" viewBox="0 0 160 30" fill="none" preserveAspectRatio="none">
              <defs>
                <linearGradient id="niftyGlow" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#56e5a9" stopOpacity="0.3" />
                  <stop offset="100%" stopColor="#56e5a9" stopOpacity="0.0" />
                </linearGradient>
              </defs>
              <path d="M 0 24 Q 25 21 50 16 T 100 12 T 160 4 L 160 30 L 0 30 Z" fill="url(#niftyGlow)" />
              <path d="M 0 24 Q 25 21 50 16 T 100 12 T 160 4" stroke="#56e5a9" strokeWidth="1.75" strokeLinecap="round" />
            </svg>
          </div>
          <div className="flex items-center justify-between font-mono text-[9px] text-[#87929a] pt-1 border-t border-[#1c2b3c]/60">
            <span>L: {niftyIndex.low.toLocaleString('en-IN')}</span>
            <span>H: {niftyIndex.high.toLocaleString('en-IN')}</span>
          </div>
        </div>

        {/* Card 2: BSE SENSEX */}
        <div className="p-3.5 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] shadow-sm flex flex-col justify-between hover:border-[#38bdf8]/40 transition-colors">
          <div>
            <div className="flex items-center justify-between pb-1">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-[#d4e4fa]">SENSEX</span>
                <span className="px-1 py-0.2 rounded bg-[#122131] font-mono text-[9px] text-[#87929a]">
                  BSE
                </span>
              </div>
              <TrendingUp className="w-3.5 h-3.5 text-[#56e5a9]" />
            </div>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="font-mono text-xl font-bold text-[#d4e4fa] tracking-tight">
                {sensexIndex.value.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </span>
              <span className="font-mono text-xs font-semibold text-[#56e5a9]">
                +{sensexIndex.change.toFixed(2)} (+{sensexIndex.changePercent.toFixed(2)}%)
              </span>
            </div>
          </div>
          <div className="my-2 h-7 w-full overflow-hidden">
            <svg className="w-full h-full" viewBox="0 0 160 30" fill="none" preserveAspectRatio="none">
              <defs>
                <linearGradient id="sensexGlow" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.3" />
                  <stop offset="100%" stopColor="#38bdf8" stopOpacity="0.0" />
                </linearGradient>
              </defs>
              <path d="M 0 22 Q 30 25 65 14 T 120 10 T 160 4 L 160 30 L 0 30 Z" fill="url(#sensexGlow)" />
              <path d="M 0 22 Q 30 25 65 14 T 120 10 T 160 4" stroke="#38bdf8" strokeWidth="1.75" strokeLinecap="round" />
            </svg>
          </div>
          <div className="flex items-center justify-between font-mono text-[9px] text-[#87929a] pt-1 border-t border-[#1c2b3c]/60">
            <span>L: {sensexIndex.low.toLocaleString('en-IN')}</span>
            <span>H: {sensexIndex.high.toLocaleString('en-IN')}</span>
          </div>
        </div>

        {/* Card 3: Watchlist Alpha */}
        <div className="p-3.5 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] shadow-sm flex flex-col justify-between hover:border-[#38bdf8]/40 transition-colors">
          <div>
            <div className="flex items-center justify-between pb-1">
              <span className="text-[11px] font-semibold uppercase text-[#bdc8d1]">Watchlist Return</span>
              <span className="px-1.5 py-0.5 rounded bg-[#3131c0]/30 text-[#c0c1ff] font-mono text-[9px]">
                6 Monitored
              </span>
            </div>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="font-mono text-xl font-bold text-[#56e5a9] tracking-tight">
                +1.84%
              </span>
              <span className="font-mono text-xs font-semibold text-[#8ed5ff]">
                +1.42% α
              </span>
            </div>
          </div>
          <div className="my-2">
            <div className="flex items-center justify-between font-mono text-[9px] text-[#87929a] mb-1">
              <span>4 Gainers</span>
              <span>2 Decliners</span>
            </div>
            <div className="w-full h-1.5 rounded-full bg-[#1c2b3c] overflow-hidden flex">
              <div className="h-full bg-[#56e5a9]" style={{ width: '66.7%' }}></div>
              <div className="h-full bg-[#ffb4ab]" style={{ width: '33.3%' }}></div>
            </div>
          </div>
          <div className="flex items-center justify-between font-mono text-[9px] text-[#87929a] pt-1 border-t border-[#1c2b3c]/60">
            <span>Ref: NIFTY 50</span>
            <span className="text-[#56e5a9] font-semibold">Beat +142 bps</span>
          </div>
        </div>

        {/* Card 4: INDIA VIX */}
        <div className="p-3.5 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] shadow-sm flex flex-col justify-between hover:border-[#38bdf8]/40 transition-colors">
          <div>
            <div className="flex items-center justify-between pb-1">
              <span className="text-[11px] font-semibold uppercase text-[#bdc8d1]">India VIX (Risk)</span>
              <span className="px-1.5 py-0.5 rounded bg-[#56e5a9]/15 text-[#56e5a9] font-mono text-[9px]">
                Calm Regime
              </span>
            </div>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="font-mono text-xl font-bold text-[#d4e4fa] tracking-tight">
                {vixIndex.value.toFixed(2)}
              </span>
              <span className="font-mono text-xs font-semibold text-[#56e5a9]">
                {vixIndex.change.toFixed(2)} ({vixIndex.changePercent.toFixed(2)}%)
              </span>
            </div>
          </div>
          <div className="my-2">
            <div className="flex justify-between font-mono text-[9px] text-[#87929a] mb-1">
              <span>10 (Low)</span>
              <span>20 (Mid)</span>
              <span>35 (Panic)</span>
            </div>
            <div className="w-full h-1.5 rounded-full bg-[#1c2b3c] relative overflow-hidden">
              <div className="absolute left-0 top-0 bottom-0 bg-[#38bdf8] rounded-full" style={{ width: '28%' }}></div>
            </div>
          </div>
          <div className="flex items-center justify-between font-mono text-[9px] text-[#87929a] pt-1 border-t border-[#1c2b3c]/60">
            <span>Option Skew: Call Favor</span>
            <span className="text-[#bdc8d1]">IV Rank: 22%</span>
          </div>
        </div>

        {/* Card 5: ML Bias Signal */}
        <div className="p-3.5 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] shadow-sm flex flex-col justify-between hover:border-[#38bdf8]/40 transition-colors">
          <div>
            <div className="flex items-center justify-between pb-1">
              <span className="text-[11px] font-semibold uppercase text-[#bdc8d1]">ML Bias Signal</span>
              <span className="px-1.5 py-0.5 rounded bg-[#38bdf8]/20 text-[#8ed5ff] font-mono text-[9px]">
                RF Ensemble
              </span>
            </div>
            <div className="flex items-baseline gap-1 mt-1">
              <span className="text-sm font-bold text-[#56e5a9] tracking-tight">BULLISH</span>
              <span className="font-mono text-xs text-[#bdc8d1]">(74.2%)</span>
            </div>
          </div>
          <div className="my-2">
            <div className="flex items-center justify-between font-mono text-[9px] text-[#87929a] mb-1">
              <span className="text-[#56e5a9]">74% Long Bias</span>
              <span className="text-[#ffb4ab]">26% Bear</span>
            </div>
            <div className="w-full h-1.5 rounded-full bg-[#1c2b3c] flex overflow-hidden">
              <div className="h-full bg-[#38bdf8]" style={{ width: '74.2%' }}></div>
              <div className="h-full bg-[#273647]" style={{ width: '25.8%' }}></div>
            </div>
          </div>
          <div className="flex items-center justify-between font-mono text-[9px] text-[#87929a] pt-1 border-t border-[#1c2b3c]/60">
            <span>Epoch Acc: 81.4%</span>
            <span className="text-[#38bdf8] font-semibold">Overweight</span>
          </div>
        </div>
      </section>

      {/* SECTION B: Interactive Benchmark Chart */}
      <section className="rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] shadow-md overflow-hidden flex flex-col">
        {/* Chart Header & Control Toolbar */}
        <div className="p-3.5 bg-[#0d1c2d] border-b border-[#1c2b3c] flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="flex flex-col sm:flex-row sm:items-center gap-3">
            <div>
              <span className="font-mono text-[10px] text-[#87929a] uppercase tracking-wider block">
                Benchmark Telemetry
              </span>
              <h2 className="text-sm sm:text-base font-bold text-[#d4e4fa]">
                {selectedBenchmark} • Relative Performance & Dynamic Momentum
              </h2>
            </div>

            {/* Benchmark Switcher */}
            <div className="flex items-center p-0.5 rounded-lg bg-[#122131] border border-[#1c2b3c]">
              {(['NIFTY 50', 'BANK NIFTY', 'SENSEX', 'NIFTY IT'] as const).map((bm) => (
                <button
                  key={bm}
                  onClick={() => setSelectedBenchmark(bm)}
                  className={`px-2.5 py-1 rounded text-[11px] font-mono font-medium transition-colors ${
                    selectedBenchmark === bm
                      ? 'bg-[#38bdf8] text-[#00354a] font-bold shadow-sm'
                      : 'text-[#87929a] hover:text-[#d4e4fa]'
                  }`}
                >
                  {bm}
                </button>
              ))}
            </div>
          </div>

          {/* Timeframe Controls and Indicator Checkboxes */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center p-0.5 rounded-lg bg-[#122131] border border-[#1c2b3c]">
              {(['1D', '5D', '1M', '3M', '6M', '1Y'] as Timeframe[]).map((tf) => (
                <button
                  key={tf}
                  onClick={() => setTimeframe(tf)}
                  className={`px-2 py-0.5 rounded text-[10px] font-mono font-medium transition-colors ${
                    timeframe === tf
                      ? 'bg-[#1c2b3c] text-[#8ed5ff] font-bold'
                      : 'text-[#87929a] hover:text-[#d4e4fa]'
                  }`}
                >
                  {tf}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <label className="flex items-center gap-1.5 cursor-pointer px-2 py-1 rounded bg-[#122131] hover:bg-[#1c2b3c] text-[10px] font-mono text-[#bdc8d1]">
                <input
                  type="checkbox"
                  checked={showSMA}
                  onChange={(e) => setShowSMA(e.target.checked)}
                  className="rounded bg-[#051424] text-[#38bdf8] accent-[#38bdf8] w-3 h-3"
                />
                <span>50-SMA</span>
              </label>
              <label className="flex items-center gap-1.5 cursor-pointer px-2 py-1 rounded bg-[#122131] hover:bg-[#1c2b3c] text-[10px] font-mono text-[#bdc8d1]">
                <input
                  type="checkbox"
                  checked={showBollinger}
                  onChange={(e) => setShowBollinger(e.target.checked)}
                  className="rounded bg-[#051424] text-[#38bdf8] accent-[#38bdf8] w-3 h-3"
                />
                <span>Bollinger</span>
              </label>
            </div>
          </div>
        </div>

        {/* High-Fidelity SVG Graphic Area */}
        <div className="relative w-full px-4 py-3 bg-[#010f1f]/80">
          <div className="absolute right-6 top-3 pointer-events-none flex flex-col items-end opacity-40">
            <span className="font-mono text-[9px] font-bold text-[#87929a]">
              NSE:{selectedBenchmark.replace(' ', '_')}
            </span>
            <span className="font-mono text-[8px] text-[#87929a]">
              DAILY INTERVAL • OHLCV
            </span>
          </div>

          {/* SVG Price Chart */}
          <div className="w-full h-64 sm:h-72">
            <svg className="w-full h-full" viewBox="0 0 1000 280" fill="none" preserveAspectRatio="none">
              <defs>
                <linearGradient id="benchmarkGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.32" />
                  <stop offset="60%" stopColor="#38bdf8" stopOpacity="0.06" />
                  <stop offset="100%" stopColor="#38bdf8" stopOpacity="0.0" />
                </linearGradient>
              </defs>

              {/* Grid lines */}
              <line x1="0" y1="50" x2="1000" y2="50" stroke="#1c2b3c" strokeDasharray="2 4" strokeWidth="0.75" />
              <line x1="0" y1="120" x2="1000" y2="120" stroke="#1c2b3c" strokeDasharray="2 4" strokeWidth="0.75" />
              <line x1="0" y1="190" x2="1000" y2="190" stroke="#1c2b3c" strokeDasharray="2 4" strokeWidth="0.75" />

              <text x="990" y="46" fill="#87929a" fontSize="9" fontFamily="JetBrains Mono" textAnchor="end">
                {activeBenchmarkData.max.toLocaleString('en-IN', { maximumFractionDigits: 1 })} (Peak Resistance)
              </text>
              <text x="990" y="186" fill="#87929a" fontSize="9" fontFamily="JetBrains Mono" textAnchor="end">
                {activeBenchmarkData.min.toLocaleString('en-IN', { maximumFractionDigits: 1 })} (Demand Floor)
              </text>

              {/* 50-SMA Orange Trend Curve */}
              {showSMA && activeBenchmarkData.smaPath && (
                <path
                  d={activeBenchmarkData.smaPath}
                  fill="none"
                  stroke="#f59e0b"
                  strokeWidth="1.5"
                  strokeDasharray="4 2"
                  opacity="0.85"
                />
              )}

              {/* Bollinger Bands */}
              {showBollinger && (
                <>
                  {activeBenchmarkData.bbUpperPath && (
                    <path
                      d={activeBenchmarkData.bbUpperPath}
                      fill="none"
                      stroke="#c0c1ff"
                      strokeWidth="1"
                      strokeDasharray="3 3"
                      opacity="0.6"
                    />
                  )}
                  {activeBenchmarkData.bbLowerPath && (
                    <path
                      d={activeBenchmarkData.bbLowerPath}
                      fill="none"
                      stroke="#c0c1ff"
                      strokeWidth="1"
                      strokeDasharray="3 3"
                      opacity="0.6"
                    />
                  )}
                </>
              )}

              {/* Main Mountain Area & Line */}
              <path
                d={activeBenchmarkData.areaCoords}
                fill="url(#benchmarkGrad)"
              />
              <path
                d={activeBenchmarkData.pathCoords}
                fill="none"
                stroke="#38bdf8"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />

              {/* High Point Marker Callout */}
              <circle
                cx={activeBenchmarkData.maxPoint.x}
                cy={activeBenchmarkData.maxPoint.y}
                r="4.5"
                fill="#38bdf8"
                stroke="#051424"
                strokeWidth="2"
              />
              <rect
                x={Math.max(10, Math.min(880, activeBenchmarkData.maxPoint.x - 55))}
                y={Math.max(8, activeBenchmarkData.maxPoint.y - 24)}
                width="110"
                height="18"
                rx="3"
                fill="#1c2b3c"
              />
              <text
                x={Math.max(10, Math.min(880, activeBenchmarkData.maxPoint.x - 55)) + 55}
                y={Math.max(8, activeBenchmarkData.maxPoint.y - 24) + 12}
                fill="#8ed5ff"
                fontSize="9"
                fontWeight="600"
                fontFamily="JetBrains Mono"
                textAnchor="middle"
              >
                High: {activeBenchmarkData.maxPoint.val.toLocaleString('en-IN', { maximumFractionDigits: 1 })}
              </text>

              {/* Low Point Marker Callout */}
              <circle
                cx={activeBenchmarkData.minPoint.x}
                cy={activeBenchmarkData.minPoint.y}
                r="4.5"
                fill="#ffb4ab"
                stroke="#051424"
                strokeWidth="2"
              />
              <rect
                x={Math.max(10, Math.min(880, activeBenchmarkData.minPoint.x - 55))}
                y={Math.min(252, activeBenchmarkData.minPoint.y + 8)}
                width="110"
                height="18"
                rx="3"
                fill="#1c2b3c"
              />
              <text
                x={Math.max(10, Math.min(880, activeBenchmarkData.minPoint.x - 55)) + 55}
                y={Math.min(252, activeBenchmarkData.minPoint.y + 8) + 12}
                fill="#ffb4ab"
                fontSize="9"
                fontWeight="600"
                fontFamily="JetBrains Mono"
                textAnchor="middle"
              >
                Low: {activeBenchmarkData.minPoint.val.toLocaleString('en-IN', { maximumFractionDigits: 1 })}
              </text>

              {/* Current Close Pulse Point */}
              <circle
                cx={activeBenchmarkData.lastPoint.x}
                cy={activeBenchmarkData.lastPoint.y}
                r="5"
                fill="#56e5a9"
              />
            </svg>
          </div>

          {/* Volume Profile Bars Below */}
          <div className="h-12 w-full pt-2">
            <div className="flex items-center justify-between text-[9px] font-mono text-[#87929a] pb-1">
              <span>VOLUME OSCILLATOR (DAILY EQUITIES)</span>
              <span>AVG: 284.5M</span>
            </div>
            <div className="w-full h-8 flex items-end gap-1 sm:gap-1.5 justify-between">
              {[40, 30, 55, 48, 75, 35, 62, 90, 68, 45, 58, 80, 65, 72].map((height, i) => (
                <div
                  key={i}
                  className={`w-full rounded-t transition-all ${
                    i % 3 === 1 ? 'bg-[#ffb4ab]/50 hover:bg-[#ffb4ab]' : 'bg-[#56e5a9]/50 hover:bg-[#56e5a9]'
                  }`}
                  style={{ height: `${height}%` }}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Chart Bottom Status Strip */}
        <div className="px-4 py-2 bg-[#122131] border-t border-[#1c2b3c] flex flex-wrap items-center justify-between gap-2 font-mono text-[10px]">
          <div className="flex items-center gap-4 flex-wrap">
            <div>
              <span className="text-[#87929a]">SPOT: </span>
              <span className="text-[#d4e4fa] font-bold">
                {activeBenchmarkData.index.value.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </span>
            </div>
            <div>
              <span className="text-[#87929a]">{timeframe} CHANGE: </span>
              <span className={`font-bold ${activeBenchmarkData.periodChange >= 0 ? 'text-[#56e5a9]' : 'text-[#ffb4ab]'}`}>
                {activeBenchmarkData.periodChange >= 0 ? '+' : ''}{activeBenchmarkData.periodChange.toFixed(2)} ({activeBenchmarkData.periodChangePercent >= 0 ? '+' : ''}{activeBenchmarkData.periodChangePercent.toFixed(2)}%)
              </span>
            </div>
            <div className="hidden sm:block">
              <span className="text-[#87929a]">ROLLING BETA: </span>
              <span className="text-[#d4e4fa]">1.00</span>
            </div>
            <div className="hidden md:block">
              <span className="text-[#87929a]">SHARPE (1Y): </span>
              <span className="text-[#38bdf8] font-bold">1.82</span>
            </div>
          </div>
          <div className="flex items-center gap-1.5 text-[#bdc8d1]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#56e5a9] animate-pulse"></span>
            <span>Last Telemetry Sync: {lastRefreshedTime}</span>
          </div>
        </div>
      </section>

      {/* SECTION B.5: User's Active Watchlist Summary */}
      <section className="rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] shadow-md p-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#1c2b3c]">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#38bdf8] animate-pulse"></span>
            <h3 className="text-sm font-bold text-[#d4e4fa] tracking-tight">
              My Watchlist Summary
            </h3>
            <span className="font-mono text-[10px] px-2 py-0.5 rounded-full bg-[#122131] border border-[#1c2b3c] text-[#8ed5ff]">
              {watchlistSymbols.length} Monitored
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onNavigateToWatchlist}
              className="px-3 py-1.5 rounded-lg bg-[#122131] hover:bg-[#1c2b3c] border border-[#1c2b3c] text-[#8ed5ff] text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <span>Manage Watchlist</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Watchlist Quick Summary Cards */}
        <div className="mt-3">
          {watchlistSymbols.length === 0 ? (
            <div className="py-6 text-center text-xs text-[#87929a] flex flex-col items-center justify-center gap-2">
              <p>Your watchlist currently has no active stocks.</p>
              <button
                onClick={onNavigateToWatchlist}
                className="px-3 py-1.5 rounded bg-[#38bdf8] text-[#00354a] font-semibold text-xs hover:brightness-110 transition-all"
              >
                + Add Predefined Stocks to Watchlist
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
              {stocks
                .filter(s => watchlistSymbols.includes(s.symbol))
                .map((stock) => {
                  const isPositive = stock.changePercent >= 0;
                  return (
                    <div
                      key={stock.symbol}
                      onClick={() => onSelectStock(stock.symbol)}
                      className="p-3 rounded-lg bg-[#122131] border border-[#1c2b3c] hover:border-[#38bdf8]/40 transition-all cursor-pointer flex flex-col justify-between group"
                    >
                      <div className="flex items-center justify-between pb-1">
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono text-xs font-bold text-[#d4e4fa] group-hover:text-[#38bdf8] transition-colors">
                            {stock.symbol}
                          </span>
                          <span className="font-mono text-[9px] px-1 py-0.2 rounded bg-[#0d1c2d] text-[#87929a]">
                            {stock.exchange}
                          </span>
                        </div>
                        <span className={`font-mono text-[10px] font-semibold flex items-center gap-0.5 ${
                          isPositive ? 'text-[#56e5a9]' : 'text-[#ffb4ab]'
                        }`}>
                          {isPositive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                          {isPositive ? '+' : ''}{stock.changePercent.toFixed(2)}%
                        </span>
                      </div>

                      <div className="flex items-baseline justify-between mt-1">
                        <span className="text-[10px] text-[#87929a] truncate max-w-[110px]">
                          {stock.name}
                        </span>
                        <div className="text-right">
                          <div className="font-mono text-xs font-bold text-[#d4e4fa]">
                            ₹{stock.ltp.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                          </div>
                          <div className={`font-mono text-[9px] ${isPositive ? 'text-[#56e5a9]' : 'text-[#ffb4ab]'}`}>
                            {isPositive ? '+' : ''}₹{stock.change.toFixed(2)}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
            </div>
          )}
        </div>
      </section>

      {/* SECTION C: Two-Column Analytical Grid (Table on Left, Signals on Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column: Top Equities Table (8 cols) */}
        <div className="lg:col-span-8 flex flex-col rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] shadow-md overflow-hidden">
          <div className="p-3.5 border-b border-[#1c2b3c] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-[#d4e4fa]">Top Equities & Liquidity Pulse</h3>
                <span className="px-1.5 py-0.5 rounded bg-[#122131] text-[#38bdf8] font-mono text-[9px] font-semibold">
                  NSE Universe
                </span>
              </div>
              <p className="text-[11px] text-[#bdc8d1]">
                Predefined capstone constituents sorted with technical signals, liquidity indicators, and predictive classification.
              </p>
            </div>

            {/* Filter buttons & Table CSV Export */}
            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <div className="flex items-center p-0.5 rounded-lg bg-[#122131] border border-[#1c2b3c]">
                <button
                  onClick={() => setFilterMode('all')}
                  className={`px-2.5 py-1 rounded text-[10px] font-mono font-medium ${
                    filterMode === 'all'
                      ? 'bg-[#1c2b3c] text-[#8ed5ff] font-semibold'
                      : 'text-[#87929a] hover:text-[#d4e4fa]'
                  }`}
                >
                  All ({stocks.length})
                </button>
                <button
                  onClick={() => setFilterMode('high-beta')}
                  className={`px-2.5 py-1 rounded text-[10px] font-mono font-medium ${
                    filterMode === 'high-beta'
                      ? 'bg-[#1c2b3c] text-[#8ed5ff] font-semibold'
                      : 'text-[#87929a] hover:text-[#d4e4fa]'
                  }`}
                >
                  High Beta
                </button>
                <button
                  onClick={() => setFilterMode('ml-favs')}
                  className={`px-2.5 py-1 rounded text-[10px] font-mono font-medium ${
                    filterMode === 'ml-favs'
                      ? 'bg-[#1c2b3c] text-[#8ed5ff] font-semibold'
                      : 'text-[#87929a] hover:text-[#d4e4fa]'
                  }`}
                >
                  ML Favs
                </button>
              </div>

              <button
                onClick={() => exportStocksScreenerToCSV(displayedStocks)}
                className="px-2.5 py-1 rounded-lg bg-[#122131] hover:bg-[#1c2b3c] border border-[#1c2b3c] text-[#8ed5ff] text-[10px] font-mono flex items-center gap-1 transition-colors"
                title="Export this filtered table as CSV"
              >
                <Download className="w-3 h-3 text-[#38bdf8]" />
                <span>Export</span>
              </button>
            </div>
          </div>

          {/* Table */}
          <div className="w-full overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-[#122131] text-[#87929a] font-mono text-[10px] uppercase tracking-wider border-b border-[#1c2b3c]">
                  <th className="py-2.5 px-3 font-semibold">Company / Ticker</th>
                  <th className="py-2.5 px-2 font-semibold">Exch</th>
                  <th className="py-2.5 px-3 font-semibold text-right">LTP (₹)</th>
                  <th className="py-2.5 px-3 font-semibold text-right">24h Chg</th>
                  <th className="py-2.5 px-3 font-semibold text-right hidden sm:table-cell">24h Volume</th>
                  <th className="py-2.5 px-3 font-semibold text-center hidden md:table-cell">AI Signal</th>
                  <th className="py-2.5 px-3 font-semibold text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1c2b3c]/60 font-mono">
                {displayedStocks.map((stock) => {
                  const isPositive = stock.changePercent >= 0;
                  return (
                    <tr
                      key={stock.symbol}
                      className="hover:bg-[#122131] transition-colors group cursor-pointer"
                      onClick={() => onSelectStock(stock.symbol)}
                    >
                      <td className="py-2.5 px-3">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-lg bg-[#122131] border border-[#1c2b3c] flex items-center justify-center font-bold text-[10px] text-[#8ed5ff] group-hover:border-[#38bdf8]/40">
                            {stock.symbol.slice(0, 3)}
                          </div>
                          <div className="flex flex-col min-w-0">
                            <span className="font-bold text-xs text-[#d4e4fa] leading-tight">
                              {stock.symbol}
                            </span>
                            <span className="text-[10px] text-[#87929a] font-sans truncate max-w-[120px] sm:max-w-xs">
                              {stock.name}
                            </span>
                          </div>
                        </div>
                      </td>
                      <td className="py-2.5 px-2">
                        <span className="px-1.5 py-0.5 rounded bg-[#1c2b3c] text-[9px] text-[#bdc8d1]">
                          {stock.exchange}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right font-bold text-[#d4e4fa]">
                        ₹{stock.ltp.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </td>
                      <td className="py-2.5 px-3 text-right">
                        <span
                          className={`inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold ${
                            isPositive
                              ? 'bg-[#56e5a9]/15 text-[#56e5a9]'
                              : 'bg-[#ffb4ab]/15 text-[#ffb4ab]'
                          }`}
                        >
                          {isPositive ? '+' : ''}{stock.changePercent.toFixed(2)}%
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right text-[#87929a] hidden sm:table-cell">
                        {(stock.volume / 1000000).toFixed(2)}M
                      </td>
                      <td className="py-2.5 px-3 text-center hidden md:table-cell">
                        <span
                          className={`px-2 py-0.5 rounded text-[9px] font-semibold ${
                            stock.aiSignal === 'Strong Buy' || stock.aiSignal === 'Bullish'
                              ? 'bg-[#56e5a9]/15 text-[#56e5a9]'
                              : stock.aiSignal === 'Bearish'
                              ? 'bg-[#ffb4ab]/15 text-[#ffb4ab]'
                              : 'bg-[#1c2b3c] text-[#87929a]'
                          }`}
                        >
                          {stock.aiSignal} ({stock.aiConfidence}%)
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-right font-sans">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onSelectStock(stock.symbol);
                          }}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-[#122131] hover:bg-[#38bdf8] hover:text-[#00354a] text-[#8ed5ff] text-[10px] font-semibold transition-colors"
                        >
                          <span>Analyze</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="p-2.5 bg-[#122131] border-t border-[#1c2b3c] flex items-center justify-between text-[10px] font-mono text-[#87929a]">
            <span>Showing {displayedStocks.length} of {stocks.length} Selected Equities</span>
            <span className="text-[#56e5a9]">Click any row for Deep Technical Analysis</span>
          </div>
        </div>

        {/* Right Column: Market Breadth, AI Radar & Alerts (4 cols) */}
        <div className="lg:col-span-4 flex flex-col gap-4">
          {/* Market Breadth & Sector Velocity */}
          <div className="p-3.5 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] shadow-sm flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-[#d4e4fa] uppercase tracking-wider">
                Market Breadth & Sectors
              </h3>
              <span className="font-mono text-[10px] text-[#56e5a9] font-semibold">Net Bullish</span>
            </div>

            <div>
              <div className="flex items-center justify-between font-mono text-[10px] mb-1">
                <span className="text-[#56e5a9] font-bold">1,420 Advances (68%)</span>
                <span className="text-[#ffb4ab] font-bold">650 Declines (32%)</span>
              </div>
              <div className="w-full h-1.5 rounded-full bg-[#1c2b3c] overflow-hidden flex">
                <div className="h-full bg-[#56e5a9]" style={{ width: '68.6%' }}></div>
                <div className="h-full bg-[#ffb4ab]" style={{ width: '31.4%' }}></div>
              </div>
            </div>

            <div>
              <span className="font-mono text-[9px] uppercase tracking-wider text-[#87929a] block mb-1.5">
                Sector Velocity Today
              </span>
              <div className="grid grid-cols-3 gap-1.5 text-center font-mono text-[10px]">
                <div className="p-1.5 rounded bg-[#122131] border border-[#1c2b3c]">
                  <span className="block text-[#87929a] text-[9px]">NIFTY IT</span>
                  <span className="font-bold text-[#56e5a9]">+1.60%</span>
                </div>
                <div className="p-1.5 rounded bg-[#122131] border border-[#1c2b3c]">
                  <span className="block text-[#87929a] text-[9px]">AUTO</span>
                  <span className="font-bold text-[#56e5a9]">+1.20%</span>
                </div>
                <div className="p-1.5 rounded bg-[#122131] border border-[#1c2b3c]">
                  <span className="block text-[#87929a] text-[9px]">ENERGY</span>
                  <span className="font-bold text-[#56e5a9]">+0.90%</span>
                </div>
                <div className="p-1.5 rounded bg-[#122131] border border-[#1c2b3c]">
                  <span className="block text-[#87929a] text-[9px]">METAL</span>
                  <span className="font-bold text-[#56e5a9]">+0.80%</span>
                </div>
                <div className="p-1.5 rounded bg-[#122131] border border-[#1c2b3c]">
                  <span className="block text-[#87929a] text-[9px]">BANKING</span>
                  <span className="font-bold text-[#ffb4ab]">-0.20%</span>
                </div>
                <div className="p-1.5 rounded bg-[#122131] border border-[#1c2b3c]">
                  <span className="block text-[#87929a] text-[9px]">FMCG</span>
                  <span className="font-bold text-[#ffb4ab]">-0.50%</span>
                </div>
              </div>
            </div>
          </div>

          {/* AI Prediction Radar Card */}
          <div className="p-3.5 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] shadow-sm flex flex-col gap-2.5 relative overflow-hidden">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <BrainCircuit className="w-4 h-4 text-[#38bdf8]" />
                <h3 className="text-xs font-bold text-[#d4e4fa]">AI Prediction Radar</h3>
              </div>
              <span className="font-mono text-[9px] px-1.5 py-0.5 rounded bg-[#3131c0]/30 text-[#c0c1ff]">
                T+1 Horizon
              </span>
            </div>

            <div className="p-2.5 rounded-lg bg-[#122131] border border-[#1c2b3c] flex flex-col gap-1.5">
              <div className="flex items-center justify-between text-[10px] font-mono">
                <span className="text-[#87929a]">TOP PREDICTED GAINER</span>
                <span className="text-[#56e5a9] font-bold">82% CONFIDENCE</span>
              </div>
              <div className="flex items-baseline justify-between">
                <div>
                  <span className="font-mono text-base font-bold text-[#d4e4fa]">INFY</span>
                  <span className="text-[10px] text-[#87929a] ml-1">(NSE)</span>
                </div>
                <span className="font-mono text-sm font-bold text-[#56e5a9]">+1.85% PROJ.</span>
              </div>
              <div className="w-full h-1 rounded-full bg-[#1c2b3c] overflow-hidden">
                <div className="h-full bg-[#56e5a9] rounded-full" style={{ width: '82%' }}></div>
              </div>
            </div>

            <button
              onClick={onNavigateToPredictions}
              className="w-full py-2 rounded-lg bg-[#122131] hover:bg-[#1c2b3c] border border-[#1c2b3c] text-[#8ed5ff] text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
            >
              <span>Explore All AI Predictions</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Algorithmic Telemetry Alerts */}
          <div className="p-3.5 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] shadow-sm flex flex-col gap-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-[#87929a]" />
                <h3 className="text-xs font-bold text-[#d4e4fa]">Algorithmic Telemetry</h3>
              </div>
              <span className="font-mono text-[9px] text-[#87929a]">Signals Stream</span>
            </div>

            <div className="space-y-2">
              <div className="p-2 rounded-lg bg-[#122131] border border-[#1c2b3c] text-[11px]">
                <div className="flex items-center justify-between font-mono text-[10px]">
                  <span className="font-bold text-[#56e5a9]">RELIANCE</span>
                  <span className="text-[#87929a]">14:15 IST</span>
                </div>
                <p className="text-[#bdc8d1] mt-0.5 leading-snug">
                  Crossed above 20-Day EMA (₹2,642) with expanding institutional volume.
                </p>
              </div>

              <div className="p-2 rounded-lg bg-[#122131] border border-[#1c2b3c] text-[11px]">
                <div className="flex items-center justify-between font-mono text-[10px]">
                  <span className="font-bold text-[#38bdf8]">NIFTY IT</span>
                  <span className="text-[#87929a]">12:30 IST</span>
                </div>
                <p className="text-[#bdc8d1] mt-0.5 leading-snug">
                  14-Day RSI reaches 68.4. Approaching overbought upper resistance threshold.
                </p>
              </div>

              <div className="p-2 rounded-lg bg-[#122131] border border-[#1c2b3c] text-[11px]">
                <div className="flex items-center justify-between font-mono text-[10px]">
                  <span className="font-bold text-[#ffb4ab]">SBIN</span>
                  <span className="text-[#87929a]">09:45 IST</span>
                </div>
                <p className="text-[#bdc8d1] mt-0.5 leading-snug">
                  RSI bearish divergence on PSU Banking index; support at ₹778 test.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
