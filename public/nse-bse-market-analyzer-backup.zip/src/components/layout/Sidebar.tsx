import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  CandlestickChart, 
  BrainCircuit, 
  ShieldAlert, 
  GitCompare, 
  Star, 
  FileText, 
  Settings, 
  X, 
  User, 
  MoreVertical, 
  Activity, 
  LogIn, 
  LogOut, 
  UserCheck 
} from 'lucide-react';
import { NavigationTab } from '../../types/market';
import { UserProfile } from '../../types/auth';

interface SidebarProps {
  currentTab: NavigationTab;
  onNavigate: (tab: NavigationTab) => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
  currentUser: UserProfile | null;
  onOpenAuth: (mode?: 'signin' | 'signup' | 'profile') => void;
  onSignOut: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onNavigate,
  mobileOpen,
  onCloseMobile,
  currentUser,
  onOpenAuth,
  onSignOut
}) => {
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);

  const navItems = [
    {
      id: 'dashboard' as NavigationTab,
      label: 'Dashboard',
      icon: LayoutDashboard,
      badge: null
    },
    {
      id: 'stock-analysis' as NavigationTab,
      label: 'Stock Analysis',
      icon: CandlestickChart,
      badge: null
    },
    {
      id: 'ai-predictions' as NavigationTab,
      label: 'AI Predictions',
      icon: BrainCircuit,
      badge: 'ML'
    },
    {
      id: 'risk-analysis' as NavigationTab,
      label: 'Risk Analysis',
      icon: ShieldAlert,
      badge: null
    },
    {
      id: 'stock-comparison' as NavigationTab,
      label: 'Stock Comparison',
      icon: GitCompare,
      badge: null
    },
    {
      id: 'watchlist' as NavigationTab,
      label: 'Watchlist',
      icon: Star,
      badge: null
    },
    {
      id: 'reports' as NavigationTab,
      label: 'Reports',
      icon: FileText,
      badge: null
    },
    {
      id: 'settings' as NavigationTab,
      label: 'Settings',
      icon: Settings,
      badge: null
    }
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/75 lg:hidden backdrop-blur-sm"
          onClick={onCloseMobile}
        />
      )}

      {/* Sidebar Panel */}
      <aside
        className={`fixed left-0 top-0 h-full w-64 bg-[#010f1f] border-r border-[#1c2b3c] z-50 flex flex-col justify-between transition-transform duration-200 select-none ${
          mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        <div className="flex flex-col">
          {/* Logo & Terminal Header */}
          <div className="h-16 px-4 flex items-center justify-between border-b border-[#1c2b3c]">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-[#122131] border border-[#1c2b3c] flex items-center justify-center text-[#38bdf8] shadow-sm">
                <Activity className="w-4 h-4" />
              </div>
              <div className="flex flex-col">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-sm text-[#d4e4fa] tracking-tight">
                    NSE-BSE
                  </span>
                  <span className="font-mono text-[9px] uppercase px-1 py-0.5 rounded bg-[#1c2b3c] text-[#8ed5ff] border border-[#273647]">
                    v2.4
                  </span>
                </div>
                <span className="font-mono text-[10px] text-[#87929a] uppercase tracking-wider">
                  AI/ML Terminal
                </span>
              </div>
            </div>

            {/* Mobile Close Button */}
            <button
              onClick={onCloseMobile}
              className="lg:hidden p-1.5 rounded-lg text-[#87929a] hover:text-[#d4e4fa] hover:bg-[#122131]"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Nav Section Label */}
          <div className="px-4 pt-4 pb-1">
            <span className="font-mono text-[10px] uppercase tracking-widest text-[#87929a]">
              Terminal Core
            </span>
          </div>

          {/* Navigation Links */}
          <nav className="flex flex-col gap-1 px-2 mt-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;

              return (
                <button
                  key={item.id}
                  onClick={() => {
                    onNavigate(item.id);
                    onCloseMobile();
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs transition-all relative ${
                    isActive
                      ? 'bg-[#1c2b3c] text-[#8ed5ff] font-semibold after:absolute after:left-0 after:top-1.5 after:bottom-1.5 after:w-1 after:bg-[#38bdf8] after:rounded-r shadow-[0_0_12px_rgba(56,189,248,0.15)]'
                      : 'text-[#bdc8d1] hover:bg-[#122131] hover:text-[#d4e4fa]'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-[#38bdf8]' : 'text-[#87929a]'}`} />
                    <span>{item.label}</span>
                  </div>

                  {item.badge && (
                    <span className="font-mono text-[9px] px-1.5 py-0.2 rounded bg-[#3131c0]/40 text-[#c0c1ff] border border-[#c0c1ff]/20">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Footer Meta & Profile */}
        <div className="p-3 flex flex-col gap-2.5 border-t border-[#1c2b3c] relative">
          {/* Project Meta Box */}
          <div className="p-2.5 rounded-lg bg-[#0d1c2d] border border-[#1c2b3c]">
            <div className="flex items-center gap-1.5 mb-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#56e5a9]"></span>
              <span className="font-mono text-[10px] uppercase tracking-wider text-[#bdc8d1]">
                Project Meta
              </span>
            </div>
            <p className="text-[11px] text-[#bdc8d1] leading-tight font-medium">
              B.Tech AI & ML Capstone
            </p>
            <p className="font-mono text-[10px] text-[#87929a] mt-0.5">
              Engine: Scikit-learn & Pandas
            </p>
          </div>

          {/* Profile Card / Sign In Prompt */}
          {currentUser ? (
            <div className="relative">
              <div 
                onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                className="p-2 rounded-lg bg-[#122131] hover:bg-[#1c2b3c] transition-colors flex items-center justify-between border border-[#1c2b3c] cursor-pointer"
              >
                <div className="flex items-center gap-2 min-w-0">
                  <div className="relative shrink-0">
                    <div className="w-8 h-8 rounded-full bg-[#051424] border border-[#38bdf8]/40 flex items-center justify-center text-[#38bdf8] font-bold text-xs">
                      {currentUser.displayName ? currentUser.displayName.charAt(0).toUpperCase() : 'U'}
                    </div>
                    <span className="absolute bottom-0 right-0 w-2 h-2 rounded-full bg-[#56e5a9] ring-2 ring-[#010f1f]"></span>
                  </div>
                  <div className="flex flex-col min-w-0">
                    <span className="text-xs font-semibold text-[#d4e4fa] leading-tight truncate">
                      {currentUser.displayName}
                    </span>
                    <span className="font-mono text-[10px] text-[#87929a] truncate">
                      {currentUser.email}
                    </span>
                  </div>
                </div>
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    setProfileDropdownOpen(!profileDropdownOpen);
                  }}
                  className="text-[#87929a] hover:text-[#d4e4fa] p-1" 
                  aria-label="Profile options"
                >
                  <MoreVertical className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Profile Dropdown Menu */}
              {profileDropdownOpen && (
                <>
                  <div 
                    className="fixed inset-0 z-30" 
                    onClick={() => setProfileDropdownOpen(false)} 
                  />
                  <div className="absolute bottom-12 left-0 right-0 z-40 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] shadow-2xl p-2 flex flex-col gap-1 text-xs">
                    <button
                      onClick={() => {
                        setProfileDropdownOpen(false);
                        onOpenAuth('profile');
                      }}
                      className="w-full text-left px-2.5 py-2 rounded-lg hover:bg-[#122131] text-[#d4e4fa] flex items-center gap-2 transition-colors"
                    >
                      <UserCheck className="w-4 h-4 text-[#38bdf8]" />
                      <span>Edit Display Profile</span>
                    </button>
                    <button
                      onClick={() => {
                        setProfileDropdownOpen(false);
                        onNavigate('settings');
                      }}
                      className="w-full text-left px-2.5 py-2 rounded-lg hover:bg-[#122131] text-[#d4e4fa] flex items-center gap-2 transition-colors"
                    >
                      <Settings className="w-4 h-4 text-[#87929a]" />
                      <span>Terminal Settings</span>
                    </button>
                    <div className="h-[1px] bg-[#1c2b3c] my-0.5" />
                    <button
                      onClick={() => {
                        setProfileDropdownOpen(false);
                        onSignOut();
                      }}
                      className="w-full text-left px-2.5 py-2 rounded-lg hover:bg-[#93000a]/20 text-[#ffb4ab] flex items-center gap-2 transition-colors"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </>
              )}
            </div>
          ) : (
            <div className="p-2.5 rounded-lg bg-[#122131] border border-[#1c2b3c] flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-full bg-[#051424] border border-[#1c2b3c] flex items-center justify-center text-[#87929a]">
                  <User className="w-3.5 h-3.5" />
                </div>
                <div>
                  <span className="text-xs font-semibold text-[#d4e4fa] block leading-tight">
                    Guest Mode
                  </span>
                  <span className="font-mono text-[9px] text-[#87929a]">
                    Watchlists not synced
                  </span>
                </div>
              </div>
              <button
                onClick={() => onOpenAuth('signin')}
                className="w-full py-1.5 rounded-md bg-[#38bdf8] text-[#00354a] font-semibold text-xs flex items-center justify-center gap-1.5 hover:brightness-110 transition-all shadow-sm"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Sign In / Register</span>
              </button>
            </div>
          )}
        </div>
      </aside>
    </>
  );
};
