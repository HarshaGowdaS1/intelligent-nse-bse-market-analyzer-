import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { MarketIndex, StockQuote } from '../../types/market';

interface TickerTapeProps {
  indices: MarketIndex[];
  stocks: StockQuote[];
  onSelectStock?: (symbol: string) => void;
}

export const TickerTape: React.FC<TickerTapeProps> = ({ indices, stocks, onSelectStock }) => {
  // Combine indices and stocks into a unified ticker ribbon
  const items = [
    ...indices.map(idx => ({
      key: `idx-${idx.symbol}`,
      label: idx.symbol,
      value: idx.value.toLocaleString('en-IN', { minimumFractionDigits: 2 }),
      change: `${idx.changePercent >= 0 ? '+' : ''}${idx.changePercent.toFixed(2)}%`,
      isPositive: idx.changePercent >= 0,
      isStock: false,
      symbol: idx.symbol
    })),
    ...stocks.map(stk => ({
      key: `stk-${stk.symbol}`,
      label: stk.symbol,
      value: `₹${stk.ltp.toLocaleString('en-IN', { minimumFractionDigits: 2 })}`,
      change: `${stk.changePercent >= 0 ? '+' : ''}${stk.changePercent.toFixed(2)}%`,
      isPositive: stk.changePercent >= 0,
      isStock: true,
      symbol: stk.symbol
    }))
  ];

  // Duplicate list to create a seamless infinite marquee loop
  const marqueeItems = [...items, ...items];

  return (
    <div className="h-8 bg-[#010f1f] border-b border-[#1c2b3c] flex items-center overflow-hidden select-none">
      <div className="px-3 flex items-center gap-1.5 bg-[#010f1f] z-10 shrink-0 border-r border-[#1c2b3c]">
        <span className="w-2 h-2 rounded-full bg-[#56e5a9] animate-pulse"></span>
        <span className="font-mono text-[10px] font-bold text-[#8ed5ff] uppercase tracking-wider">
          DEMO TICKER
        </span>
      </div>

      <div className="overflow-hidden w-full relative">
        <div className="animate-marquee flex items-center gap-6 text-[11px] font-mono whitespace-nowrap pl-4">
          {marqueeItems.map((item, index) => (
            <div
              key={`${item.key}-${index}`}
              onClick={() => {
                if (item.isStock && onSelectStock) {
                  onSelectStock(item.symbol);
                }
              }}
              className={`flex items-center gap-1.5 shrink-0 ${
                item.isStock ? 'cursor-pointer hover:text-[#38bdf8] transition-colors' : ''
              }`}
            >
              <span className="text-[#d4e4fa] font-semibold">{item.label}</span>
              <span className="text-[#87929a]">{item.value}</span>
              <span
                className={`flex items-center font-semibold text-[10px] ${
                  item.isPositive ? 'text-[#56e5a9]' : 'text-[#ffb4ab]'
                }`}
              >
                {item.isPositive ? (
                  <TrendingUp className="w-3 h-3 inline mr-0.5" />
                ) : (
                  <TrendingDown className="w-3 h-3 inline mr-0.5" />
                )}
                {item.change}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
