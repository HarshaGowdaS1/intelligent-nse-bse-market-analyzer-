import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, 
  Calendar, 
  AlertTriangle, 
  Bell, 
  HelpCircle, 
  Menu, 
  X,
  TrendingUp,
  Activity,
  CheckCircle2,
  LogIn,
  User,
  LogOut,
  SlidersHorizontal,
  BookOpen
} from 'lucide-react';
import { Exchange, StockQuote } from '../../types/market';
import { UserProfile } from '../../types/auth';
import { DATA_METADATA } from '../../services/dataService';

interface HeaderProps {
  currentExchange: Exchange;
  onExchangeChange: (exchange: Exchange) => void;
  stocks: StockQuote[];
  onSelectStock: (symbol: string) => void;
  onToggleMobileMenu: () => void;
  currentUser?: UserProfile | null;
  onOpenAuth?: (mode?: 'signin' | 'signup' | 'profile') => void;
  onSignOut?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentExchange,
  onExchangeChange,
  stocks,
  onSelectStock,
  onToggleMobileMenu,
  currentUser,
  onOpenAuth,
  onSignOut
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showDemoModal, setShowDemoModal] = useState(false);
  const [showHelpModal, setShowHelpModal] = useState(false);
  const [showUserDropdown, setShowUserDropdown] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Filter stocks based on query
  const filteredStocks = searchQuery.trim() === '' 
    ? stocks 
    : stocks.filter(s => 
        s.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.sector.toLowerCase().includes(searchQuery.toLowerCase())
      );

  // Global keyboard shortcut: Ctrl+K or Cmd+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        searchInputRef.current?.focus();
        setIsSearchOpen(true);
      } else if (e.key === 'Escape') {
        setIsSearchOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <header className="fixed top-0 left-0 lg:left-64 right-0 z-40 bg-[#051424]/95 backdrop-blur-md border-b border-[#1c2b3c] select-none">
      <div className="h-16 px-4 flex items-center justify-between gap-3">
        {/* Left: Mobile hamburger & Global Search */}
        <div className="flex items-center gap-3 flex-1 max-w-xl">
          <button 
            onClick={onToggleMobileMenu}
            className="lg:hidden p-2 rounded-lg bg-[#0d1c2d] border border-[#1c2b3c] text-[#87929a] hover:text-[#d4e4fa]"
            aria-label="Toggle navigation menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Search bar with dropdown */}
          <div className="relative flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-[#87929a]" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setIsSearchOpen(true);
                }}
                onFocus={() => setIsSearchOpen(true)}
                placeholder="Search stocks (e.g. RELIANCE, TCS, HDFCBANK)..."
                className="w-full h-9 pl-9 pr-14 rounded-lg bg-[#0d1c2d] border border-[#1c2b3c] text-xs text-[#d4e4fa] placeholder-[#87929a] focus:outline-none focus:border-[#38bdf8] transition-colors"
              />
              <div className="absolute right-2.5 top-2 flex items-center">
                <kbd className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-[#1c2b3c] text-[#87929a] border border-[#273647]">
                  ⌘K
                </kbd>
              </div>
            </div>

            {/* Autocomplete Dropdown */}
            {isSearchOpen && (
              <>
                <div 
                  className="fixed inset-0 z-10" 
                  onClick={() => setIsSearchOpen(false)} 
                />
                <div className="absolute left-0 right-0 top-11 z-20 rounded-lg bg-[#0d1c2d] border border-[#1c2b3c] shadow-2xl overflow-hidden max-h-80 overflow-y-auto">
                  <div className="p-2 border-b border-[#1c2b3c] text-[10px] font-mono uppercase text-[#87929a] flex justify-between items-center">
                    <span>Equities Directory ({filteredStocks.length})</span>
                    <span>ESC to close</span>
                  </div>
                  {filteredStocks.length === 0 ? (
                    <div className="p-4 text-center text-xs text-[#87929a]">
                      No matching equity counters found for "{searchQuery}"
                    </div>
                  ) : (
                    filteredStocks.map((stock) => (
                      <div
                        key={stock.symbol}
                        onClick={() => {
                          onSelectStock(stock.symbol);
                          setIsSearchOpen(false);
                          setSearchQuery('');
                        }}
                        className="px-3 py-2 hover:bg-[#122131] transition-colors cursor-pointer flex items-center justify-between border-b border-[#1c2b3c]/50 last:border-b-0"
                      >
                        <div className="flex items-center gap-2.5">
                          <span className="font-mono text-xs font-bold text-[#8ed5ff]">
                            {stock.symbol}
                          </span>
                          <span className="text-[11px] text-[#87929a] truncate max-w-[180px] sm:max-w-xs">
                            {stock.name}
                          </span>
                        </div>
                        <div className="text-right">
                          <div className="font-mono text-xs text-[#d4e4fa]">
                            ₹{stock.ltp.toFixed(2)}
                          </div>
                          <div className={`font-mono text-[10px] ${stock.changePercent >= 0 ? 'text-[#56e5a9]' : 'text-[#ffb4ab]'}`}>
                            {stock.changePercent >= 0 ? '+' : ''}{stock.changePercent.toFixed(2)}%
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </>
            )}
          </div>

          {/* NSE / BSE Toggle */}
          <div className="hidden sm:flex items-center p-0.5 rounded-lg bg-[#0d1c2d] border border-[#1c2b3c]">
            <button
              onClick={() => onExchangeChange('NSE')}
              className={`px-2.5 py-1 rounded text-[11px] font-mono font-semibold transition-colors ${
                currentExchange === 'NSE'
                  ? 'bg-[#38bdf8] text-[#00354a] shadow-sm'
                  : 'text-[#87929a] hover:text-[#d4e4fa]'
              }`}
            >
              NSE
            </button>
            <button
              onClick={() => onExchangeChange('BSE')}
              className={`px-2.5 py-1 rounded text-[11px] font-mono font-semibold transition-colors ${
                currentExchange === 'BSE'
                  ? 'bg-[#38bdf8] text-[#00354a] shadow-sm'
                  : 'text-[#87929a] hover:text-[#d4e4fa]'
              }`}
            >
              BSE
            </button>
          </div>
        </div>

        {/* Right side status items */}
        <div className="flex items-center gap-2 sm:gap-2.5">
          {/* Market Status Pill */}
          <div className="hidden xl:flex items-center gap-2 px-2.5 py-1 rounded-full bg-[#0d1c2d] border border-[#1c2b3c]">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#ffb4ab] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#ffb4ab]"></span>
            </span>
            <span className="font-mono text-[10px] text-[#bdc8d1] uppercase">
              Market Closed (Demo) • 15:30 IST
            </span>
          </div>

          {/* Date Tag */}
          <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#0d1c2d] border border-[#1c2b3c] text-[#87929a] text-[11px]">
            <Calendar className="w-3.5 h-3.5" />
            <span className="font-mono">24 Oct 2024 - Today</span>
          </div>

          {/* Demo Dataset Warning Pill */}
          <button
            onClick={() => setShowDemoModal(true)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#93000a]/20 border border-[#ffb4ab]/30 text-[#ffb4ab] hover:bg-[#93000a]/30 transition-colors text-[11px] font-mono"
            title="Click to view dataset provenance"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span className="hidden sm:inline font-semibold">Demo Dataset</span>
          </button>

          {/* Notifications */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative p-2 rounded-lg text-[#87929a] hover:text-[#d4e4fa] hover:bg-[#122131] transition-colors"
              aria-label="View algorithmic notifications"
            >
              <Bell className="w-4 h-4" />
              <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-[#38bdf8]"></span>
            </button>

            {showNotifications && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setShowNotifications(false)} />
                <div className="absolute right-0 top-11 z-20 w-80 rounded-lg bg-[#0d1c2d] border border-[#1c2b3c] shadow-2xl p-3">
                  <div className="flex items-center justify-between pb-2 border-b border-[#1c2b3c]">
                    <span className="font-mono text-xs font-bold text-[#8ed5ff]">
                      ALGORITHMIC RADAR ALERTS
                    </span>
                    <span className="text-[10px] font-mono text-[#56e5a9]">3 Unread</span>
                  </div>
                  <div className="space-y-2 mt-2">
                    <div className="p-2 rounded bg-[#122131] border border-[#1c2b3c] text-xs">
                      <div className="flex justify-between font-mono text-[10px] text-[#56e5a9] font-bold">
                        <span>RELIANCE • Bullish EMA Cross</span>
                        <span>14:15 IST</span>
                      </div>
                      <p className="text-[11px] text-[#bdc8d1] mt-0.5">
                        Price crossed 20-Day EMA (₹2,642) with expanding institutional volume.
                      </p>
                    </div>

                    <div className="p-2 rounded bg-[#122131] border border-[#1c2b3c] text-xs">
                      <div className="flex justify-between font-mono text-[10px] text-[#38bdf8] font-bold">
                        <span>INFY • AI Forecast T+1 Signal</span>
                        <span>13:50 IST</span>
                      </div>
                      <p className="text-[11px] text-[#bdc8d1] mt-0.5">
                        High backtest confidence (82%) with projected +1.85% upside target.
                      </p>
                    </div>

                    <div className="p-2 rounded bg-[#122131] border border-[#1c2b3c] text-xs">
                      <div className="flex justify-between font-mono text-[10px] text-[#ffb4ab] font-bold">
                        <span>TATAMOTORS • High Volume Outlier</span>
                        <span>10:45 IST</span>
                      </div>
                      <p className="text-[11px] text-[#bdc8d1] mt-0.5">
                        Intraday volume surpassed 20-Day Average by 1.66x (14.8M traded).
                      </p>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Quick Help Guide Button */}
          <button
            onClick={() => setShowHelpModal(true)}
            className="p-2 rounded-lg text-[#87929a] hover:text-[#38bdf8] hover:bg-[#122131] transition-colors"
            title="Terminal & Indicator Formulas Guide"
            aria-label="View terminal documentation"
          >
            <HelpCircle className="w-4 h-4" />
          </button>

          {/* User Account / Auth Trigger */}
          <div className="relative">
            {currentUser ? (
              <div>
                <button
                  onClick={() => setShowUserDropdown(!showUserDropdown)}
                  className="flex items-center gap-2 p-1 sm:px-2.5 sm:py-1 rounded-lg bg-[#0d1c2d] hover:bg-[#122131] border border-[#1c2b3c] transition-all"
                >
                  <div className="w-6 h-6 rounded-full bg-[#122131] border border-[#38bdf8]/50 flex items-center justify-center text-[#38bdf8] font-bold text-xs">
                    {currentUser.displayName ? currentUser.displayName.slice(0, 2).toUpperCase() : 'U'}
                  </div>
                  <div className="hidden md:flex flex-col text-left">
                    <span className="font-mono text-xs font-semibold text-[#d4e4fa] leading-none">
                      {currentUser.displayName || currentUser.email.split('@')[0]}
                    </span>
                    <span className="text-[9px] text-[#87929a] leading-none mt-0.5">
                      {currentUser.roleTitle || 'Analyst'}
                    </span>
                  </div>
                </button>

                {showUserDropdown && (
                  <>
                    <div className="fixed inset-0 z-10" onClick={() => setShowUserDropdown(false)} />
                    <div className="absolute right-0 top-11 z-20 w-56 rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] shadow-2xl p-2 font-mono">
                      <div className="px-3 py-2 border-b border-[#1c2b3c]">
                        <span className="block text-xs font-bold text-[#d4e4fa] truncate">
                          {currentUser.displayName || 'Analyst'}
                        </span>
                        <span className="block text-[10px] text-[#87929a] truncate font-sans">
                          {currentUser.email}
                        </span>
                        <span className="inline-block mt-1 text-[9px] px-1.5 py-0.2 rounded bg-[#122131] text-[#38bdf8] font-mono">
                          {currentUser.roleTitle || 'Quantitative Analyst'}
                        </span>
                      </div>

                      <div className="py-1">
                        <button
                          onClick={() => {
                            setShowUserDropdown(false);
                            onOpenAuth?.('profile');
                          }}
                          className="w-full px-3 py-1.5 rounded-lg text-left text-xs text-[#bdc8d1] hover:bg-[#122131] hover:text-[#d4e4fa] flex items-center gap-2 transition-colors"
                        >
                          <User className="w-3.5 h-3.5 text-[#38bdf8]" />
                          <span>Edit Profile</span>
                        </button>
                      </div>

                      <div className="pt-1 border-t border-[#1c2b3c]">
                        <button
                          onClick={() => {
                            setShowUserDropdown(false);
                            onSignOut?.();
                          }}
                          className="w-full px-3 py-1.5 rounded-lg text-left text-xs text-[#ffb4ab] hover:bg-[#93000a]/20 flex items-center gap-2 transition-colors"
                        >
                          <LogOut className="w-3.5 h-3.5" />
                          <span>Sign Out</span>
                        </button>
                      </div>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <button
                onClick={() => onOpenAuth?.('signin')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#38bdf8] text-[#00354a] font-semibold text-xs hover:brightness-110 shadow-sm transition-all"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Sign In</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Demo Dataset Explanation Modal */}
      {showDemoModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] p-5 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#1c2b3c]">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-[#f59e0b]" />
                <h3 className="font-semibold text-sm text-[#d4e4fa]">
                  Dataset & Academic Model Provenance
                </h3>
              </div>
              <button
                onClick={() => setShowDemoModal(false)}
                className="text-[#87929a] hover:text-[#d4e4fa]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="py-4 space-y-3 text-xs text-[#bdc8d1] leading-relaxed">
              <p>
                This terminal is running in <strong>Academic Sandbox Mode</strong> for a B.Tech Artificial Intelligence & Machine Learning final-year capstone project.
              </p>
              <div className="p-3 rounded-lg bg-[#010f1f] border border-[#1c2b3c] space-y-1.5 font-mono text-[11px]">
                <div className="flex justify-between">
                  <span className="text-[#87929a]">Source Data:</span>
                  <span className="text-[#8ed5ff]">EOD Synthetic Sample Snapshot</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#87929a]">Anchor Date:</span>
                  <span className="text-[#d4e4fa]">24 Oct 2024, 15:30 IST</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#87929a]">Universe:</span>
                  <span className="text-[#d4e4fa]">NSE Bluechips (10 Key Counters)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#87929a]">Prediction Engine:</span>
                  <span className="text-[#56e5a9]">Scikit-learn Regressors (Simulated Demo)</span>
                </div>
              </div>
              <p className="text-[11px] text-[#87929a]">
                <strong>Compliance Note:</strong> Prices are never presented as real-time live quotes. When live API keys (e.g. Zerodha Kite Connect, Upstox, or Alpha Vantage) are connected in Phase 2, this sandbox indicator will toggle to a verified live broker feed.
              </p>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setShowDemoModal(false)}
                className="px-4 py-2 rounded-lg bg-[#38bdf8] text-[#00354a] font-semibold text-xs hover:brightness-110 transition-all"
              >
                Understood
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Terminal & Mathematical Guide Modal */}
      {showHelpModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
          <div className="w-full max-w-2xl max-h-[85vh] overflow-y-auto rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] p-5 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-[#1c2b3c]">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-[#38bdf8]" />
                <h3 className="font-semibold text-base text-[#d4e4fa]">
                  NSE-BSE Market Analyzer — Mathematical & Architecture Guide
                </h3>
              </div>
              <button
                onClick={() => setShowHelpModal(false)}
                className="text-[#87929a] hover:text-[#d4e4fa]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="py-4 space-y-4 text-xs text-[#bdc8d1] leading-relaxed">
              <div className="p-3 rounded-lg bg-[#010f1f] border border-[#1c2b3c]">
                <h4 className="font-bold text-[#8ed5ff] text-xs uppercase mb-1">
                  1. Technical Indicator Formulations
                </h4>
                <ul className="space-y-1.5 font-mono text-[11px]">
                  <li>• <strong className="text-[#d4e4fa]">SMA(n):</strong> Arithmetic mean of last n closing prices.</li>
                  <li>• <strong className="text-[#d4e4fa]">EMA(n):</strong> Weighted moving average with smoothing multiplier α = 2 / (n + 1).</li>
                  <li>• <strong className="text-[#d4e4fa]">RSI(14):</strong> Wilder's smoothed 14-period RS ratio: 100 - (100 / (1 + RS)).</li>
                  <li>• <strong className="text-[#d4e4fa]">MACD(12, 26, 9):</strong> EMA(12) - EMA(26); Signal line is EMA(9) of the MACD difference.</li>
                  <li>• <strong className="text-[#d4e4fa]">Bollinger Bands:</strong> 20-SMA ± 2 standard deviations.</li>
                </ul>
              </div>

              <div className="p-3 rounded-lg bg-[#010f1f] border border-[#1c2b3c]">
                <h4 className="font-bold text-[#8ed5ff] text-xs uppercase mb-1">
                  2. Quantitative Risk Metrics & Assumptions
                </h4>
                <ul className="space-y-1.5 font-mono text-[11px]">
                  <li>• <strong className="text-[#d4e4fa]">Risk-Free Rate (Rf):</strong> 6.85% p.a. (benchmarked to Reserve Bank of India 10Y G-Sec yield).</li>
                  <li>• <strong className="text-[#d4e4fa]">Sharpe Ratio:</strong> (Annualized Return - Rf) / Annualized Volatility (assuming 252 trading sessions/year).</li>
                  <li>• <strong className="text-[#d4e4fa]">Value-at-Risk (VaR 95%):</strong> Empirical 5th percentile of daily logarithmic returns multiplied by current price.</li>
                  <li>• <strong className="text-[#d4e4fa]">Conditional VaR (CVaR 95%):</strong> Expected shortfall representing average loss when daily returns breach the 95% VaR threshold.</li>
                  <li>• <strong className="text-[#d4e4fa]">Beta (β):</strong> Covariance(Stock, Nifty 50) / Variance(Nifty 50) on synchronized log returns.</li>
                </ul>
              </div>

              <div className="p-3 rounded-lg bg-[#010f1f] border border-[#1c2b3c]">
                <h4 className="font-bold text-[#8ed5ff] text-xs uppercase mb-1">
                  3. Academic Capstone Machine Learning Architecture
                </h4>
                <p className="text-[11px]">
                  The predictive subsystem demonstrates Random Forest Regressors and Gradient Boosted trees for T+1, T+5, and T+15 forecast horizons. Chronological time-series walk-forward validation (split date: 01-Jun-2024) is strictly enforced to eliminate look-ahead bias and data leakage.
                </p>
              </div>
            </div>

            <div className="flex justify-end pt-2 border-t border-[#1c2b3c]">
              <button
                onClick={() => setShowHelpModal(false)}
                className="px-4 py-2 rounded-lg bg-[#38bdf8] text-[#00354a] font-semibold text-xs hover:brightness-110 transition-all"
              >
                Close Documentation
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
