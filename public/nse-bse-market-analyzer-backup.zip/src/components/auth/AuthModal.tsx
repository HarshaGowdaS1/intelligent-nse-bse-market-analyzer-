import React, { useState } from 'react';
import { 
  X, 
  Lock, 
  Mail, 
  User, 
  ArrowRight, 
  KeyRound, 
  ShieldCheck, 
  AlertCircle, 
  CheckCircle2, 
  Eye, 
  EyeOff 
} from 'lucide-react';
import { AuthService } from '../../services/authService';
import { UserProfile } from '../../types/auth';

export type AuthModalMode = 'signin' | 'signup' | 'forgot' | 'profile';

interface AuthModalProps {
  isOpen: boolean;
  initialMode?: AuthModalMode;
  onClose: () => void;
  currentUser: UserProfile | null;
  onAuthSuccess: (user: UserProfile) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  initialMode = 'signin',
  onClose,
  currentUser,
  onAuthSuccess
}) => {
  const [mode, setMode] = useState<AuthModalMode>(initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [displayName, setDisplayName] = useState(currentUser?.displayName || '');
  const [roleTitle, setRoleTitle] = useState(currentUser?.roleTitle || 'Quantitative Analyst');
  const [resetToken, setResetToken] = useState('');
  const [resetStep, setResetStep] = useState<'request' | 'confirm'>('request');
  
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const resetFormState = () => {
    setErrorMsg(null);
    setSuccessMsg(null);
    setPassword('');
    setConfirmPassword('');
  };

  const switchMode = (newMode: AuthModalMode) => {
    resetFormState();
    setMode(newMode);
    if (newMode === 'profile' && currentUser) {
      setDisplayName(currentUser.displayName);
      setRoleTitle(currentUser.roleTitle || 'Quantitative Analyst');
    }
  };

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setIsLoading(true);

    try {
      const user = await AuthService.signIn(email, password);
      onAuthSuccess(user);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to sign in. Please check your credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (password !== confirmPassword) {
      setErrorMsg('Passwords do not match.');
      return;
    }

    setIsLoading(true);
    try {
      const user = await AuthService.signUp(email, password, displayName);
      onAuthSuccess(user);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to create account.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRequestReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setIsLoading(true);

    try {
      const result = await AuthService.requestPasswordReset(email);
      setResetToken(result.token);
      setResetStep('confirm');
      setSuccessMsg(`Reset token generated for ${result.email}. Please set your new password below.`);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to process password reset request.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCompleteReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (password !== confirmPassword) {
      setErrorMsg('Passwords do not match.');
      return;
    }

    setIsLoading(true);
    try {
      await AuthService.completePasswordReset(email, resetToken, password);
      setSuccessMsg('Your password has been successfully reset! You may now sign in.');
      setTimeout(() => {
        switchMode('signin');
      }, 1500);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to reset password.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setIsLoading(true);

    try {
      const updated = await AuthService.updateProfile({ displayName, roleTitle });
      onAuthSuccess(updated);
      setSuccessMsg('Profile updated successfully.');
      setTimeout(() => {
        onClose();
      }, 800);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to update profile.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm select-none">
      <div className="w-full max-w-md rounded-xl bg-[#0d1c2d] border border-[#1c2b3c] shadow-2xl overflow-hidden flex flex-col">
        {/* Modal Top Header */}
        <div className="p-4 bg-[#010f1f] border-b border-[#1c2b3c] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#122131] border border-[#1c2b3c] flex items-center justify-center text-[#38bdf8]">
              {mode === 'profile' ? <User className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
            </div>
            <div>
              <h2 className="font-bold text-sm text-[#d4e4fa] tracking-tight">
                {mode === 'signin' && 'Sign In to Terminal'}
                {mode === 'signup' && 'Create Terminal Account'}
                {mode === 'forgot' && 'Reset Access Password'}
                {mode === 'profile' && 'Edit Quant Profile'}
              </h2>
              <span className="font-mono text-[10px] text-[#87929a] uppercase">
                NSE-BSE Market Analyzer
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[#87929a] hover:text-[#d4e4fa] hover:bg-[#122131] transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 flex flex-col gap-4">
          {/* Feedback Messages */}
          {errorMsg && (
            <div className="p-3 rounded-lg bg-[#93000a]/20 border border-[#ffb4ab]/30 flex items-start gap-2.5 text-xs text-[#ffb4ab]">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3 rounded-lg bg-[#56e5a9]/15 border border-[#56e5a9]/30 flex items-start gap-2.5 text-xs text-[#56e5a9]">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* MODE: SIGN IN */}
          {mode === 'signin' && (
            <form onSubmit={handleSignIn} className="flex flex-col gap-3.5">
              <div>
                <label className="block text-[11px] font-mono text-[#87929a] uppercase mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-2.5 w-4 h-4 text-[#87929a]" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="analyst@university.edu"
                    className="w-full h-9 pl-9 pr-3 rounded-lg bg-[#010f1f] border border-[#1c2b3c] text-xs text-[#d4e4fa] focus:outline-none focus:border-[#38bdf8]"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-[11px] font-mono text-[#87929a] uppercase">
                    Password
                  </label>
                  <button
                    type="button"
                    onClick={() => switchMode('forgot')}
                    className="text-[10px] font-mono text-[#38bdf8] hover:underline"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="absolute left-3 top-2.5 w-4 h-4 text-[#87929a]" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full h-9 pl-9 pr-9 rounded-lg bg-[#010f1f] border border-[#1c2b3c] text-xs text-[#d4e4fa] focus:outline-none focus:border-[#38bdf8]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-[#87929a] hover:text-[#d4e4fa]"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="mt-2 w-full py-2.5 rounded-lg bg-[#38bdf8] text-[#00354a] font-semibold text-xs flex items-center justify-center gap-1.5 hover:brightness-110 transition-all disabled:opacity-50"
              >
                <span>{isLoading ? 'Authenticating...' : 'Sign In to Workspace'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <div className="pt-2 text-center text-xs text-[#87929a]">
                Don't have an account yet?{' '}
                <button
                  type="button"
                  onClick={() => switchMode('signup')}
                  className="text-[#38bdf8] font-semibold hover:underline"
                >
                  Create one now
                </button>
              </div>
            </form>
          )}

          {/* MODE: SIGN UP */}
          {mode === 'signup' && (
            <form onSubmit={handleSignUp} className="flex flex-col gap-3">
              <div>
                <label className="block text-[11px] font-mono text-[#87929a] uppercase mb-1">
                  Display Name / Analyst Handle
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-2.5 w-4 h-4 text-[#87929a]" />
                  <input
                    type="text"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="e.g. Harsha Sharma"
                    className="w-full h-9 pl-9 pr-3 rounded-lg bg-[#010f1f] border border-[#1c2b3c] text-xs text-[#d4e4fa] focus:outline-none focus:border-[#38bdf8]"
                  />
                </div>
                <span className="text-[10px] text-[#87929a] mt-0.5 block">
                  Leave empty to auto-derive from your email prefix.
                </span>
              </div>

              <div>
                <label className="block text-[11px] font-mono text-[#87929a] uppercase mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-2.5 w-4 h-4 text-[#87929a]" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="harsha@gmail.com"
                    className="w-full h-9 pl-9 pr-3 rounded-lg bg-[#010f1f] border border-[#1c2b3c] text-xs text-[#d4e4fa] focus:outline-none focus:border-[#38bdf8]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-mono text-[#87929a] uppercase mb-1">
                  Create Password (min 6 characters)
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-2.5 w-4 h-4 text-[#87929a]" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    minLength={6}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full h-9 pl-9 pr-9 rounded-lg bg-[#010f1f] border border-[#1c2b3c] text-xs text-[#d4e4fa] focus:outline-none focus:border-[#38bdf8]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-[#87929a] hover:text-[#d4e4fa]"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-mono text-[#87929a] uppercase mb-1">
                  Confirm Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-2.5 w-4 h-4 text-[#87929a]" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full h-9 pl-9 pr-3 rounded-lg bg-[#010f1f] border border-[#1c2b3c] text-xs text-[#d4e4fa] focus:outline-none focus:border-[#38bdf8]"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="mt-2 w-full py-2.5 rounded-lg bg-[#38bdf8] text-[#00354a] font-semibold text-xs flex items-center justify-center gap-1.5 hover:brightness-110 transition-all disabled:opacity-50"
              >
                <span>{isLoading ? 'Creating Account...' : 'Register Account'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <div className="pt-2 text-center text-xs text-[#87929a]">
                Already registered?{' '}
                <button
                  type="button"
                  onClick={() => switchMode('signin')}
                  className="text-[#38bdf8] font-semibold hover:underline"
                >
                  Sign In
                </button>
              </div>
            </form>
          )}

          {/* MODE: FORGOT PASSWORD */}
          {mode === 'forgot' && (
            <div className="flex flex-col gap-3">
              {resetStep === 'request' ? (
                <form onSubmit={handleRequestReset} className="flex flex-col gap-3.5">
                  <p className="text-xs text-[#bdc8d1] leading-relaxed">
                    Enter the email address associated with your terminal account to initiate the password reset sequence.
                  </p>
                  <div>
                    <label className="block text-[11px] font-mono text-[#87929a] uppercase mb-1">
                      Account Email
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-2.5 w-4 h-4 text-[#87929a]" />
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="yourname@gmail.com"
                        className="w-full h-9 pl-9 pr-3 rounded-lg bg-[#010f1f] border border-[#1c2b3c] text-xs text-[#d4e4fa] focus:outline-none focus:border-[#38bdf8]"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full py-2.5 rounded-lg bg-[#38bdf8] text-[#00354a] font-semibold text-xs flex items-center justify-center gap-1.5 hover:brightness-110 transition-all disabled:opacity-50"
                  >
                    <span>{isLoading ? 'Processing...' : 'Request Password Reset Token'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  <button
                    type="button"
                    onClick={() => switchMode('signin')}
                    className="text-center text-xs text-[#87929a] hover:text-[#d4e4fa]"
                  >
                    Back to Sign In
                  </button>
                </form>
              ) : (
                <form onSubmit={handleCompleteReset} className="flex flex-col gap-3">
                  <div>
                    <label className="block text-[11px] font-mono text-[#87929a] uppercase mb-1">
                      Verification Token
                    </label>
                    <div className="relative">
                      <KeyRound className="absolute left-3 top-2.5 w-4 h-4 text-[#56e5a9]" />
                      <input
                        type="text"
                        readOnly
                        value={resetToken}
                        className="w-full h-9 pl-9 pr-3 rounded-lg bg-[#010f1f] border border-[#56e5a9]/40 text-xs text-[#56e5a9] font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-mono text-[#87929a] uppercase mb-1">
                      New Password
                    </label>
                    <input
                      type="password"
                      required
                      minLength={6}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full h-9 px-3 rounded-lg bg-[#010f1f] border border-[#1c2b3c] text-xs text-[#d4e4fa] focus:outline-none focus:border-[#38bdf8]"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-mono text-[#87929a] uppercase mb-1">
                      Confirm New Password
                    </label>
                    <input
                      type="password"
                      required
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full h-9 px-3 rounded-lg bg-[#010f1f] border border-[#1c2b3c] text-xs text-[#d4e4fa] focus:outline-none focus:border-[#38bdf8]"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isLoading}
                    className="mt-2 w-full py-2.5 rounded-lg bg-[#56e5a9] text-[#003824] font-semibold text-xs flex items-center justify-center gap-1.5 hover:brightness-110 transition-all disabled:opacity-50"
                  >
                    <span>{isLoading ? 'Updating...' : 'Set New Password'}</span>
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  </button>
                </form>
              )}
            </div>
          )}

          {/* MODE: EDIT PROFILE */}
          {mode === 'profile' && (
            <form onSubmit={handleUpdateProfile} className="flex flex-col gap-3.5">
              <div>
                <label className="block text-[11px] font-mono text-[#87929a] uppercase mb-1">
                  Registered Email (Immutable)
                </label>
                <input
                  type="email"
                  disabled
                  value={currentUser?.email || ''}
                  className="w-full h-9 px-3 rounded-lg bg-[#010f1f]/50 border border-[#1c2b3c] text-xs text-[#87929a] font-mono cursor-not-allowed"
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono text-[#87929a] uppercase mb-1">
                  Display Name
                </label>
                <input
                  type="text"
                  required
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="Your Name"
                  className="w-full h-9 px-3 rounded-lg bg-[#010f1f] border border-[#1c2b3c] text-xs text-[#d4e4fa] focus:outline-none focus:border-[#38bdf8]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono text-[#87929a] uppercase mb-1">
                  Role / Specialization Title
                </label>
                <input
                  type="text"
                  value={roleTitle}
                  onChange={(e) => setRoleTitle(e.target.value)}
                  placeholder="Quant Analyst / Lead"
                  className="w-full h-9 px-3 rounded-lg bg-[#010f1f] border border-[#1c2b3c] text-xs text-[#d4e4fa] focus:outline-none focus:border-[#38bdf8]"
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="mt-2 w-full py-2.5 rounded-lg bg-[#38bdf8] text-[#00354a] font-semibold text-xs flex items-center justify-center gap-1.5 hover:brightness-110 transition-all disabled:opacity-50"
              >
                <span>{isLoading ? 'Saving...' : 'Save Profile Changes'}</span>
                <CheckCircle2 className="w-3.5 h-3.5" />
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
