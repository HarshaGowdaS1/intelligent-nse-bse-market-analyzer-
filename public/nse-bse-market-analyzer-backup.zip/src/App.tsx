/**
 * NSE-BSE Market Analyzer
 * Final-Year B.Tech Artificial Intelligence and Machine Learning Capstone Application
 * 
 * Professional dark financial-terminal interface for quantitative analytics
 * and supervised predictive modeling across Indian equity markets (NSE & BSE).
 */

import React, { useState, useEffect } from 'react';
import { NavigationTab, Exchange, StockQuote, MarketIndex } from './types/market';
import { UserProfile } from './types/auth';
import { AuthService } from './services/authService';
import { UserStorageService } from './services/userStorageService';
import { INITIAL_STOCKS, INITIAL_INDICES } from './services/dataService';
import { Sidebar } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { TickerTape } from './components/layout/TickerTape';
import { DashboardPage } from './components/dashboard/DashboardPage';
import { StockAnalysisPage } from './components/analysis/StockAnalysisPage';
import { AIPredictionsPage } from './components/predictions/AIPredictionsPage';
import { WatchlistPage } from './components/watchlist/WatchlistPage';
import { SettingsPage } from './components/settings/SettingsPage';
import { RoadmapPage } from './components/common/RoadmapPage';
import { AuthModal, AuthModalMode } from './components/auth/AuthModal';

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavigationTab>('dashboard');
  const [currentExchange, setCurrentExchange] = useState<Exchange>('NSE');
  const [selectedStockSymbol, setSelectedStockSymbol] = useState<string>('RELIANCE');
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  // Authentication state
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => AuthService.getCurrentUser());
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalMode, setAuthModalMode] = useState<AuthModalMode>('signin');

  // Watchlist state (dynamically scoped per authenticated user or guest)
  const [watchlistSymbols, setWatchlistSymbols] = useState<string[]>(() => {
    return UserStorageService.getWatchlist(currentUser?.uid);
  });

  // Equities and Indices from Data Service
  const [stocks, setStocks] = useState<StockQuote[]>(INITIAL_STOCKS);
  const [indices, setIndices] = useState<MarketIndex[]>(INITIAL_INDICES);

  // Listen to Auth state changes
  useEffect(() => {
    const unsubscribe = AuthService.onAuthStateChanged((user) => {
      setCurrentUser(user);
      // Reload user's isolated watchlist
      const userWatchlist = UserStorageService.getWatchlist(user?.uid);
      setWatchlistSymbols(userWatchlist);
    });

    return () => unsubscribe();
  }, []);

  const handleOpenAuth = (mode: AuthModalMode = 'signin') => {
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  };

  const handleSignOut = () => {
    AuthService.signOut();
  };

  const handleAddToWatchlist = (symbol: string) => {
    if (!watchlistSymbols.includes(symbol)) {
      const next = [...watchlistSymbols, symbol];
      setWatchlistSymbols(next);
      UserStorageService.saveWatchlist(next, currentUser?.uid);
    }
  };

  const handleRemoveFromWatchlist = (symbol: string) => {
    const next = watchlistSymbols.filter(s => s !== symbol);
    setWatchlistSymbols(next);
    UserStorageService.saveWatchlist(next, currentUser?.uid);
  };

  const handleSelectStock = (symbol: string) => {
    setSelectedStockSymbol(symbol);
    setCurrentTab('stock-analysis');
  };

  const handleNavigateToPredictions = (symbol?: string) => {
    if (symbol) {
      setSelectedStockSymbol(symbol);
    }
    setCurrentTab('ai-predictions');
  };

  return (
    <div className="min-h-screen bg-[#051424] text-[#d4e4fa] flex">
      {/* Left Persistent / Responsive Sidebar */}
      <Sidebar
        currentTab={currentTab}
        onNavigate={(tab) => setCurrentTab(tab)}
        mobileOpen={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
        currentUser={currentUser}
        onOpenAuth={handleOpenAuth}
        onSignOut={handleSignOut}
      />

      {/* Main Workspace Frame */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        {/* Top Header Bar */}
        <Header
          currentExchange={currentExchange}
          onExchangeChange={setCurrentExchange}
          stocks={stocks}
          onSelectStock={handleSelectStock}
          onToggleMobileMenu={() => setMobileMenuOpen(!mobileMenuOpen)}
          currentUser={currentUser}
          onOpenAuth={handleOpenAuth}
          onSignOut={handleSignOut}
        />

        {/* Scrolling Ticker Tape below Header */}
        <div className="pt-16">
          <TickerTape
            indices={indices}
            stocks={stocks}
            onSelectStock={handleSelectStock}
          />
        </div>

        {/* Active Page View Container */}
        <main className="flex-1 p-4 lg:p-6 overflow-y-auto">
          {currentTab === 'dashboard' && (
            <DashboardPage
              indices={indices}
              stocks={stocks}
              watchlistSymbols={watchlistSymbols}
              onSelectStock={handleSelectStock}
              onNavigateToPredictions={() => setCurrentTab('ai-predictions')}
              onNavigateToWatchlist={() => setCurrentTab('watchlist')}
              onRemoveFromWatchlist={handleRemoveFromWatchlist}
            />
          )}

          {currentTab === 'stock-analysis' && (
            <StockAnalysisPage
              selectedSymbol={selectedStockSymbol}
              onSelectSymbol={setSelectedStockSymbol}
              allStocks={stocks}
              onNavigateToPredictions={handleNavigateToPredictions}
            />
          )}

          {currentTab === 'ai-predictions' && (
            <AIPredictionsPage
              selectedSymbol={selectedStockSymbol}
              onSelectSymbol={setSelectedStockSymbol}
              allStocks={stocks}
              onNavigateToAnalysis={handleSelectStock}
            />
          )}

          {currentTab === 'watchlist' && (
            <WatchlistPage
              allStocks={stocks}
              watchlistSymbols={watchlistSymbols}
              onAddToWatchlist={handleAddToWatchlist}
              onRemoveFromWatchlist={handleRemoveFromWatchlist}
              onSelectStockForAnalysis={handleSelectStock}
            />
          )}

          {currentTab === 'settings' && (
            <SettingsPage
              currentUser={currentUser}
              onOpenAuth={handleOpenAuth}
              onUserUpdated={(updated) => setCurrentUser(updated)}
              currentExchange={currentExchange}
              onExchangeChange={setCurrentExchange}
            />
          )}

          {['risk-analysis', 'stock-comparison', 'reports'].includes(currentTab) && (
            <RoadmapPage
              tab={currentTab}
              onNavigate={(tab) => setCurrentTab(tab)}
            />
          )}
        </main>
      </div>

      {/* Global User Authentication & Profile Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        initialMode={authModalMode}
        onClose={() => setIsAuthModalOpen(false)}
        currentUser={currentUser}
        onAuthSuccess={(user) => {
          setCurrentUser(user);
          setIsAuthModalOpen(false);
        }}
      />
    </div>
  );
}
